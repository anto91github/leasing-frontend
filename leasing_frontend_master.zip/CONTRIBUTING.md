# Coding Rules

Please follow [Google's JavaScript Style Guide](https://google.github.io/styleguide/jsguide.html)

### Naming Conventions

In general Angular should follow TypeScript naming conventions.
See: https://github.com/Microsoft/TypeScript/wiki/Coding-guidelines

Classes:

- Example: `Compiler`, `ApplicationMetadata`
- Camel case with first letter uppercase
- In general prefer single words. (This is so that when appending `Proto` or `Factory` the class
  is still reasonable to work with.)
- Should not end with `Impl` or any other word which describes a specific implementation of an
  interface.

Interfaces:

- Follow the same rules as Classes
- Should not have `I` or `Interface` in the name or any other way of identifying it as an interface.

Methods and functions:

- Example: `bootstrap`, `someMethod`
- Should be camel case with first letter lowercase

Constants:

- Example: `CORE_DIRECTIVES`
- Should be all uppercase with SNAKE_CASE

# Commit Message Guidelines

Angular have very precise rules over how their git commit messages can be formatted. This leads to **more readable messages** that are easy to follow when looking through the project history. But also, we use the git commit messages to generate the **application change log**.

### Commit Message Format

Each commit message consists of a **header**, a **body** and a **footer**. The header has a special
format that includes a **type**, a **scope** and a **subject**:

```
<type>(<optional scope>): <subject>
<BLANK LINE>
<optional body>
<BLANK LINE>
<optional footer>
```

The header is mandatory but the body, footer, and the scope of the header is optional. The footer should contain a closing reference to an issue if any.

Samples: (even more [samples](https://github.com/angular/angular/commits/master))

```
docs(changelog): update changelog to 2.1
```

```
feat(lang): add english language
```

```
fix(master): edit & delete on master employee

Change redirect URL after successfully edit / delete data.

fixes issue #12
```

### Type

Must be one of the following:

- **feat**: A new feature
- **fix**: A bug fix
- **docs**: Changes to documentation
- **style**: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc)
- **refactor**: A code change that neither fixes a bug nor adds a feature
- **build**: Changes that affect the build system or external dependencies (example scopes: gulp, broccoli, npm)

# Changelog

Generate changelogs and release notes from project's commit messages and metadata.

### Quickstart

```sh
$ npm install -g standard-changelog
$ cd leasing-frontend
$ standard-changelog
```

The above generates a changelog based on commits since the last semver tag that match the pattern of a "Feature", "Fix", "Performance Improvement" or "Breaking Changes".

All available command line parameters can be listed using CLI: `standard-changelog --help`.

### Recommended Workflow

1. Make changes
1. Commit those changes
1. Bump version in `package.json`
1. Run command `standard-changelog` from project directory
1. Commit `package.json` and `CHANGELOG.md` files
1. Tag
1. Push
