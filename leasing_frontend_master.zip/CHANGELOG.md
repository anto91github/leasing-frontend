<a name="0.1.1"></a>

## [0.1.1](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/compare/v0.1.0...v0.1.1) (2018-10-10)

### Bug Fixes

- **auth:** check userdata before assign value cookie ([6153a61](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/6153a61))
- **auth:** user authentication using concat request ([ccb0713](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/ccb0713))
- **service:** temporary solutions for getting token in http header ([5e5af90](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/5e5af90))

### Features

- **auth:** add cookie for user details, roles, and companies ([95729e9](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/95729e9))
- **auth:** implement login with rest api ([c1334ec](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/c1334ec))
- **auth:** set icon to checked on list of company in the header ([9dc336b](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/9dc336b))
- **auth:** set userdata on cookie ([9cfa580](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/9cfa580))
- **auth:** store authentication data with cookie instead localstorage ([dd49333](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/dd49333))
- **core:** error message on dxdatagrid ([3b49722](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/3b49722))
- **core:** error message on dxdatagrid ([b4b7fb7](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/b4b7fb7))
- **customer:** dynamic form on form attachment ([4a49738](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/4a49738))
- **service:** add company_id parameter on getmaster ([4794b4e](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/4794b4e))
- **template:** add dropdown on header to switch company ([7eb05b7](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/7eb05b7))

<a name="0.1.0"></a>

# 0.1.0 (2018-08-03)

### Bug Fixes

- Form Master Customer, fix if user change province, all field will be empty ([c89b05c](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/c89b05c))
- hide web input on vendor ([f731ea0](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/f731ea0))
- open preview pdf now enable to download in chrome ([e952da6](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/e952da6))

### Features

- Add header filter on grid installment ([f731aba](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/f731aba))
- Add input dp, interest, term on form submission ([98691c1](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/98691c1))
- Add installment details component ([5f919aa](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/5f919aa))
- Add installment form ([fb44b11](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/fb44b11))
- Add interface attachment ([496978e](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/496978e))
- Add test file capitalize pipe ([7cca14b](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/7cca14b))
- Add upload image on product form ([7c0f051](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/7c0f051))
- Create Data Grid for Policy Page ([c2c4e33](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/c2c4e33))
- Export pdf & excel installment data using sample ([9e76b4f](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/9e76b4f))
- Remove simulation module ([441661b](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/441661b))
- Remove simulation.component.css ([f18a408](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/f18a408))
- Scroll in sidebar ([3bc14c7](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/3bc14c7))
- Style input form validation ([293f8ae](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/293f8ae))
- Update style installment detail ([27253eb](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/27253eb))
- Update upload attachment ([122e5cf](http://administrator@192.168.1.22:/repos/leasing-frontend/.git/commits/122e5cf))
