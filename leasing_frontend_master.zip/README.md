# Leasing Frontend

Leasing Frontend is a leasing application built on top of Angular Framework.

## Prerequisite Software

Before you can build and test Leasing, you must install and configure the following products on your development machine:

- [Git](http://git-scm.com) and/or the **GitHub app** (for [Mac](http://mac.github.com) or
  [Windows](http://windows.github.com)); [GitHub's Guide to Installing
  Git](https://help.github.com/articles/set-up-git) is a good source of information.

- [Node.js](http://nodejs.org), (version specified in the engines field of [`package.json`](../package.json)) which is used to run a development web server,
  run tests, and generate distributable files.

- [Yarn](https://yarnpkg.com) or [Npm](https://npmjs.com) (version specified in the engines field of [`package.json`](../package.json)) which is used to install dependencies.

## Clone Repository

Clone leasing repository to our local folder

```sh
git clone administrator@192.168.1.22:/repos/leasing-frontend/.git
```

## Installing Npm Modules

Next, install the JavaScript modules needed to build and test Angular:

```sh
# Install Angular project dependencies (package.json)
npm install
```

## Running Development Server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.
