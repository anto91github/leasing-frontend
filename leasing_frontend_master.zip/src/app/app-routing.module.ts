import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './modules/home/home.component';
import { AuthComponent } from './modules/auth/auth.component';
import { SimpleLayoutComponent } from './shared/containers/simple-layout/simple-layout.component';
import { FullLayoutComponent } from './shared/containers/full-layout/full-layout.component';
import { AuthGuard } from './core/services/auth-guard.service';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: '',
    component: FullLayoutComponent,
    canActivateChild: [AuthGuard],
    data: {
      breadcrumb: 'app.home'
    },
    children: [
      {
        path: 'dashboard',
        component: HomeComponent,
        data: {
          breadcrumb: ''
        }
      },
      {
        path: 'user',
        data: {
          breadcrumb: 'sys.user'
        },
        loadChildren: './modules/user/user.module#UserModule'
      },
      {
        path: 'master',
        data: {
          breadcrumb: 'app.master'
        },
        children: [
          {
            path: 'customers',
            loadChildren: './modules/master/customer/customer.module#CustomerModule',
            data: {
              breadcrumb: 'app.customer'
            }
          },
          {
            path: 'vendors',
            loadChildren: './modules/master/vendor/vendor.module#VendorModule',
            data: {
              breadcrumb: 'app.vendor'
            }
          },
          {
            path: 'products',
            loadChildren: './modules/master/product/product.module#ProductModule',
            data: {
              breadcrumb: 'app.product'
            }
          },
          {
            path: 'company',
            loadChildren: './modules/master/company/company.module#CompanyModule',
            data: {
              breadcrumb: 'app.company'
            }
          },
          {
            path: 'dealer',
            loadChildren: './modules/master/dealer/dealer.module#DealerModule',
            data: {
              breadcrumb: 'app.dealer'
            }
          }
        ]
      },
      {
        path: 'transaction',
        data: {
          breadcrumb: 'app.transaction'
        },
        children: [
          {
            path: 'simulation',
            loadChildren: './modules/transaction/simulation/simulation.module#SimulationModule',
            data: {
              breadcrumb: 'app.simulation'
            }
          },
          {
            path: 'submissions',
            loadChildren: './modules/transaction/submission/submission.module#SubmissionModule',
            data: {
              breadcrumb: 'app.submission'
            }
          },
          {
            path: 'installment',
            loadChildren: './modules/transaction/installment/installment.module#InstallmentModule',
            data: {
              breadcrumb: 'app.installment'
            }
          },
          {
            path: 'transfer-stock',
            loadChildren: './modules/transaction/transfer-stock/transfer-stock.module#TransferStockModule',
            data: {
              breadcrumb: 'app.transfer-stock'
            }
          },
          {
            path: 'delivery',
            loadChildren: './modules/transaction/delivery/delivery.module#DeliveryModule',
            data: {
              breadcrumb: 'app.delivery'
            }
          },
          {
            path: 'vendor-po',
            loadChildren:
              './modules/transaction/vendor-po/vendor-po.module#VendorPoModule',
            data: {
              breadcrumb: 'app.vendor-po'
            }
          },
          {
            path: 'vendor-receive',
            loadChildren:
              './modules/transaction/vendor-receive/vendor-receive.module#VendorReceiveModule',
            data: {
              breadcrumb: 'app.vendor-receive'
            }
          },
          {
            path: 'vendor-invoice',
            loadChildren:
              './modules/transaction/vendor-invoice/vendor-invoice.module#VendorInvoiceModule',
            data: {
              breadcrumb: 'app.vendor-invoice'
            }
          },
          {
            path: 'vendor-payment',
            loadChildren:
              './modules/transaction/vendor-payment/vendor-payment.module#VendorPaymentModule',
            data: {
              breadcrumb: 'app.vendor-payment'
            }
          },
          {
            path: 'customer-receive',
            loadChildren:
              './modules/transaction/customer-receive/customer-receive.module#CustomerReceiveModule',
            data: {
              breadcrumb: 'app.customer-receive'
            }
          },
          {
            path: 'stock',
            loadChildren: './modules/transaction/stock/stock.module#StockModule',
            data: {
              breadcrumb: 'app.stock'
            }
          },
          {
            path: 'income',
            loadChildren: './modules/transaction/income/income.module#IncomeModule',
            data: {
              breadcrumb: 'app.income'
            }
          },
          {
            path: 'outcome',
            loadChildren: './modules/transaction/outcome/outcome.module#OutcomeModule',
            data: {
              breadcrumb: 'app.outcome'
            }
          }
        ]
      },
      {
        path: 'setting',
        data: {
          breadcrumb: 'sys.settings'
        },
        children: [
          {
            path: 'user',
            loadChildren: './modules/setting/user/user.module#UserModule',
            data: {
              breadcrumb: 'sys.user'
            }
          },
          {
            path: 'role',
            loadChildren: './modules/setting/role/role.module#RoleModule',
            data: {
              breadcrumb: 'sys.role'
            }
          },
          {
            path: 'policy',
            loadChildren: './modules/setting/policy/policy.module#PolicyModule',
            data: {
              breadcrumb: 'sys.policy'
            }
          }
        ]
      },
      {
        path: 'report',
        data: {
          breadcrumb: 'app.report'
        },
        children: [
          {
            path: 'employees',
            loadChildren: './modules/report/employee/employee.module#EmployeeModule',
            data: {
              breadcrumb: 'app.employee'
            }
          },
          {
            path: 'finance',
            loadChildren: './modules/report/finance/finance.module#FinanceModule',
            data: {
              breadcrumb: 'app.finance'
            }
          }
        ]
      }
    ]
  },
  {
    path: '',
    component: SimpleLayoutComponent,
    children: [
      {
        path: 'auth',
        loadChildren: './modules/auth/auth.module#AuthModule'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
