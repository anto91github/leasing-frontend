import { Pipe, PipeTransform } from '@angular/core';

/*
 * Format string to camelCase
 *
 *  returns string;
*/
@Pipe({
  name: 'capitalize'
})
export class CapitalizePipe implements PipeTransform {
  transform(value: any, args?: any): string {
    if (value.indexOf('_') > -1) {
      let word = '';
      const words = value.split('_');
      for (let i = 0; i < words.length; i++) {
        word += words[i];
        if (i < words.length - 1) {
          words[i + 1] = words[i + 1].charAt(0).toUpperCase() + words[i + 1].slice(1);
        }
      }
      return word;
    } else {
      return value.replace(/\w\S*/g, function(txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    }
  }
}
