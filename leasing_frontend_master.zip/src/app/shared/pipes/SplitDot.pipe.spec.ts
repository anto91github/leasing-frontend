import { SplitDot } from './splitDot.pipe ';

describe('CapitalizePipe', () => {
  it('create an instance', () => {
    const pipe = new SplitDot();
    expect(pipe).toBeTruthy();
  });
  it('cylinder_capacity should return cylinderCapacity', () => {
    const pipe = new SplitDot();
    expect(pipe.transform('cylinder_capacity')).toEqual('cylinderCapacity');
  });
});
