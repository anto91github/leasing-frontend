export * from './capitalize.pipe';
export * from './SplitDot.pipe ';
