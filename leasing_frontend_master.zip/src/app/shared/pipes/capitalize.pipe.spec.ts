import { CapitalizePipe } from './capitalize.pipe';

describe('CapitalizePipe', () => {
  it('create an instance', () => {
    const pipe = new CapitalizePipe();
    expect(pipe).toBeTruthy();
  });
  it('cylinder_capacity should return cylinderCapacity', () => {
    const pipe = new CapitalizePipe();
    expect(pipe.transform('cylinder_capacity')).toEqual('cylinderCapacity');
  });
});
