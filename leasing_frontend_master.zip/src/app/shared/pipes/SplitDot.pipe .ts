import { Pipe, PipeTransform } from '@angular/core';

/*
 * Format string to camelCase
 *
 *  returns string;
*/
@Pipe({
  name: 'SplitDot'
})
export class SplitDot implements PipeTransform {
  transform(value: any, args?: any): string {
    const words = value.split('.');
    return words[2].replace(/\w\S*/g, function(txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
  }
}
