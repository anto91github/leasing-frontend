import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CapitalizePipe } from './pipes/capitalize.pipe';
import { SplitDot } from './pipes/SplitDot.pipe ';
import { SpinnerComponent } from './spinner/spinner.component';
import { ToastyModule } from 'ng2-toasty';

@NgModule({
  imports: [CommonModule, ToastyModule.forRoot()],
  declarations: [CapitalizePipe, SplitDot, SpinnerComponent],
  providers: [CapitalizePipe, SplitDot],
  exports: [CapitalizePipe, SplitDot, SpinnerComponent, ToastyModule]
})
export class SharedModule {}
