import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './simple-layout.component.html',
  styles: []
})
export class SimpleLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
