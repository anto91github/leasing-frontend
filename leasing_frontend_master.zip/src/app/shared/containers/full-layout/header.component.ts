import { DOCUMENT } from '@angular/common';
import { Component, OnInit, Inject } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LocalStorageService } from 'ngx-webstorage';
import { Router } from '@angular/router';
import { ToastyService, ToastOptions, ToastData } from 'ng2-toasty';

import { UserService } from '../../../core';

/**
 * This class represents the header component.
 */
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  langCurrent = '';
  langList = [];
  companies = {};
  company_active = '0';

  constructor(
    private router: Router,
    private translate: TranslateService,
    private localSt: LocalStorageService,
    private userService: UserService,
    private toastyService: ToastyService,
    @Inject(DOCUMENT) private document: Document
  ) {}

  ngOnInit() {
    this.langCurrent = this.translate.currentLang;
    this.langList = ['id', 'en'];
    this.document.body.classList.remove('bg-white');
    this.companies = this.localSt.retrieve('user_companies');
    this.company_active = this.localSt.retrieve('user_company_active');
  }

  /**
   * Toggle sidebar open or collapsed
   */
  toggleSidebar() {
    const width = window.innerWidth;
    if (width > 1024) {
      this.document.body.classList.remove('sidebar-open');
      this.document.body.classList.toggle('sidebar-collapsed');
    } else {
      this.document.body.classList.remove('sidebar-collapsed');
      this.document.body.classList.toggle('sidebar-open');
    }
  }

  /**
   * Change active language
   */
  switchLang(lang, event) {
    this.translate.use(lang);
    this.langCurrent = lang;
    this.localSt.store('sys.lang', lang);
    event.preventDefault();
  }

  /**
   * Change active company
   */
  switchCompany(company, event) {
    this.localSt.store('user_company_active', company.id);
    this.company_active = company.id;
    const toastOptions: ToastOptions = {
      title: this.translate.instant('app.company'),
      msg: this.translate.instant('alert.branch_success'),
      showClose: true,
      timeout: 2000,
      theme: 'default',
      onRemove: (toast: ToastData) => {
        setTimeout(() => {
          window.location.reload();
        });
      }
    };
    this.toastyService.success(toastOptions);
    event.preventDefault();
  }

  /**
   * Logout application
   */
  logout() {
    this.userService.purgeAuth();
    this.router.navigateByUrl('/auth/login');
  }
}
