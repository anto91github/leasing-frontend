import { Component, OnInit } from '@angular/core';
import { SidebarMenu } from './sidebar-menu';
import { LocalStorageService } from 'ngx-webstorage';
import { ApiService } from '../../../core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styles: []
})
export class SidebarComponent implements OnInit {
  user_permission_collection: any = {};
  user_permission: any = [];
  // items: any = SidebarMenu; // -->uncomment this to apply side menu from sidebar-menu.ts
  items: any = [];
  words: any = [];
  side_menu: any = [];
  module: any = [];
  pages: any = [];
  groups: any = {};
  new_pages: any = [];
  groups_module: any = [];
  clean_pages: any = [];
  config: any;

  constructor(private apiService: ApiService, private localSt: LocalStorageService) {
    function remove_duplicates_es6(arr) {
      const s = new Set(arr);
      const it = s.values();
      return Array.from(it);
    }
    this.user_permission_collection = this.localSt.retrieve('user_roles'); // get user permission collection from Local Storage
    if (this.user_permission_collection !== null) {
      if (this.user_permission_collection.length) {
        for (const check of this.user_permission_collection[0].access_collection) {
          // get user permission from cookies and split the '.' character
          this.user_permission.push(check.permission.split('.'));
        }
      }
    }

    for (const user_module of this.user_permission) {
      // save "User-Module" to this.module array
      this.module.push(user_module[0]);
    }

    for (const user_pages of this.user_permission) {
      // save "User-Pages" to this.module array
      this.pages.push(user_pages[1]);
    }
    const clean_module = remove_duplicates_es6(this.module); // remove duplicate module
    this.clean_pages = remove_duplicates_es6(this.pages); // remove duplicate module

    this.apiService.get('module?page=0&size=500&sort=order,asc').subscribe((data: any) => {
      this.items.push(
        { title: true, name: 'home' },
        { name: 'dashboard', url: '/dashboard', icon: 'mdi mdi-home' }
      );

      this.side_menu = data.content;
      /*for (let i = 0; i < this.side_menu.length; i++) {
        const groupName = this.side_menu[i].group;
        if (!this.groups[groupName]) {
          this.groups[groupName] = [];
        }
        this.groups[groupName].push(this.side_menu[i].color);
      }*/

      // start loop for group page
      let index_module = 0;
      for (const module of this.side_menu) {
        this.groups_module.push({ module: module.module, page_collection: [] });
        const groups_child = [];
        const groups_parent = [];
        for (const page of module.page_collection) {
          const groupName = page.parent_id;
          if (!this.groups[groupName]) {
            this.groups[groupName] = [];
          }

          if (!page.parent_id) {
            groups_parent.push({
              id: page.id,
              parent_id: page.parent_id,
              name: page.page,
              url: '/' + module.module + '/' + page.page,
              icon: page.icon == null ? '' : page.icon,
              children: []
            });
          } else {
            groups_child.push({
              id: page.id,
              parent_id: page.parent_id,
              name: page.page,
              url: '/' + module.module + '/' + page.page,
              icon: page.icon == null ? '' : page.icon
            });
          }

          // this.groups[groupName].push({page_name: page.page, parent_id: page.parent_id}); // grouped page menu
        }
        this.groups_module[index_module].page_collection = groups_parent;

        // Loop insert child items
        for (const child of groups_child) {
          this.insert_child(child);
        }
        index_module++;
      }
      // end loop for group page

      for (const module of this.groups_module) {
        if (clean_module.includes(module.module)) {
          this.items.push({ title: true, name: module.module });
        }

        for (const page of module.page_collection) {
          this.items.push({
            name: page.name,
            url: page.url,
            icon: page.icon,
            children: page.children
          });
        }
      }
    });
  }

  ngOnInit() {}

  insert_child(item) {
    let index_module = 0;
    for (const parent of this.groups_module) {
      let index_page = 0;
      for (const page of parent.page_collection) {
        if (item.parent_id === page.id) {
          this.groups_module[index_module].page_collection[index_page].children.push(item);
        }
        index_page++;
      }
      index_module++;
    }
  }

  hideMenu(event) {
    event.target.classList.remove('nav-hover');
  }

  showMenu(event) {
    event.target.classList.add('nav-hover');
  }

  toggleMenu(item, event) {
    if (item.children && item.children.length > 0) {
      event.target.closest('li').classList.toggle('nav-active');
      event.preventDefault();
    }
  }

  public isDivider(item) {
    return item.divider ? true : false;
  }

  public isTitle(item) {
    return item.title ? true : false;
  }

  public isDropdown(item) {
    if (item.children && item.children.length > 0) {
      return true;
    } else if (item.children) {
      if (this.clean_pages.includes(item.name)) {
        return false;
      } else {
        return true;
      }
      // return false;
    }
    // return item.children && item.children.length > 0 ? true : false;
  }

  public isPermit(item) {
    let permission = false;
    if (item.children && item.children.length > 0) {
      for (const child of item.children) {
        if (this.clean_pages.includes(child.name)) {
          permission = true;
        }
      }
    } else {
      return this.clean_pages.includes(item.name);
    }
    return permission;
  }

  /*public isPermitPage(item) {
    let permission = false;
    for (const child of item) {
      if (this.clean_pages.includes(child.name)) {
        permission = true;
      }
    }
    return permission;
  }*/
}
