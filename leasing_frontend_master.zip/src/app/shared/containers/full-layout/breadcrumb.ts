export interface BreadCrumb {
  label: string;
  url: string;
}
