export const SidebarMenu = [
  { title: true, name: 'app.home' },
  { name: 'app.dashboard', url: '/dashboard', icon: 'mdi mdi-home' },
  { title: true, name: 'app.transaction' },
  {
    name: 'app.credit',
    icon: 'mdi mdi-folder-plus',
    children: [
      { name: 'app.simulation', url: '/transaction/simulation', icon: 'icon-puzzle' },
      { name: 'app.submission', url: '/transaction/submissions', icon: 'icon-puzzle' },
      { name: 'app.installment', url: '/transaction/installment', icon: 'icon-puzzle' }
    ]
  },
  { name: 'app.stock', url: '/transaction/stock', icon: 'mdi mdi-buffer' },
  { name: 'app.income', url: '/transaction/income', icon: 'mdi mdi-cash-multiple' },
  { name: 'app.outcome', url: '/transaction/outcome', icon: 'mdi mdi-book-minus' },
  { title: true, name: 'app.master' },
  { name: 'app.customer', url: '/master/customers', icon: 'mdi mdi-account-box' },
  { name: 'app.vendor', url: '/master/vendors', icon: 'mdi mdi-domain' },
  { name: 'app.product', url: '/master/products', icon: 'mdi mdi-cube' },
  { title: true, name: 'sys.settings' },
  { name: 'sys.user', url: '/setting/user', icon: 'mdi mdi-account-multiple' },
  { name: 'sys.role', url: '/setting/role', icon: 'mdi mdi-account-settings-variant' },
  { name: 'sys.policy', url: '/setting/policy', icon: 'mdi mdi-account-settings-variant' },
  { title: true, name: 'app.report' },
  { name: 'app.employee', url: '/report/employees', icon: 'mdi mdi-account' },
  { name: 'app.finance', url: '/report/finance', icon: 'mdi mdi-file-document' }
];
