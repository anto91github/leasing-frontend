import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BreadCrumb } from './breadcrumb';


@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html'
})
export class BreadcrumbComponent implements OnInit {
  breadcrumbs: Array<BreadCrumb>;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private translateService: TranslateService
  ) {
    this.router.events
      // .filter(event => event instanceof NavigationEnd)
      .subscribe(event => {
        this.breadcrumbs = [];
        let currentRoute = this.route.root,
          url = '';
        do {
          const childrenRoutes = currentRoute.children;
          currentRoute = null;
          // tslint:disable-next-line:no-shadowed-variable
          childrenRoutes.forEach(route => {
            if (route.outlet === 'primary') {
              const routeSnapshot = route.snapshot;
              url += '/' + routeSnapshot.url.map(segment => segment.path).join('/');
              this.breadcrumbs.push({
                label: route.snapshot.data.breadcrumb,
                url: url
              });
              currentRoute = route;
            }
          });
        } while (currentRoute);
      });
  }

  ngOnInit() {}
}
