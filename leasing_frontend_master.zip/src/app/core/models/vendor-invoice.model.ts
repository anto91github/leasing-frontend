export interface VendorInvoice {
  id: number;
  receipt_id: number;
  invoice_number: string;
  invoice_date: string;
  invoice_value: number;
  invoice_detail: any;
}
