export interface Product {
  id: number;
  vendor_id: number;
  brand: string;
  type: string;
  category: string;
  model: string;
  cylinder_capacity: string;
  basic_price: number;
  fuel: string;
  picture: string;
}
