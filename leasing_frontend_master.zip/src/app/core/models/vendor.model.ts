export interface Vendor {
  vendor_name: string;
  vendor_type: string;
  address: string;
  phone: string;
  fax: string;
  email: string;
  web: string;
}
