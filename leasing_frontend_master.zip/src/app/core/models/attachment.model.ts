export interface Attachment {
  file_download_uri: string;
  file_name: string;
  file_type: string;
  size: number;
}
