export interface Company {
    company_name: string;
    address: string;
    phone: string;
    fax: string;
    email: string;
    web: string;
  }
  