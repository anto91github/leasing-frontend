export interface Master {
  content: any;
  pageable: any;
  last: boolean;
  total_pages: number;
  total_elements: number;
  size: number;
  number: number;
  sort: any;
  number_of_elements: number;
  first: boolean;
}
