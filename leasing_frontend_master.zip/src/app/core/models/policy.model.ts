export interface Policy {
  id: number;
  title: string;
  description: string;
  content: string;
}
