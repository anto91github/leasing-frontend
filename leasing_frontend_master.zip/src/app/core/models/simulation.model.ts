export interface Simulation {
  no: number;
  /*due_date: string;
  remaining_amount: number;
  amount: number;
  interest: number;
  total_amount: number;*/
  payment_number: number;
  payment_date: string;
  interest_paid: number;
  principal_paid: number;
  payment_amount: number;
  balance: number;

}
