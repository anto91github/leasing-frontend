export interface Installment {
  id: number;
  kode: string;
  due_date: string;
  fullname: string;
  product: string;
  period: number;
  total: number;
  penalty: number;
  status: string;
}
