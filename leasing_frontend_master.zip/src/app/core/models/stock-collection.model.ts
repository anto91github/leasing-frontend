export interface StockCollection {
  stock_collection: any;
  id: number;
  manufacture_year: string;
  vin: string;
  engine_number: string;
  color: string;
  price: number;
}
