export interface Dealer {
    dealer_name: string;
    address: string;
    phone: string;
    fax: string;
    email: string;
    web: string;
    price_formulas: any;
}
