export interface Submission {
  id: number;
  date: string;
  name: string;
  product: string;
  period: string;
  down_payment: number;
  interest: number;
  status: string;
}
