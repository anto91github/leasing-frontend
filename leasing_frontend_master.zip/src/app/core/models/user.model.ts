export interface User {
  id: number;
  email: string;
  token: string;
  name: string;
  username: string;
  complete_name: string;
  role: string;
  image: string;
  status: string;
  content1: string;
  companys: any;
  roles: any;
}
