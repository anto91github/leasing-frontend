import { Role } from '../../core';

export const role: Role[] = [];
