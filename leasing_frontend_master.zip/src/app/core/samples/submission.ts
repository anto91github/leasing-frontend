import { Submission } from '../models/submission.model';

export const submission: Submission[] = [];
