import { Simulation } from '../../core';

export const simulation: Simulation[] = [];
