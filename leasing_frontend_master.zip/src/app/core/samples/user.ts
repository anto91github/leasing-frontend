import { User } from '../../core';

export const user: User[] = [];
