import { Policy } from '../../core';

export const policy: Policy[] = [];
