import { Installment } from '../../core';

export const installment: Installment[] = [];
