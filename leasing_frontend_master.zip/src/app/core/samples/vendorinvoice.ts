import { VendorInvoice } from '../models/vendor-invoice.model';

export const vendorinvoice: VendorInvoice[] = [];
