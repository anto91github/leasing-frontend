import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CookieModule } from 'ngx-cookie';

import { HttpTokenInterceptor } from './interceptors/http.token.interceptor';

import {
  JwtService,
  ApiService,
  UserService,
  AuthGuard,
  ConfigService,
  SampleService
} from './services';

@NgModule({
  imports: [CommonModule, CookieModule.forRoot()],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HttpTokenInterceptor, multi: true },
    ApiService,
    SampleService,
    AuthGuard,
    ConfigService,
    JwtService,
    UserService,
    {
      provide: APP_INITIALIZER,
      useFactory: (config: ConfigService) => () => config.load(),
      deps: [ConfigService],
      multi: true
    }
  ],
  declarations: []
})
export class CoreModule {}
