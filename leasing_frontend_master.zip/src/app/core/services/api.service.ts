import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

import { Master, StockCollection } from './../models';
import { CapitalizePipe } from '../../shared/pipes';
import { ConfigService } from './config.service';
import { JwtService } from './jwt.service';

@Injectable()
export class ApiService {
  headers_token: any;

  constructor(
    private config: ConfigService,
    private jwtService: JwtService,
    private localStorageService: LocalStorageService,
    private http: HttpClient,
    private capitalizePipe: CapitalizePipe
  ) {
    const token = this.jwtService.getToken();
    this.headers_token = new HttpHeaders();
    this.headers_token = this.headers_token.append('Authorization', 'Bearer ' + token);
  }

  getMaster(url: string, params: any): Promise<any> {
    // @TODO: Add remote filtering
    console.log(params.userData);
    const length = params.take || this.config.getConfig('paginationLength');
    const page = params.skip ? params.skip / length : 0;
    let options = `?page=${page}&size=${length}`;

    if (params.sort) {
      options += '&sort=' + this.capitalizePipe.transform(params.sort[0].selector);
      if (params.sort[0].desc) {
        options += ',desc';
      }
    }

    if (params.userData.custom_sort) {
      options += '&sort=' + params.userData.selector;
      if (params.userData.sortMethod === 'desc') {
         options += ',desc';
      }
    }
    if (params.userData.company_id) {
      options += '&company_id=' + this.localStorageService.retrieve('user_company_active');
    }
    if (params.userData.is_po_approved) {
      options += '&po_status=APPROVED';
    }
    if (params.userData.is_po_approved) {
      options += '&by?submisson_status=APPROVED';
    }
    if (params.userData.grn_status_not) {
      options += '&grn_status_not=RECEIVED';
    }

    return this.http
      .get(this.config.getConfig('apiUrl') + url + options)
      .toPromise()
      .catch(error => {
        return Promise.reject(error.error.message);
      })
      .then((item: Master) => {
        return {
          data: item.content,
          totalCount: item.total_elements
        };
      });
  }

  getSubmissionApprove(url: string, params: any): Promise<any> {
    // @TODO: Add remote filtering
    const length = params.take || this.config.getConfig('paginationLength');
    const page = params.skip ? params.skip / length : 0;
    let options = `?submission_status=APPROVED&has_schedule=TRUE&page=${page}&size=${length}`;
    if (params.sort) {
      options += '&sort=' + this.capitalizePipe.transform(params.sort[0].selector);
      if (params.sort[0].desc) {
        options += ',desc';
      }
    }
    if (params.userData.company_id) {
      options += '&company_id=' + this.localStorageService.retrieve('user_company_active');
    }

    return this.http
      .get(this.config.getConfig('apiUrl') + url + options)
      .toPromise()
      .catch(error => {
        return Promise.reject(error.error.message);
      })
      .then((item: Master) => {
        return {
          data: item.content,
          totalCount: item.total_elements
        };
      });
  }

  getAllcustomer(url: string, params: any): Promise<any> {
    // @TODO: Add remote filtering
    const length = params.take || this.config.getConfig('paginationLength');
    const page = params.skip ? params.skip / length : 0;
    let options = `?page=${page}&size=${length}`;
    if (params.sort) {
      options += '&sort=' + this.capitalizePipe.transform(params.sort[0].selector);
      if (params.sort[0].desc) {
        options += ',desc';
      }
    }
    if (params.userData.company_id) {
      options += '&company_id=' + this.localStorageService.retrieve('user_company_active');
    }

    return this.http
      .get(this.config.getConfig('apiUrl') + url + options)
      .toPromise()
      .catch(error => {
        return Promise.reject(error.error.message);
      })
      .then((item: Master) => {
        return {
          data: item.content,
          totalCount: item.total_elements
        };
      });
  }

  getAllcustomerCompany(url: string, params: any): Promise<any> {
    // @TODO: Add remote filtering
    const length = params.take || this.config.getConfig('paginationLength');
    const page = params.skip ? params.skip / length : 0;
    let options = `?page=${page}&size=${length}`;
    if (params.sort) {
      options += '&sort=' + this.capitalizePipe.transform(params.sort[0].selector);
      if (params.sort[0].desc) {
        options += ',desc';
      }
    }
    if (params.userData.company_id) {
      options += '&company_id=' + this.localStorageService.retrieve('user_company_active');
    }

    return this.http
      .get(this.config.getConfig('apiUrl') + url + options)
      .toPromise()
      .catch(error => {
        return Promise.reject(error.error.message);
      })
      .then((item: Master) => {
        return {
          data: item.content,
          totalCount: item.total_elements
        };
      });
  }

  getDataPersonal(item) {
    item.content.forEach(row => {
      if (!row) {
        return false;
      } else {
        /** KTP */
        const ktp_province = row['ktp_address_province'];
        const ktp_city = row['ktp_address_city'];
        const ktp_district = row['ktp_address_district'];
        const ktp_village = row['ktp_address_village'];

        /** KTP */
        const home_province = row['home_address_province'];
        const home_city = row['home_address_city'];
        const home_district = row['home_address_district'];
        const home_village = row['home_address_village'];

        /** Personal Data */
        const dataKeyPersonalData = Object.keys(row);
        if (dataKeyPersonalData[14] === 'ktp_address_province') {
          /** KTP */
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/province/' + ktp_province)
            .subscribe((data: any) => {
              row['ktp_address_province'] = data.province_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/city/' + ktp_city)
            .subscribe((data: any) => {
              row['ktp_address_city'] = data.city_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/district/' + ktp_district)
            .subscribe((data: any) => {
              row['ktp_address_district'] = data.district_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/village/' + ktp_village)
            .subscribe((data: any) => {
              row['ktp_address_village'] = data.village_name;
            });
        }
        /** HOME */
        if (dataKeyPersonalData[22] === 'home_address_province') {
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/province/' + home_province)
            .subscribe((data: any) => {
              row['home_address_province'] = data.province_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/city/' + home_city)
            .subscribe((data: any) => {
              row['home_address_city'] = data.city_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/district/' + home_district)
            .subscribe((data: any) => {
              row['home_address_district'] = data.district_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/village/' + home_village)
            .subscribe((data: any) => {
              row['home_address_village'] = data.village_name;
            });
        }
      }

      if (!row.customer_job_data) {
        return false;
      } else {
        /** JOB */
        const job_province = row.customer_job_data['province'];
        const job_city = row.customer_job_data['city'];
        const job_district = row.customer_job_data['district'];
        const job_village = row.customer_job_data['village'];

        const dataKeyJobData = Object.keys(row.customer_job_data);
        if (dataKeyJobData[5] === 'province') {
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/province/' + job_province)
            .subscribe((data: any) => {
              row['province'] = data.province_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/city/' + job_city)
            .subscribe((data: any) => {
              row['city'] = data.city_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/district/' + job_district)
            .subscribe((data: any) => {
              row['district'] = data.district_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/village/' + job_village)
            .subscribe((data: any) => {
              row['village'] = data.village_name;
            });
        }
      }

      if (!row.customer_couple_data) {
        return false;
      } else {
      /** Couple */
        const couple_province = row.customer_couple_data['ktp_address_province'];
        const couple_city = row.customer_couple_data['ktp_address_city'];
        const couple_district = row.customer_couple_data['ktp_address_district'];
        const couple_village = row.customer_couple_data['ktp_address_village'];

        const dataKeyCoupleData = Object.keys(row.customer_couple_data);

        if (dataKeyCoupleData[11] === 'ktp_address_province') {
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/province/' + couple_province)
            .subscribe((data: any) => {
              row['ktp_address_province'] = data.province_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/city/' + couple_city)
            .subscribe((data: any) => {
              row['ktp_address_city'] = data.city_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/district/' + couple_district)
            .subscribe((data: any) => {
              row['ktp_address_district'] = data.district_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/village/' + couple_village)
            .subscribe((data: any) => {
              row['ktp_address_village'] = data.village_name;
            });
        }
      }

      if (!row.customer_emergency_contact) {
        return false;
      } else {
        /** Emergancy Contact */
        const emergancyContact_province = row.customer_emergency_contact['address_province'];
        const emergancyContact_city = row.customer_emergency_contact['address_city'];
        const emergancyContact_district = row.customer_emergency_contact['address_district'];
        const emergancyContact_village = row.customer_emergency_contact['address_village'];

        const dataKeyEmerganyContactData = Object.keys(row.customer_emergency_contact);
        if (dataKeyEmerganyContactData[6] === 'address_province') {
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/province/' + emergancyContact_province)
            .subscribe((data: any) => {
              row['address_province'] = data.province_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/city/' + emergancyContact_city)
            .subscribe((data: any) => {
              row['address_city'] = data.city_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/district/' + emergancyContact_district)
            .subscribe((data: any) => {
              row['address_district'] = data.district_name;
            });
          this.http
            .get(this.config.getConfig('apiUrl') + 'area/village/' + emergancyContact_village)
            .subscribe((data: any) => {
              row['address_village'] = data.village_name;
            });
        }
      }
      return row;
    });
  }

  getSimulation(url: string, params: any) /*: Promise<any>*/ {
    const length = params.take || this.config.getConfig('paginationLength');
    const page = params.skip ? params.skip / length : 0;
    const amount = params.amount ? params.amount : '';
    const dp = params.dp ? params.dp : '';
    const interest = params.interest ? params.interest : '';
    const term = params.term ? params.term : '';
    let options = `?page=${page}&size=${length}&amount=${amount}&dp=${dp}&interest=${interest}&term=${term}`;
    if (params.sort) {
      options += '&sort=' + this.capitalizePipe.transform(params.sort[0].selector);
      if (params.sort[0].desc) {
        options += ',desc';
      }
    }

    const content_dummy = [
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      },
      {
        due_date: '12/05/2011',
        remaining_amount: '15,990,925',
        amount: '332,404',
        interest: '358,596',
        total_amount: '691,000'
      }
    ];

    return content_dummy;
  }

  getSimulation2() {
    const content = {
      content: [
        {
          id: 3,
          fixed_income: 1,
          couple_income: 2,
          other_income: 3,
          spending: 4,
          subscribe: 1
        }
      ]
    };
    return content;
  }

  getContent(url) {
    return this.http
      .get(this.config.getConfig('apiUrl') + url, { headers: this.headers_token })
      .toPromise()
      .catch(error => Promise.reject(error.error.message))
      .then((response: Master) => {
        return response.content;
      });
  }

  getStockCollection(url) {
    return this.http
      .get(this.config.getConfig('apiUrl') + url, { headers: this.headers_token })
      .toPromise()
      .catch(error => Promise.reject(error.message))
      .then((response: StockCollection) => {
        return response.stock_collection;
      });
    // return this.http.get(this.config.getConfig('apiUrl') + url);

    /*const dummy =[
        {
          color:"Black",
          engine_number:"01001",
          id: 1,
          manufacture_year:"2018-01-01",
          price:25000000,
          vin:"01001"
        }
      ];
      return dummy;*/
  }

  get(url: string) {
    return this.http.get(this.config.getConfig('apiUrl') + url, {
      headers: this.headers_token
    });
  }

  post(url: string, params) {
    return this.http.post(this.config.getConfig('apiUrl') + url, params, { observe: 'response' });
  }

  put(url: string, params) {
    return this.http.put(this.config.getConfig('apiUrl') + url, params, {
      observe: 'response'
    });
  }

  delete(url: string) {
    return this.http.delete(this.config.getConfig('apiUrl') + url);
  }

  postUploadFile(url: string, params) {
    return this.http.post(this.config.getConfig('apiUrl') + url, params);
  }
}
