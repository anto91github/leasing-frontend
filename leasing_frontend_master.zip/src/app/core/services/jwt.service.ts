import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie';

/**
 * A service for read, store, and delete user token
 */
@Injectable()
export class JwtService {
  /**
   * Creates a new JwtService with the injected CookieService.
   * @param {CookieService} cookieService The injected CookieService.
   * @constructor
   */
  constructor(private cookieService: CookieService) {}

  /**
   * Get user token from cookie
   * @return {string} The value of user token that wants to be got
   */
  getToken(): String {
    return this.cookieService.get('user_token');
  }

  /**
   * Save user token to cookie
   * @param {string} token The value of user token that want to be stored
   * @returns {void}
   */
  saveToken(token: string) {
    this.cookieService.put('user_token', token);
  }

  /**
   * Destroy user token from cookie
   * @returns {void}
   */
  destroyToken() {
    this.cookieService.get('user_token');
  }
}
