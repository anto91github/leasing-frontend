import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';

import { submission, installment, user, role, simulation, policy, vendorinvoice } from '../samples';
import { Installment, Role, Simulation, User, Policy, VendorInvoice } from '..';

@Injectable({
  providedIn: 'root'
})
export class SampleService {
  constructor() {}

  getSubmission() {
    return submission;
  }

  getInstallment(): Observable<Installment[]> {
    return of(installment);
  }

  getUser() {
    return user;
  }

  getRole() {
    return role;
  }

  getSimulation(): Observable<Simulation[]> {
    return of(simulation);
  }

  getUserSample(): Observable<User[]> {
    return of(user);
  }

  getRoleSample(): Observable<Role[]> {
    return of(role);
  }

  getPolicySample(): Observable<Policy[]> {
    return of(policy);
  }

  getVendorInvoiceSample(): Observable<VendorInvoice[]> {
    return of(vendorinvoice);
  }

}
