import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, mergeMap, concatMap, delay } from 'rxjs/operators';
import { forkJoin, combineLatest, from, concat } from 'rxjs';
import { CookieService } from 'ngx-cookie';

import { ApiService } from './api.service';
import { JwtService } from './jwt.service';
import { User } from '../models';
import { LocalStorageService } from 'ngx-webstorage';

@Injectable()
export class UserService {
  isLoggedIn = false;
  UserRole = [];
  constructor(
    private apiService: ApiService,
    private jwtService: JwtService,
    private cookieService: CookieService,
    private localSt: LocalStorageService
  ) {}

  // Verify JWT in localstorage with server & load user's info.
  // This runs once on application startup.
  populate() {
    // If JWT detected, attempt to get & store user's info
    if (this.jwtService.getToken()) {
      // TODO: Request user profile
      this.isLoggedIn = true;
    } else {
      // Remove any potential remnants of previous auth states
      this.purgeAuth();
    }
  }

  attemptAuth(credentials): Observable<any> {
    const userSignin = this.apiService.post('auth/signin', credentials).pipe(
      map((data: any) => {
        this.isLoggedIn = true;
        this.jwtService.saveToken(data.body.access_token);
        return data.body;
      })
    );
    const userDetails = id => this.apiService.get('user/' + id);
    const userMe = this.apiService
      .get('user/me')
      .pipe(concatMap((user: User) => userDetails(user.id)));
    return concat(userSignin, userMe);
  }

  saveUserData(user: User) {
    const userData = { name: user.name, id: user.id, username: user.username, email: user.email };
    const userCompanies = [];
    const userRoles = [];

    if (user.roles) {
      for (const role of user.roles) {
        userRoles.push({
          id: role.id,
          name: role.name,
          access_collection: role.access_collection
        });
      }
    }
    if (user.companys) {
      for (const company of user.companys) {
        userCompanies.push({
          id: company.id,
          company_name: company.company_name,
          address: company.address,
          email: company.email,
          phone: company.phone,
          fax: company.fax
        });
      }
    }
    this.localSt.store('user_details', userData);
    this.localSt.store('user_roles', userRoles);
    this.localSt.store('user_companies', userCompanies);
    this.localSt.store('user_company_active', userCompanies.length ? userCompanies[0].id : '');
  }

  purgeAuth() {
    this.isLoggedIn = false;
    this.jwtService.destroyToken();
    this.cookieService.removeAll();
    this.localSt.clear();
  }
}
