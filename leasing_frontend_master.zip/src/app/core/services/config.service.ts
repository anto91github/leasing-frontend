import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

/**
 * A service for read configuration data from app.config.json
 */
@Injectable()
export class ConfigService {
  config: Object = null;

  /**
   * Creates a new ConfigService with the injected HttpClient.
   * @param {HttpClient} http The injected HttpClient.
   * @constructor
   */
  constructor(private http: HttpClient) {}

  /**
   * Get specific data from configuration
   * @return {string} The value of configuration data from specified key
   */
  public getConfig(key: any) {
    return typeof this.config[key] === null ? '' : this.config[key];
  }

  /**
   * Load all configuration data from app.config.json
   */
  load(): Promise<any> {
    return this.http
      .get('app/app.config.json')
      .toPromise()
      .then(res => (this.config = res));
  }
}
