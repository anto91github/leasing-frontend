import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerFormCompanyComponent } from './customer-form-company.component';

describe('CustomerFormCompanyComponent', () => {
  let component: CustomerFormCompanyComponent;
  let fixture: ComponentFixture<CustomerFormCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerFormCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerFormCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
