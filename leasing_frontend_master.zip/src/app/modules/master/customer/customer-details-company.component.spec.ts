import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDetailsCompanyComponent } from './customer-details-company.component';

describe('CustomerDetailsCompanyComponent', () => {
  let component: CustomerDetailsCompanyComponent;
  let fixture: ComponentFixture<CustomerDetailsCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerDetailsCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerDetailsCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
