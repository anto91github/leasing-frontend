import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerDetailsComponent } from './customer-details.component';
import { CustomerComponent } from './customer.component';
import { CustomerFormComponent } from './customer-form.component';
import { CustomerFormCompanyComponent } from './customer-form-company.component';
import { CustomerDetailsCompanyComponent } from './customer-details-company.component';


const routes: Routes = [
  {
    path: '',
    component: CustomerComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'personal-form',
    component: CustomerFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: 'company-form',
    component: CustomerFormCompanyComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: CustomerFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id/details-personal',
    component: CustomerDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  },
  {
    path: ':id/edit-company',
    component: CustomerFormCompanyComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id/details-company',
    component: CustomerDetailsCompanyComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule {}
