import { Component, OnInit, OnDestroy, Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { fadeIn } from '../../../shared/animations';
import { ApiService } from '../../../core';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  animations: [fadeIn()]
})
@Injectable()
export class CustomerDetailsComponent implements OnInit, OnDestroy {
  row: any = {
    customer_job_data: [],
    customer_emergency_contact: [],
    customer_financial_data: [],
    customer_couple_data: []
  };

  /** KTP */
  ktp_province: any = { province_name: [] };
  ktp_city: any     = { city_name: [] };
  ktp_district: any = { district_name: [] };
  ktp_village: any  = { village_name: [] };

  /** Home */
  home_province: any = { province_name: [] };
  home_city: any     = { city_name: [] };
  home_district: any = { district_name: [] };
  home_village: any  = { village_name: [] };

  /** JOB */
  job_province: any  = { province_name: [] };
  job_city: any      = { city_name: [] };
  job_district: any  = { district_name: [] };
  job_village: any   = { village_name: [] };

  /** Emergency Contact */
  emergency_province: any = { province_name: [] };
  emergency_city: any     = { city_name: [] };
  emergency_district: any = { district_name: [] };
  emergency_village: any  = { village_name: [] };

  /** Couple Contact */
  couple_province: any = { province_name: [] };
  couple_city: any     = { city_name: [] };
  couple_district: any = { district_name: [] };
  couple_village: any  = { village_name: [] };

  valCoupleData: any;

  constructor(
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.route.snapshot.params.id;
    this.apiService.get('customer/personal_data/' + id).subscribe(data => {
      this.row = data;
      /** JOB */
      const JobData = this.row.customer_job_data;
      /** Emergency Contact Data */
      const EmergencyContactData = this.row.customer_emergency_contact;
      /** Couple Data */
      const CoupleData = this.row.customer_couple_data;

      if (CoupleData) {
        this.valCoupleData = true;
      } else {
        this.valCoupleData = false;
      }
    });
  }
  // customer_job_data
  back() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.row = false;
  }
}
