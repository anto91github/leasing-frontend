import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import CustomStore from 'devextreme/data/custom_store';
import { DxDataGridComponent } from 'devextreme-angular';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';

import { ConfigService, ApiService } from '../../../core/services';
import { Master } from '../../../core/models';
import { LocalStorageService } from 'ngx-webstorage';
import { fadeIn } from '../../../shared/animations';
import { NgbModal, NgbModalRef, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss'],
  providers: [TranslateService],
  animations: [fadeIn()]
})
export class CustomerComponent implements OnInit {
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  private route = 'master/customers/';
  public dataSourcePersonal: any = {};
  public dataSourceCompany: any = {};
  private modalRef: NgbModalRef;

  page_view_permission: string;
  page_create_permission: string;
  page_edit_permission: string;
  page_delete_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_create: boolean;
  allow_edit: boolean;
  allow_delete: boolean;
  allow_print: boolean;
  allow_export: boolean;

  isMarried = true;
  closeResult: string;
  cust_type = 1;

  constructor(
    private apiService: ApiService,
    private location: Location,
    private translateService: TranslateService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private config: ConfigService,
    private localSt: LocalStorageService,
    private modalService: NgbModal
  ) {
    this.title = this.translateService.instant('app.customer');
    this.titleCompany = this.translateService.instant('app.customerCompany');
    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'master.customers.view';
    this.page_create_permission = 'master.customers.create';
    this.page_edit_permission = 'master.customers.edit';
    this.page_delete_permission = 'master.customers.delete';
    this.page_print_permission = 'master.customers.print';
    this.page_export_permission = 'master.customers.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
        this.translateService.instant('app.customer')
      );
      this.location.back();
    }

    this.dataSourcePersonal.store = new CustomStore({
      load: function (loadOptions: any) {
        const data = apiService.getAllcustomer('customer/personal_data', loadOptions);
        return data;
      },
      remove: function (row) {
        return apiService
          .delete('customer/personal_data/' + row.id)
          .toPromise()
          .then(
            data => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });

    this.dataSourceCompany.store = new CustomStore({
      load: function (loadOptions: any) {
        const data = apiService.getAllcustomerCompany('customer/company_data', loadOptions);
        return data;
      },
      remove: function (row) {
        return apiService
          .delete('customer/company_data/' + row.id)
          .toPromise()
          .then(
            data => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
  }

  ngOnInit() {
    this.Personal();
   }

  Personal() {
    this.cust_type = 1;
  }

  Company() {
    this.cust_type = 2;
  }

  openModal(content) {
    this.modalRef = this.modalService.open(content, { size: 'sm' });
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
        this.closeResult = `Dismissed ${reason}`;
    });
  }

  closeModal() {
    this.modalRef.close();
  }

  getFormPersonal() {
    this.modalRef.close();
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.router.navigate([this.route, 'personal-form']);
  }

  GetFormCompany() {
    this.modalRef.close();
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.router.navigate([this.route, 'company-form']);
  }


  calculateCellValue(row) {
    return row.first_name + ' ' + row.last_name;
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  // actionAdd() {
  //   if (this.allow_create === false) {
  //     alert(
  //       this.translateService.instant('alert.no_create') +
  //       this.translateService.instant('app.customer')
  //     );
  //     return false;
  //   }
  //   this.router.navigate([this.route, 'create']);
  // }

  /** ACTION CUSTOMER PERSONAL */

  actionDetails(id) {
    this.router.navigate([this.route, id, 'details-personal']);
  }

  actionEdit(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete(row) {
    if (this.allow_delete === false) {
      alert(
        this.translateService.instant('alert.no_delete') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

/** END ACTION CUSTOMER PERSONAL */

/** ACTION CUSTOMER COMPANY */

  actionDetailsCompany(id) {
    this.router.navigate([this.route, id, 'details-company']);
  }

  actionEditCompany(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit-company']);
  }

  actionDeleteCompany(row) {
    if (this.allow_delete === false) {
      alert(
        this.translateService.instant('alert.no_delete') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

/** END ACTION CUSTOMER COMPANY */


 actionPDFCompany() {
  //  alert('COmpany');
   if (this.allow_print === false) {
    alert(
      this.translateService.instant('alert.no_print') +
      this.translateService.instant('app.company')
    );
    return false;
  }
  const columns = [
    { title: 'No', dataKey: 'no' },
    { title: this.translateService.instant('app.company_name'), dataKey: 'company_name' },
    // { title: this.translateService.instant('app.company_type'), dataKey: 'company_type' },
    { title: this.translateService.instant('app.company_address'), dataKey: 'company_address' },
    { title: this.translateService.instant('app.phone'), dataKey: 'phone' },
    { title: this.translateService.instant('app.email'), dataKey: 'email' },
    { title: this.translateService.instant('app.fax'), dataKey: 'fax' },
    { title: this.translateService.instant('app.web'), dataKey: 'website' }
  ];
  const rows = [];

  this.apiService.get('customer/company_data').subscribe(
    (success: any) => {
      const items = success.content;
      for (let i = 0; i < items.length; i++) {
        rows.push({
          no: `${i + 1}.`,
          company_name: items[i].company_name,
          // company_type: items[i].company_type,
          company_address: items[i].company_address,
          phone: items[i].phone,
          email: items[i].email,
          fax: items[i].fax,
          website: items[i].website
        });
      }

      // Only pt supported (not mm or in)
      const doc = new jsPDF('l', 'pt');
      doc.autoTable(columns, rows, {
        addPageContent: function (data) {
          doc.text('Customer Company', 40, 40);
        },
        margin: { top: 60 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 7 },
        columnStyles: { text: { columnWidth: 'auto' } }
      });
      window.open(doc.output('bloburl'));
    },
    error => {
      console.log(error);
    }
  );
 }

  actionExcelCompany() {
    // alert('EXel Comapny');
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
        this.translateService.instant('app.company')
      );
      return false;
    }
    this.apiService.get('customer/company_data').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.company_name')]: el.company_name,
            [this.translateService.instant('app.company_address')]: el.company_address,
            [this.translateService.instant('app.phone')]: el.phone,
            [this.translateService.instant('app.email')]: el.email,
            [this.translateService.instant('app.fax')]: el.fax,
            [this.translateService.instant('app.web')]: el.website
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.titleCompany);
        XLSX.writeFile(wb, `${this.titleCompany}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }
  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    this.apiService.get('customer/personal_data').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.fullname')]: el.first_name + ' ' + el.last_name,
            [this.translateService.instant('app.customer_gender')]: el.customer_gender,
            [this.translateService.instant('app.ktp_address')]: el.ktp_address,
            [this.translateService.instant('app.email')]: el.email,
            [this.translateService.instant('app.phone')]: el.phone,
            [this.translateService.instant('app.ktp_number')]: el.ktp_number,
            [this.translateService.instant('app.birth_date')]: el.birth_date
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
        this.translateService.instant('app.customer')
      );
      return false;
    }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.fullname'), dataKey: 'fullname' },
      { title: this.translateService.instant('app.customer_gender'), dataKey: 'customer_gender' },
      { title: this.translateService.instant('app.ktp_address'), dataKey: 'ktp_address' },
      { title: this.translateService.instant('app.email'), dataKey: 'email' },
      { title: this.translateService.instant('app.phone'), dataKey: 'phone' },
      { title: this.translateService.instant('app.ktp_number'), dataKey: 'ktp_number' },
      { title: this.translateService.instant('app.birth_date'), dataKey: 'birth_date' }
    ];
    const rows = [];

    this.apiService.get('customer/personal_data').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            fullname: items[i].first_name + ' ' + items[i].last_name,
            customer_gender: items[i].customer_gender,
            ktp_address: items[i].ktp_address,
            phone: items[i].phone,
            email: items[i].email,
            ktp_number: items[i].ktp_number,
            birth_date: items[i].birth_date
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('l', 'pt');
        doc.autoTable(columns, rows, {
          addPageContent: function (data) {
            doc.text('Customer', 40, 30);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }
}
