import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl,
  FormArray
} from '@angular/forms';
import { FlashMessagesService } from 'angular2-flash-messages';
import { fadeIn } from '../../../shared/animations';
import { map, mergeMap, concatMap, delay } from 'rxjs/operators';
import { ApiService, Master, Product } from '../../../core';

@Component({
  selector: 'app-customer-form-company',
  templateUrl: './customer-form-company.component.html',
  styleUrls: ['./customer-form-company.component.scss'],
  animations: [fadeIn()]
})
export class CustomerFormCompanyComponent implements OnInit {
  [x: string]: any;
  form: FormGroup;
  items: FormArray;

  company_status = [
    { id: 'TERTUTUP', name: 'TERTUTUP' },
    { id: 'TERBUKA', name: 'TERBUKA' }
  ];

  company_type = [
    { id: 'PERUSAHAAN_PERORANGAN', name: 'PERUSAHAAN PERORANGAN' },
    { id: 'FIRMA', name: 'FIRMA' },
    { id: 'PERSEROAN_KOMANDITER', name: 'PERSEROAN KOMANDITER' },
    { id: 'PERUSAHAAN_UMUM', name: 'PERUSAHAAN UMUM' },
    { id: 'KOPERASI', name: 'KOPERASI' },
    { id: 'YAYASAN', name: 'YAYASAN' },
    { id: 'BUMN', name: 'BUMN' },
    { id: 'PEMERINTAHAN', name: 'PEMERINTAHAN' }
  ];

  province = [];
  city_collection = [];
  city = [];
  district = [];
  village = [];
  certificate_date_new: any;
  @ViewChild('d')
  datePicker;

  constructor(
    private location: Location,
    private route: ActivatedRoute,
    private router: Router,
    private formbuilder: FormBuilder,
    private flashMessage: FlashMessagesService,
    private apiService: ApiService
  ) { }

  ngOnInit() {
    this.LoadProvince();

    this.form = this.formbuilder.group({
      company_name: new FormControl('', {
        validators: Validators.required
      }),
      company_type: new FormControl('', {
        validators: Validators.required
      }),
      company_status: new FormControl('', {
        validators: Validators.required
      }),
      director: new FormControl('', {
        validators: Validators.required
      }),
      npwp: new FormControl('', {
        validators: Validators.required
      }),
      siup: new FormControl('', {
        validators: Validators.required
      }),
      tdp: new FormControl('', {
        validators: Validators.required
      }),
      domicile: new FormControl('', {
        validators: Validators.required
      }),
      notarial_certificate: new FormControl('', {
        validators: Validators.required
      }),
      certificate_date: new FormControl('', {
        validators: Validators.required
      }),
      phone: new FormControl('', {
        validators: Validators.required
      }),
      fax: new FormControl('', {
        validators: Validators.required
      }),
      email: new FormControl('', {
        validators: [Validators.email, Validators.maxLength(50), Validators.required]
      }),
      website: new FormControl('', {
        validators: Validators.required
      }),
      company_address: new FormControl('', {
        validators: Validators.required
      }),
      postal_code: new FormControl('', {
        validators: Validators.required
      }),
      province: new FormControl('', {
        validators: Validators.required
      }),
      city: new FormControl('', {
        validators: Validators.required
      }),
      district: new FormControl('', {
        validators: Validators.required
      }),
      village: new FormControl('', {
        validators: Validators.required
      })
    },
      { updateOn: 'blur' });

    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      // this.title = this.id ? 'sys.edit' : 'sys.add';
      if (!this.id) {
        return;
      }
      this.apiService.get('customer/company_data/' + this.id).subscribe((data: any) => {
        this.certificate_date_new    = data.certificate_date;
        const certificate_date_Split = data.certificate_date.split('-');
        const DateNew = {
          day: parseInt(certificate_date_Split[2], 0),
          month: parseInt(certificate_date_Split[1], 0),
          year: parseInt(certificate_date_Split[0], 0)
        };

        this.form.patchValue(
          {
            company_name: data.company_name,
            company_type: data.company_type,
            company_status: data.company_status,
            npwp: data.npwp,
            siup: data.siup,
            tdp: data.tdp,
            domicile: data.domicile,
            notarial_certificate: data.notarial_certificate,
            certificate_date: DateNew,
            director: data.director,
            company_address: data.company_address,
            province: data.province,
            city: data.city,
            district: data.district,
            village: data.village,
            postal_code: data.postal_code,
            phone: data.phone,
            fax: data.fax,
            email: data.email,
            website: data.website
          }
        );
      });
    });
  }

  private async LoadProvince(): Promise<any> {
   await this.apiService
      .get('area/province/data')
      .pipe(delay(100))
      .subscribe((data: any) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              province_name: el.province_name,
              city_collection: el.city_collection,
              code: el.code,
              status: el.status
            });
        });
        this.province = [...items];
      });
  }

  changeProvince(event) {
    this.apiService.get('area/province/' + event.id).subscribe((data: any) => {
      const items = [];
      data.city_collection.forEach(el => {
          items.push(
            {
              id: el.id,
              city_name: el.city_name,
              city_collection: el.city_collection,
              code: el.code,
              status: el.status
            });
        });
      this.city = [...items];
      this.form.get('city').patchValue('');
      this.form.get('district').patchValue('');
      this.form.get('village').patchValue('');
    });
  }

  changeCity(event) {
    this.apiService.get('area/city/' + event.id).subscribe((data: any) => {
      const items = [];
      data.district_collection.forEach(el => {
        items.push(
          {
            id: el.id,
            district_name: el.district_name,
            district_collection: el.district_collection,
            code: el.code,
            status: el.status
          });
      });
      this.district = [...items];
      this.form.get('district').patchValue('');
    });
  }

  changeDistrict(event) {
    this.apiService.get('area/district/' + event.id).subscribe((data: any) => {
      const items = [];
      data.village_collection.forEach(el => {
        items.push(
          {
            id: el.id,
            village_name: el.village_name,
            village_collection: el.village_collection,
            code: el.code,
            status: el.status
          });
      });
      this.village = [...items];
      this.form.get('village').patchValue('');
    });
  }

  updateDate(param, ev) {
    if (param === 'certificate_date') {
      this.certificate_date_new = ev.year + '-' + ('0' + ev.month).substr(-2) + '-' + ('0' + ev.day).substr(-2);
    }
    this.form.get(param).patchValue({ year: ev.year, month: ev.month, day: ev.day });
  }

  back() {
    this.location.back();
  }

  save() {
    const form_value = {
      certificate_date: this.certificate_date_new,
      city: this.form.value.city,
      company_address: this.form.value.company_address,
      company_name: this.form.value.company_name,
      company_status: this.form.value.company_status,
      company_type: this.form.value.company_type,
      director: this.form.value.director,
      district: this.form.value.district,
      domicile: this.form.value.domicile,
      email: this.form.value.email,
      fax: this.form.value.fax,
      notarial_certificate: this.form.value.notarial_certificate,
      npwp: this.form.value.npwp,
      phone: this.form.value.phone,
      postal_code: this.form.value.postal_code,
      province: this.form.value.province,
      siup: this.form.value.siup,
      tdp: this.form.value.tdp,
      village: this.form.value.village,
      website: this.form.value.website
    };

    if (this.form.valid) {
      if (!this.id) {
        console.log(form_value);
        this.apiService.post('customer/company_data/', form_value).subscribe(
          success => {
            console.log(success);
          },
          error => {
            console.log(error);
          }
        );
        this.router.navigate(['master/customers']);
      } else {
        /** PUT */
        this.apiService.put('customer/company_data/' + this.id, form_value).subscribe(
          success => {
            console.log(success);
          },
          error => {
            console.log(error);
          }
        );
        this.router.navigate(['master/customers']);
      }
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
