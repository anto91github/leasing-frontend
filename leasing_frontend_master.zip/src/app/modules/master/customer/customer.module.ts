import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { DxDataGridModule } from 'devextreme-angular';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from '../customer/customer.component';
import { CustomerDetailsComponent } from '../customer/customer-details.component';
import { CustomerFormComponent } from './customer-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';
import { MaskModule } from 'soft-angular-mask';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask/src/currency-mask.config';
import * as $ from 'jquery';
import { CustomerFormCompanyComponent } from './customer-form-company.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomerDetailsCompanyComponent } from './customer-details-company.component';


/** Setting Currency Monney */
export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: 'left',
  allowNegative: true,
  decimal: ',',
  precision: 0,
  prefix: '',
  suffix: '',
  thousands: '.'
};

@NgModule({
  imports: [
    CommonModule,
    CustomerRoutingModule,
    NgbModule,
    DxDataGridModule,
    MaskModule,
    CurrencyMaskModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    FroalaEditorModule.forRoot(),
    FroalaViewModule.forRoot(),
    FlashMessagesModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [
  CustomerComponent,
  CustomerDetailsComponent,
  CustomerFormComponent,
  CustomerFormCompanyComponent,
  CustomerFormCompanyComponent,
  CustomerDetailsCompanyComponent
],
  providers: [
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ],
})
export class CustomerModule {}
