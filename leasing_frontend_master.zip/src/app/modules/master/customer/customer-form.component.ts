import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Renderer,
  ViewChildren,
  QueryList,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl,
  FormArray
} from '@angular/forms';
import { map, mergeMap, concatMap, delay } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

import { FlashMessagesService } from 'angular2-flash-messages';
import { NgbDatepicker, NgbDateStruct, NgbAccordion } from '@ng-bootstrap/ng-bootstrap';
import { ApiService, Attachment } from '../../../core';
import * as $ from 'jquery';
import form from 'devextreme/ui/form';
import { TranslateService } from '@ngx-translate/core';
// import { Mask } from '@fagnerlima/ng-mask';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.scss'],
// tslint:disable-next-line: use-host-property-decorator
  host: {
    '(document:click)': 'onClick($event)'
  }
})
export class CustomerFormComponent implements OnInit {
/* tslint:disable */
  [x: string]: any;
  types = [
    { id: 'AUTHORIZED', name: 'Authorized' },
    { id: 'NON-AUTHORIZED', name: 'Non Authorized' }
  ];
  gender = [{ id: 'MALE', name: 'Male' }, { id: 'FEMALE', name: 'Female' }];
  marital_status = [
    { id: 'MARRIED', name: 'Married' },
    { id: 'SINGLE', name: 'Single' },
    { id: 'WIDOW', name: 'Widow' }
  ];
  home_status = [
    { id: 'OWN', name: 'Own' },
    { id: 'FAMILY', name: 'Family' },
    { id: 'RENT', name: 'Rent' },
    { id: 'COMPANY', name: 'Company' },
    { id: 'OTHER', name: 'Other' }
  ];
  job = [
    { id: 'BUSINESS', name: 'Business' },
    { id: 'EMPLOYEE', name: 'Employee' },
    { id: 'PROFESSIONAL', name: 'Professional' },
    { id: 'STUDENT', name: 'Student' },
    { id: 'OTHER', name: 'Other' }
  ];
  education_level = [
    { id: 'AKADEMI', name: 'AKADEMI' },
    { id: 'SD', name: 'SD' },
    { id: 'SMP', name: 'SMP' },
    { id: 'SMU', name: 'SMU' },
    { id: 'S1', name: 'S1' },
    { id: 'S2', name: 'S2' },
    { id: 'S3', name: 'S3' }
  ];
  att_title = [
    { id: 'AKTA NIKAH', name: 'AKTA NIKAH' },
    { id: 'KK', name: 'KK' },
    { id: 'KTP', name: 'KTP' },
    { id: 'NPWP', name: 'NPWP' },
    { id: 'PBB', name: 'PBB' },
    { id: 'PHOTOGRAPH', name: 'PHOTOGRAPH' },
    { id: 'REK KORAN', name: 'REK KORAN' }
  ];

  province = [];
  city_collection = [];
  city = [];
  district = [];
  village = [];

  // ktp_address_city=[];
  att_filename: string;
  @ViewChild('d')
  datePicker;
  @ViewChild('c')
  datePicker2;
  form: FormGroup;
  couple_data: FormGroup;
  myForm: FormGroup;
  row: any = [];
  id: number = null;
  idCouple: any;
  idEmergencyContact: number = null;
  idJob: number = null;
  idFinancial: number = null;
  idAttach: number = null;
  title: string;
  model_birth_date: NgbDateStruct;
  hidden = '';
  isMarried = true;
  newData: any = [];

  value_couple_data: any;
  value_job_data: any;
  value_financial_data: any;
  value_emergency_data: any;

  birth_date_personalData: any;
  birth_date_coupleData: any;
  birth_date_jobDataEstFrom: any;
  birth_date_jobDataWorkSince: any;

  img_src = 'assets/img/no-image.png';
  img_attachment = [];
  url = [];
  img_added = false;
  @ViewChildren('file_attachment') file_attachment: QueryList<ElementRef>;

  @ViewChild('ktp_address') ktp_address: ElementRef;
  @ViewChild('ktp_address_rt') ktp_address_rt: ElementRef;
  @ViewChild('ktp_address_rw') ktp_address_rw: ElementRef;

  @ViewChild('coupleFirstName') coupleFirstName: ElementRef;

  constructor(
    private location: Location,
    private apiService: ApiService,
    private router: Router,
    private flashMessage: FlashMessagesService,
    private route: ActivatedRoute,
    private renderer: Renderer,
    private formbuilder: FormBuilder,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.LoadProvince();
    // get province
    this.apiService.get('area/province/data?page=0&size=40').subscribe((data: any) => {
      this.ktp_address_province = data.content;
      this.home_address_province = data.content;
      this.customer_job_data_province = data.content;
      this.customer_couple_data_ktp_address_province = data.content;
      this.customer_emergency_contact_address_province = data.content;
    });
    /** Start Form */
    /** Personal Data */
  this.form = this.formbuilder.group(
      {
        first_name: new FormControl('', {
          validators: [
            Validators.required,
            Validators.maxLength(50),
            // Validators.pattern("[a-zA-Z-/./,/']*")
          ]
        }),
        last_name: new FormControl('', {
          validators: [
            Validators.required,
            Validators.maxLength(50),
            // Validators.pattern("[a-zA-Z-/./,/']*")
          ]
        }),
        customer_gender: new FormControl('', {
          validators: Validators.required
        }),
        marital_status: new FormControl('', {
          validators: [Validators.required]
        }),
        ktp_number: new FormControl('', {
          validators: [Validators.maxLength(16), Validators.required]
        }),
        kk_number: new FormControl('', {
          validators: [Validators.maxLength(16), Validators.required]
        }),
        passport_number: new FormControl('', {
          validators: [
            // Validators.required,
            Validators.maxLength(10),
            Validators.pattern('[0-9a-zA-Z]*')
          ]
        }),
        npwp_number: new FormControl('', {
          validators: [Validators.maxLength(20), Validators.required]
        }),
        place_birth: new FormControl('', {
          validators: [Validators.maxLength(50), Validators.required]
        }),
        birth_date: new FormControl('', {
          validators: Validators.required
        }),
        ktp_address: new FormControl('', {
          validators: [Validators.maxLength(100), Validators.required]
        }),
        ktp_address_rt: new FormControl('', {
          validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
        }),
        ktp_address_rw: new FormControl('', {
          validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
        }),
        ktp_address_province: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        ktp_address_city: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        ktp_address_district: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        ktp_address_village: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        ktp_address_postal_code: new FormControl('', {
          validators: [Validators.maxLength(5), Validators.required]
        }),
        home_address: new FormControl('', {
          validators: [Validators.maxLength(100)]
        }),
        home_address_rt: new FormControl('', {
          validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
        }),
        home_address_rw: new FormControl('', {
          validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
        }),
        home_address_province: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        home_address_city: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        home_address_district: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        home_address_village: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        home_status: new FormControl('', {}),
        phone: new FormControl('', {
          validators: [Validators.maxLength(20), Validators.pattern('[0-9]*')]
        }),
        mobile: new FormControl('', {
          validators: [Validators.maxLength(20), Validators.pattern('[0-9]*'), Validators.required]
        }),
        email: new FormControl('', {
          validators: [Validators.email, Validators.maxLength(50)]
        }),
        mothers_maiden_name: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        education_level: new FormControl('', {}),
        citizenship: new FormControl('', {
          validators: [Validators.maxLength(50)]
        }),
        number_of_dependents: new FormControl('', {
          validators: [Validators.maxLength(2), Validators.pattern('[0-9]*')]
        }),
        /** END Personal Data */

        /** Couple Data */
        customer_couple_data: new FormGroup({
          customer_couple_data_birth_date: new FormControl('', {}),
          customer_couple_data_couple_job: new FormControl('', {}),
          customer_couple_data_first_name: new FormControl('', {
            validators: [
              Validators.maxLength(50),
              Validators.pattern('[a-zA-Z-/./,/\']*')
            ]
          }),
          customer_couple_data_kk_number: new FormControl('', {
            validators: [Validators.maxLength(16)]
          }),
          customer_couple_data_ktp_address: new FormControl('', {
            validators: [Validators.maxLength(100)]
          }),
          customer_couple_data_ktp_address_city: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_couple_data_ktp_address_district: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_couple_data_ktp_address_postal_code: new FormControl('', {
            validators: [
              Validators.maxLength(5),
              Validators.pattern('[0-9]*')
            ]
          }),
          customer_couple_data_ktp_address_province: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_couple_data_ktp_address_rt: new FormControl('', {
            validators: [
              Validators.maxLength(3),
              Validators.pattern('[0-9]*')
            ]
          }),
          customer_couple_data_ktp_address_rw: new FormControl('', {
            validators: [
              Validators.maxLength(3),
              Validators.pattern('[0-9]*')
            ]
          }),
          customer_couple_data_ktp_address_village: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_couple_data_ktp_number: new FormControl('', {
            validators: [Validators.maxLength(16)]
          }),
          customer_couple_data_last_name: new FormControl('', {
            validators: [
              Validators.maxLength(50),
              Validators.pattern('[a-zA-Z-/./,/\']*')
            ]
          }),
          customer_couple_data_passport_number: new FormControl('', {
            validators: [
              Validators.maxLength(10),
              Validators.pattern('[0-9a-zA-Z]*')
            ]
          }),
          customer_couple_data_phone: new FormControl('', {
            validators: [Validators.maxLength(20)]
          }),
          customer_couple_data_mobile: new FormControl('', {
            validators: [Validators.maxLength(20)]
          }),
          customer_couple_data_place_birth: new FormControl('', {
            validators: [Validators.maxLength(50)]
          })
        }),
        /** END Couple Data */

        /** Job Data */
        customer_job_data: new FormGroup({
          customer_job_data_company_name: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_job: new FormControl('', {}),
          customer_job_data_est_from: new FormControl('', {}),
          customer_job_data_address: new FormControl('', { validators: [Validators.maxLength(100)] }),
          customer_job_data_phone: new FormControl('', { validators: [Validators.maxLength(20)] }),
          customer_job_data_fax: new FormControl('', {
            validators: [
              Validators.maxLength(20),
              Validators.pattern('[0-9]*')
            ]
          }),
          customer_job_data_email: new FormControl('', {
            validators: [Validators.email, Validators.maxLength(50)]
          }),
          customer_job_data_province: new FormControl('', {validators: [Validators.maxLength(50)] }),
          customer_job_data_city: new FormControl('', { validators: [Validators.maxLength(50)] }),
          customer_job_data_district: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_village: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_web: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_business_type: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_position: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_job_data_work_since: new FormControl('', {})
        }),
        /** END Job Data */

        /** Financial Data */
        customer_financial_data: new FormGroup({
          customer_financial_data_fixed_income: new FormControl('', {
            validators: [Validators.maxLength(18), Validators.required]
          }),
          customer_financial_data_couple_income: new FormControl('', {
            validators: [Validators.maxLength(18)]
          }),
          customer_financial_data_other_income: new FormControl('', {
            validators: [Validators.maxLength(18)]
          }),
          customer_financial_data_spending: new FormControl('', {
            validators: [Validators.maxLength(18)]
          })
        }),
        /** END Financial Data */

        /** Emergency Cantact Data */
        customer_emergency_contact: new FormGroup({
          customer_emergency_contact_first_name: new FormControl('', {
            validators: [
              Validators.maxLength(50),
              Validators.pattern('[a-zA-Z-/./,/\']*')
            ]
          }),
          customer_emergency_contact_last_name: new FormControl('', {
            validators: [
              Validators.maxLength(50),
              Validators.pattern('[a-zA-Z-/./,/\']*')
            ]
          }),
          customer_emergency_contact_phone: new FormControl('', {
            validators: [Validators.maxLength(20)]
          }),
          customer_emergency_contact_mobile: new FormControl('', {
            validators: [Validators.maxLength(20)]
          }),
          customer_emergency_contact_relationship: new FormControl('', {
            validators: [
              Validators.maxLength(30),
              Validators.pattern('[a-zA-Z]*')
            ]
          }),
          customer_emergency_contact_address_postal_code: new FormControl('', {
            validators: [Validators.maxLength(5), Validators.pattern('[0-9]*')]
          }),
          customer_emergency_contact_address: new FormControl('', {
            validators: [Validators.maxLength(100)]
          }),
          customer_emergency_contact_address_rt: new FormControl('', {
            validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
          }),
          customer_emergency_contact_address_rw: new FormControl('', {
            validators: [Validators.maxLength(3), Validators.pattern('[0-9]*')]
          }),
          customer_emergency_contact_address_province: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_emergency_contact_address_city: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_emergency_contact_address_district: new FormControl('', {
            validators: [Validators.maxLength(50)]
          }),
          customer_emergency_contact_address_village: new FormControl('', {
            validators: [Validators.maxLength(50)]
          })
        }) /** END Emergency Cantact Data */,

        /** Attachment File */
        attachments: this.formbuilder.array([]),
        /** END Attachment File */
      },
      {
        updateOn: 'blur'
      }
    );
    /** END Form */

    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      // console.log(this.id);
      this.title = this.id ? 'sys.edit' : 'sys.add';
      if (!this.id) {
        return this.addAttachments();
      }
      this.apiService.get('customer/personal_data/' + this.id).subscribe((data: any) => {
        // console.log(data);
        this.isMarried = data.marital_status === 'MARRIED' ? true : false;
        this._status = data.marital_status;
        if (data) {
          this.row = data;
          const personalData_birthdate  =  data.birth_date.split('-');
          this.birth_date_personalData = personalData_birthdate[0] + '-' + personalData_birthdate[1] + '-' + personalData_birthdate[2];

          /** Personal Data */
          for (const key in data) {
            if (data.hasOwnProperty(key)) {
              switch (key) {
                case 'birth_date':
                  const tgl = data[key].split('-');
                  this.row.birth_date = {
                    day: parseInt(tgl[2], 0),
                    month: parseInt(tgl[1], 0),
                    year: parseInt(tgl[0], 0)
                  };
                  this.form.get(key).patchValue({
                    day: parseInt(tgl[2], 0),
                    month: parseInt(tgl[1], 0),
                    year: parseInt(tgl[0], 0)
                  });
                  break;
                case 'ktp_address_province':
                  this.form.get('ktp_address_province').patchValue(data.ktp_address_province);
                  break;
                case 'ktp_address_city':
                  this.form.get('ktp_address_city').patchValue(data.ktp_address_city);
                  break;
                case 'ktp_address_district':
                  this.form.get('ktp_address_district').patchValue(data.ktp_address_district);
                  break;
                case 'ktp_address_village':
                  this.form.get('ktp_address_village').patchValue(data.ktp_address_village);
                  break;
                case 'home_address_province':
                  this.form.get('home_address_province').patchValue(data.home_address_province);
                  break;
                case 'home_address_city':
                  this.form.get('home_address_city').patchValue(data.home_address_city);
                  break;
                case 'home_address_district':
                  this.form.get('home_address_district').patchValue(data.home_address_district);
                  break;
                case 'home_address_village':
                  this.form.get('home_address_village').patchValue(data.home_address_village);
                  break;
                default:
                  this.row[data + key] = data[key];
                  break;
              }
            }
          }
          /** END Personal Data */
        }
        if (data.customer_couple_data) {
          this.idCouple = data.customer_couple_data.id;
          const coupleData_birthdate = data.customer_couple_data.birth_date.split('-');
          this.birth_date_coupleData = coupleData_birthdate[0] + '-' + coupleData_birthdate[1] + '-' + coupleData_birthdate[2];

          /** Couple Data */
          for (const key in data.customer_couple_data) {
            if (data.customer_couple_data.hasOwnProperty(key)) {
              if (key === 'birth_date') {
                const tgl = data.customer_couple_data[key].substr(0, 10).split('-');
                this.row.customer_couple_data_birth_date = {
                  day: parseInt(tgl[2], 0),
                  month: parseInt(tgl[1], 0),
                  year: parseInt(tgl[0], 0)
                };
                this.form.get('customer_couple_data.customer_couple_data_birth_date').patchValue({
                  day: parseInt(tgl[2], 0),
                  month: parseInt(tgl[1], 0),
                  year: parseInt(tgl[0], 0)
                });
              } else if (key === 'ktp_address_province') {
                this.form.get('customer_couple_data.customer_couple_data_ktp_address_province').patchValue(data.customer_couple_data[key]);
                this.row['customer_couple_data_' + key] = data.customer_couple_data[key];
              } else if (key === 'ktp_address_city') {
                this.form.get('customer_couple_data.customer_couple_data_ktp_address_city').patchValue(data.customer_couple_data[key]);
                this.row['customer_couple_data_' + key] = data.customer_couple_data[key];
              } else {
                if (this.form.get('customer_couple_data.customer_couple_data_' + key)) {
                  this.form
                    .get('customer_couple_data.customer_couple_data_' + key)
                    .patchValue(data.customer_couple_data[key]);
                  this.row['customer_couple_data_' + key] = data.customer_couple_data[key];
                }
              }
              // console.log('customer_couple_data', key, data.customer_couple_data[key]);
            }
          }
          /** END Couple Data */
        }
        if (data.customer_emergency_contact) {
          this.idEmergencyContact = data.customer_emergency_contact.id;
        }
        if (data.customer_job_data) {
          this.idJob = data.customer_job_data.id;

          this.birth_date_jobDataEstFrom = data.customer_job_data.est_from;
          this.birth_date_jobDataWorkSince = data.customer_job_data.work_since;
          /** Job Data */
          for (const key in data.customer_job_data) {
            if (data.customer_job_data.hasOwnProperty(key)) {
              switch (key) {
                case 'est_from':
                  if (data.customer_job_data[key] !== null) {
                    const tgl = data.customer_job_data[key].split('-');
                    this.row.customer_job_data_est_from = {
                      day: parseInt(tgl[2], 0),
                      month: parseInt(tgl[1], 0),
                      year: parseInt(tgl[0], 0)
                    };
                    this.form.get('customer_job_data.customer_job_data_est_from').patchValue({
                      day: parseInt(tgl[2], 0),
                      month: parseInt(tgl[1], 0),
                      year: parseInt(tgl[0], 0)
                    });
                  }
                  break;
                case 'work_since':
                if (data.customer_job_data[key] !== null){
                  const tgl = data.customer_job_data[key].substr(0, 10).split('-');
                  this.row.customer_job_data_work_since = {
                    day: parseInt(tgl[2], 0),
                    month: parseInt(tgl[1], 0),
                    year: parseInt(tgl[0], 0)
                  };
                  this.form.get('customer_job_data.customer_job_data_work_since').patchValue({
                    day: parseInt(tgl[2], 0),
                    month: parseInt(tgl[1], 0),
                    year: parseInt(tgl[0], 0)
                  });
                }
                break
              }

              if (key === 'province') {
                this.form.get('customer_job_data.customer_job_data_province').patchValue(data.customer_job_data[key]);
                this.row['customer_job_data_' + key] = data.customer_job_data[key];
              } else if (key === 'city') {
                this.form.get('customer_job_data.customer_job_data_city').patchValue(data.customer_job_data[key]);
                this.row['customer_job_data_' + key] = data.customer_job_data[key];
              } else if (key === 'district') {
                this.form.get('customer_job_data.customer_job_data_district').patchValue(data.customer_job_data[key]);
                this.row['customer_job_data_' + key] = data.customer_job_data[key];
              } else if (key === 'village') {
                this.form.get('customer_job_data.customer_job_data_village').patchValue(data.customer_job_data[key]);
                this.row['customer_job_data_' + key] = data.customer_job_data[key];
              } else {
                if (this.form.get('customer_job_data.customer_job_data_' + key)) {
                  this.form
                    .get('customer_job_data.customer_job_data_' + key)
                    .patchValue(data.customer_job_data[key]);
                  this.row['customer_job_data_' + key] = data.customer_job_data[key];
                }
              }
              // console.log('customer_job_data', key, data.customer_job_data[key]);
            }
          }
        }
        if (data.customer_financial_data) {
          this.idFinancial = data.customer_financial_data.id;
        }
        if (data.attachments) {
          this.idAttach = data.attachments;
        }

        /** Financial Data */
        for (const key in data.customer_financial_data) {
          if (data.customer_financial_data.hasOwnProperty(key)) {
            if (this.form.get('customer_financial_data.customer_financial_data_' + key)) {
              this.row['customer_financial_data_' + key] = data.customer_financial_data[key];
              this.form
                .get('customer_financial_data.customer_financial_data_' + key)
                .patchValue(data.customer_financial_data[key]);
              // console.log('customer_financial_data', key, data.customer_financial_data[key]);
            }
          }
        }
        /** END Financial Data */

        /** Emergency Contact */
        for (const key in data.customer_emergency_contact) {
          if (data.customer_emergency_contact.hasOwnProperty(key)) {
            if (this.form.get('customer_emergency_contact.customer_emergency_contact_' + key)) {
              this.row['customer_emergency_contact_' + key] = data.customer_emergency_contact[key];
              this.form
                .get('customer_emergency_contact.customer_emergency_contact_' + key)
                .patchValue(data.customer_emergency_contact[key]);
              // console.log('customer_emergency_contact', key, data.customer_emergency_contact[key]);
            }
          }
        }
        /** END Emergency Contact */

        /** Attachment */
        data.attachments.forEach(i => {
          const updatedataAttach = this.formbuilder.group({
            att_title: [i.att_title],
            att_description: [i.att_description],
            att_file: [i.att_file],
            file_type: [i.file_type]
          });
          this.attachments.push(updatedataAttach);

          switch (i.file_type) {
            case 'jpeg' || 'jpg':
              this.url.push(i.att_file);
            break;
            case 'png':
              this.url.push(i.att_file);
            break;
            case 'pdf':
              this.url.push('assets/img/pdf.png');
            break;
            case 'vnd.openxmlformats-officedocument.spreadsheetml.sheet':
              this.url.push('assets/img/xls.png');
            break;
            case 'plain':
              this.url.push('assets/img/txt.png');
            break;
            case 'vnd.ms-excel':
              this.url.push('assets/img/csv.png');
            break;
            case 'msword':
              this.url.push('assets/img/doc.png');
            break;
            case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
              this.url.push('assets/img/doc.png');
              break;
            default:
              this.url.push(i.att_file);
            break;
          }
        });
        /** END Attachment */
      });
    });
  } /** END ngOnInit */

  /** Attachments Handle Data */
  preview(event, i) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        this.img_src = e.target.result;
        this.img_added = true;
        const split_url = file.type.split('/');

        switch (split_url[1]) {
          case 'jpeg' || 'jpg':
            this.url[i] = e.target.result;
            break;
          case 'png':
            this.url[i] = e.target.result;
            break;
          case 'pdf':
            this.url[i] = 'assets/img/pdf.png';
            break;
          case 'vnd.openxmlformats-officedocument.spreadsheetml.sheet':
            this.url[i] = 'assets/img/xls.png';
            break;
          case 'plain':
            this.url[i] = 'assets/img/txt.png';
            break;
          case 'vnd.ms-excel':
            this.url[i] = 'assets/img/csv.png';
            break;
          case 'msword':
            this.url[i] = 'assets/img/doc.png';
            break;
          case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
            this.url[i] = 'assets/img/doc.png';
            break;
          default:
            this.url[i] = e.target.result;
            break;
        }
      };
    }
  }

  addAttachments() {
    const length = this.attachments.controls.length;
    const attach = this.formbuilder.group({
      att_title: [],
      att_description: [],
      att_file: [],
      file_type: []
    });
    this.attachments.push(attach);
    this.url[(length - 0)] = 'assets/img/no-images.png';
  }

  removeAttachments(i) {
    if (i === 0) {
      return;
    } else {
      const control = (<FormArray>this.form.controls['attachments']);
      control.removeAt(i);
      this.url.splice(i, 1);
      // this.url.splice(i);
      // this.img_attachment.splice(length[i]);
    }
  }

  get attachments() {
    return this.form.get('attachments') as FormArray;
  }
  /** End Attachments Handle Data */

  updateDate(param, ev) {
    if (param === 'birth_date') {
      this.birth_date_personalData = ev.year + '-' + ('0' + ev.month).substr(-2) + '-' + ('0' + ev.day).substr(-2);
    }
    if (param === 'customer_couple_data.customer_couple_data_birth_date') {
      this.birth_date_coupleData = ev.year + '-' + ('0' + ev.month).substr(-2) + '-' + ('0' + ev.day).substr(-2);
    }
    if (param === 'customer_job_data.customer_job_data_est_from') {
      this.birth_date_jobDataEstFrom = ev.year + '-' + ('0' + ev.month).substr(-2) + '-' + ('0' + ev.day).substr(-2);
    }
    if (param === 'customer_job_data.customer_job_data_work_since') {
      this.birth_date_jobDataWorkSince = ev.year + '-' + ('0' + ev.month).substr(-2) + '-' + ('0' + ev.day).substr(-2);
    }
    this.form.get(param).patchValue({ year: ev.year, month: ev.month, day: ev.day });
  }

  async save() {
    const personalData = this.form.value;
    const coupleData = this.form.value.customer_couple_data;
    const jobData = this.form.value.customer_job_data;
    const finacialData = this.form.value.customer_financial_data;
    const emergencyContact = this.form.value.customer_emergency_contact;
    const attachfile = this.form.value.attachments;

    /** Personal Data Change Format Birth Date */
    const birthdate = personalData.birth_date;
    if (birthdate) {
      personalData.birth_date =
        birthdate['year'] +
        '-' +
        ('0' + birthdate['month']).substr(-2) +
        '-' +
        ('0' + birthdate['day']).substr(-2);
    /** END Personal Data Change Format Birth Date */
    }

    /** Couple Data Change Format Birth Date */
    if (!coupleData.customer_couple_data_birth_date) {

    } else {
      const birth_date_couple = coupleData.customer_couple_data_birth_date;
      coupleData.customer_couple_data_birth_date =
        birth_date_couple['year'] +
        '-' +
        ('0' + birth_date_couple['month']).substr(-2) +
        '-' +
        ('0' + birth_date_couple['day']).substr(-2);
    /** Couple Data Change Format Birth Date */
    }
    /** Job Data Change Format Est From */
    const customer_job_data_est_from = jobData.customer_job_data_est_from;
    if (customer_job_data_est_from) {
      jobData.customer_job_data_est_from =
        customer_job_data_est_from['year'] +
        '-' +
        ('0' + customer_job_data_est_from['month']).substr(-2) +
        '-' +
        ('0' + customer_job_data_est_from['day']).substr(-2);
      /** END Job Data Change Format Est From */

      /** Job Data Change Format Work Since */
      const customer_job_data_work_sinc = jobData.customer_job_data_work_since;
      jobData.customer_job_data_work_since =
        customer_job_data_work_sinc['year'] +
        '-' +
        ('0' + customer_job_data_work_sinc['month']).substr(-2) +
        '-' +
        ('0' + customer_job_data_work_sinc['day']).substr(-2);
    /** END Job Data Change Format Work Since */

    }

    /** IndexOf Personal Data */
    for (const prop in coupleData) {
      if (prop.indexOf('customer_couple_data_') >= 0) {
        const res = prop.replace('customer_couple_data_', '');
        coupleData[res] = coupleData[prop];
        delete coupleData[prop];
      }
    }
    /** END IndexOf Personal Data */

    /** indexOf Job Data */
    for (const valJob in jobData) {
      if (valJob.indexOf('customer_job_data_') >= 0) {
        const resultJob = valJob.replace('customer_job_data_', '');
        jobData[resultJob] = jobData[valJob];
        delete jobData[valJob];
      }
    }
    /** END indexOf Job Data */

    /** IndexOf Financial Data */
    for (const valFinancial in finacialData) {
      if (valFinancial.indexOf('customer_financial_data_') >= 0) {
        const resultFinancial = valFinancial.replace('customer_financial_data_', '');
        finacialData[resultFinancial] = finacialData[valFinancial];
        delete finacialData[valFinancial];
      }
    }
    /** END IndexOf Financial Data */

    /** IndexOf Emergency Contact */
    for (const prop in emergencyContact) {
      if (prop.indexOf('customer_emergency_contact_') >= 0) {
        const resultEmergency = prop.replace('customer_emergency_contact_', '');
        emergencyContact[resultEmergency] = emergencyContact[prop];
        delete emergencyContact[prop];
      }
    }
    /** END IndexOf Emergency Contact */

    /** IndexOf Attachment */
    for (const prop in attachfile) {
      if (prop.indexOf('attachments') >= 0) {
        const resultAttachment = prop.replace('attachments', '');
        attachfile[resultAttachment] = attachfile[prop];
        delete attachfile[prop];
      }
    }

    const value_personal_data = {
      first_name: personalData.first_name,
      last_name: personalData.last_name,
      customer_gender: personalData.customer_gender,
      marital_status: personalData.marital_status,
      ktp_number: personalData.ktp_number,
      kk_number: personalData.kk_number,
      passport_number: personalData.passport_number,
      npwp_number: personalData.npwp_number,
      place_birth: personalData.place_birth,
      birth_date: this.birth_date_personalData,
      ktp_address: personalData.ktp_address,
      ktp_address_rt: personalData.ktp_address_rt,
      ktp_address_rw: personalData.ktp_address_rw,
      ktp_address_province: personalData.ktp_address_province,
      ktp_address_city: personalData.ktp_address_city,
      ktp_address_district: personalData.ktp_address_district,
      ktp_address_village: personalData.ktp_address_village,
      ktp_address_postal_code: personalData.ktp_address_postal_code,
      home_address: personalData.home_address,
      home_address_rt: personalData.home_address_rt,
      home_address_rw: personalData.home_address_rw,
      home_address_province: personalData.home_address_province,
      home_address_city: personalData.home_address_city,
      home_address_district: personalData.home_address_district,
      home_address_village: personalData.home_address_village,
      home_status: personalData.home_status,
      phone: personalData.phone,
      mobile: personalData.mobile,
      email: personalData.email,
      education_level: personalData.education_level,
      mothers_maiden_name: personalData.mothers_maiden_name,
      citizenship: personalData.citizenship,
      number_of_dependents: personalData.number_of_dependents
    };

    this.value_couple_data = {
      first_name: coupleData.first_name,
      last_name: coupleData.last_name,
      ktp_number: coupleData.ktp_number,
      kk_number: coupleData.kk_number,
      passport_number: coupleData.passport_number,
      place_birth: coupleData.place_birth,
      birth_date: this.birth_date_coupleData,
      ktp_address: coupleData.ktp_address,
      ktp_address_rt: coupleData.ktp_address_rt,
      ktp_address_rw: coupleData.ktp_address_rw,
      ktp_address_province: coupleData.ktp_address_province,
      ktp_address_city: coupleData.ktp_address_city,
      ktp_address_district: coupleData.ktp_address_district,
      ktp_address_village: coupleData.ktp_address_village,
      ktp_address_postal_code: coupleData.ktp_address_postal_code,
      phone: coupleData.phone,
      mobile: coupleData.mobile,
      couple_job: coupleData.couple_job,
      customer_personal_data: '',
    };

    this.value_job_data = {
      job: jobData.job,
      company_name: jobData.company_name,
      est_from: this.birth_date_jobDataEstFrom,
      address: jobData.address,
      province: jobData.province,
      city: jobData.city,
      district: jobData.district,
      village: jobData.village,
      phone: jobData.phone,
      fax: jobData.fax,
      email: jobData.email,
      web: jobData.web,
      business_type: jobData.business_type,
      position: jobData.position,
      work_since: this.birth_date_jobDataWorkSince,
      customer_personal_data: '',
    };

    this.value_financial_data = {
      fixed_income: finacialData.fixed_income,
      couple_income: finacialData.couple_income,
      other_income: finacialData.other_income,
      spending: finacialData.spending,
      customer_personal_data: '',
    };

   this.value_emergency_data = {
      first_name: emergencyContact.first_name,
      last_name: emergencyContact.last_name,
      address: emergencyContact.address,
      address_rt: emergencyContact.address_rt,
      address_rw: emergencyContact.address_rw,
      address_province: emergencyContact.address_province,
      address_city: emergencyContact.address_city,
      address_district: emergencyContact.address_district,
      address_village: emergencyContact.address_village,
      address_postal_code: emergencyContact.address_postal_code,
      mobile: emergencyContact.mobile,
      phone: emergencyContact.phone,
      relationship: emergencyContact.relationship,
      customer_personal_data: '',
    };

    // console.log(value_personal_data);
    // console.log(this.birth_date_personalData);
    // console.log(this.value_couple_data);
    // console.log(this.value_job_data);
    // console.log(this.value_financial_data);
    // console.log(this.value_emergency_data);

    const dataForm = {
      personal_data: value_personal_data,
      couple_data: this.value_couple_data,
      job_data: this.value_job_data,
      financial_data: this.value_financial_data,
      emergency: this.value_emergency_data,
      attachfile: attachfile
    };

    // console.log(attachfile);
    // console.log(this.form.valid);

this.validate = this.Validation(dataForm);
 if (this.validate === 0) {
      return false;
    } else {
     if (this.form.valid) {
       if (!this.id) {
        /** PERSONAL DATA POST */
         if (this.validate !== 0) {
            await this.apiService.post('customer/personal_data/', value_personal_data).subscribe(
              async success_personalData => {
                // console.log(success_personalData);
                const urlpersonalData = success_personalData.headers.get('location').split('/');
                const idpersonalData = urlpersonalData[urlpersonalData.length - 1];
                this.value_couple_data.customer_personal_data = { id: idpersonalData };
                this.value_job_data.customer_personal_data = { id: idpersonalData };
                this.value_financial_data.customer_personal_data = { id: idpersonalData };
                this.value_emergency_data.customer_personal_data = { id: idpersonalData };
                attachfile.customer_personal_data = { id: idpersonalData };

                if (this._status === 'MARRIED') {
                  await this.apiService.post('customer/couple_data/', this.value_couple_data).subscribe(
                    success_couple => {
                      console.log(success_couple);
                    },
                    error => {
                      console.log(error);
                    }
                  );
                }

                await this.apiService.post('customer/job_data/', this.value_job_data).subscribe(
                  success_job => {
                    console.log(success_job);
                  },
                  error => {
                    // console.log(error);
                  }
                );

                await this.apiService.post('customer/financial_data/', this.value_financial_data).subscribe(
                  success_financial => {
                    console.log(success_financial);
                  },
                  error => {
                    // console.log(error);
                  }
                );

                await this.apiService.post('customer/emergency_contact/', this.value_emergency_data).subscribe(
                  success_emergency_contact => {
                    console.log(success_emergency_contact);
                  },
                  error => {
                    // console.log(error);
                  }
                );

                for (let i = 0; i < attachfile.length; i++) {
                  (<FormArray>this.form.controls['attachments']).at(i).patchValue({ att_file: this.att_filename });
                  if (this.img_added) {
                    const valueElement: ElementRef[] = this.file_attachment.toArray();
                    const inputEl = valueElement[i].nativeElement;
                    const formData = new FormData();
                    formData.append('file', inputEl.files.item(0));
                    console.log(inputEl.files.item(0));
                    await this.apiService.post('attach', formData).subscribe(
                      async (response: any) => {
                        this.att_filename = response.body.file_download_uri;
                        this.file_type = response.body.file_type;
                        const format_file = this.file_type.split('/');
                        attachfile[i].att_file = this.att_filename;
                        attachfile[i].file_type = format_file[1];
                        attachfile[i].customer_personal_data = { id: idpersonalData };
                        await this.apiService.post('customer/attachment/', attachfile[i]).subscribe(
                          success_attachment => {
                            console.log(success_attachment);
                          },
                          error => {
                            console.log(error);
                          }
                        );
                      },
                      error => {
                        console.log(error);
                      }
                    );
                  }
                }
              },
              error_personalData => {
                // this.flashMessage.show(error_personalData.error.message, {
                //   cssClass: 'alert-danger',
                //   showCloseBtn: true
                // });
                return;
                // console.log(error_personalData);
              }
            );
            this.router.navigate(['master/customers']);
          }
        } else {
          this.apiService.put('customer/personal_data/' + this.id, value_personal_data).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );
          // console.log(this.idCouple);
          if (!this.idCouple) {
            this.value_couple_data.customer_personal_data = { id: this.id };
            this.apiService.post('customer/couple_data/', this.value_couple_data).subscribe(
              success_couple => {
                console.log(success_couple);
              },
              error => {
                // console.log(error);
              }
            );
          } else {
            this.value_couple_data.customer_personal_data = { id: this.id };
            this.apiService.put('customer/couple_data/' + this.idCouple, this.value_couple_data).subscribe(
              success => {
                console.log(success);
              },
              error => {
                // console.log(error);
              }
            );
          }

          this.value_emergency_data.customer_personal_data = { id: this.id };
          this.apiService
            .put('customer/emergency_contact/' + this.idEmergencyContact, this.value_emergency_data)
            .subscribe(
              success => {
                console.log(success);
              },
              error => {
                // console.log(error);
              }
            );
          this.value_job_data.customer_personal_data = { id: this.id };
          this.apiService.put('customer/job_data/' + this.idJob, this.value_job_data).subscribe(
            success => {
              console.log(success);
            },
            error => {
              // console.log(error);
            }
          );
          this.value_financial_data.customer_personal_data = { id: this.id };
          this.apiService.put('customer/financial_data/' + this.idFinancial, this.value_financial_data).subscribe(
            success => {
              console.log(success);
            },
            error => {
              // console.log(error);
            }
          );

         for (let i = 0; i < attachfile.length; i++) {
           (<FormArray>this.form.controls['attachments']).at(i).patchValue({ att_file: this.att_filename });
           if (this.img_added) {
             const valueElement: ElementRef[] = this.file_attachment.toArray();
             const inputEl = valueElement[i].nativeElement;
             const formData = new FormData();
             formData.append('file', inputEl.files.item(0));
            //  console.log(inputEl.files.item(0));
             await this.apiService.post('attach', formData).subscribe(
               async (response: any) => {
                 this.att_filename = response.body.file_download_uri;
                 this.file_type = response.body.file_type;
                 const format_file = this.file_type.split('/');
                 attachfile[i].att_file = this.att_filename;
                 attachfile[i].file_type = format_file[1];
                 attachfile[i].customer_personal_data = { id: this.id };
                 await this.apiService.post('customer/attachment/', attachfile[i]).subscribe(
                   success_attachment => {
                     console.log(success_attachment);
                   },
                   error => {
                     console.log(error);
                   }
                 );
               },
               error => {
                 console.log(error);
               }
             );
           }
         }
          this.router.navigate(['master/customers']);
        }
      } else {
        this.validateAllFormFields(this.form);
      }
    }
  }

  private Validation(dataForm) {
    // console.log(dataForm);
    this.valid = 1;

    if (!dataForm.personal_data.first_name) {
      const control = this.form.get('first_name');
      this.fieldValid(control);
      const title = this.translate.instant('app.first_name');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.last_name) {
      const control = this.form.get('last_name');
      this.fieldValid(control);
      const title = this.translate.instant('app.last_name');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.place_birth) {
      const control = this.form.get('place_birth');
      this.fieldValid(control);
      const title = this.translate.instant('app.place_birth');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.birth_date) {
      const control = this.form.get('birth_date');
      this.fieldValid(control);
      const title = this.translate.instant('app.birth_date');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.customer_gender) {
      const control = this.form.get('customer_gender');
      this.fieldValid(control);
      const title = this.translate.instant('app.customer_gender');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.marital_status) {
      const control = this.form.get('marital_status');
      this.fieldValid(control);
      const title = this.translate.instant('app.marital_status');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.ktp_number) {
      const control = this.form.get('ktp_number');
      this.fieldValid(control);
      const title = this.translate.instant('app.ktp_number');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.kk_number) {
      const control = this.form.get('kk_number');
      this.fieldValid(control);
      const title = this.translate.instant('app.kk_number');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    // if (!dataForm.personal_data.passport_number) {
    //   const control = this.form.get('passport_number');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.passport_number');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    if (!dataForm.personal_data.npwp_number) {
      const control = this.form.get('npwp_number');
      this.fieldValid(control);
      const title = this.translate.instant('app.npwp_number');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    // if (!dataForm.personal_data.phone) {
    //   const control = this.form.get('phone');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.phone');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    if (!dataForm.personal_data.mobile) {
      const control = this.form.get('mobile');
      this.fieldValid(control);
      const title = this.translate.instant('app.mobile');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.ktp_address_postal_code) {
      const control = this.form.get('ktp_address_postal_code');
      this.fieldValid(control);
      const title = this.translate.instant('app.ktp_address_postal_code');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.personal_data.ktp_address) {
      const control = this.form.get('ktp_address');
      this.fieldValid(control);
      const title = this.translate.instant('app.ktp_address');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    // if (!dataForm.personal_data.ktp_address_rt) {
    //   const control = this.form.get('ktp_address_rt');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_rt');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.ktp_address_rw) {
    //   const control = this.form.get('ktp_address_rw');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_rw');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.ktp_address_province) {
    //   const control = this.form.get('ktp_address_province');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_province');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    //  if (!dataForm.personal_data.ktp_address_city) {
    //   const control = this.form.get('ktp_address_city');
    //   this.fieldValid(control);
    //    const title = this.translate.instant('app.ktp_address_city');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.ktp_address_district) {
    //   const control = this.form.get('ktp_address_district');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_district');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.ktp_address_village) {
    //   const control = this.form.get('ktp_address_village');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_village');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.mothers_maiden_name) {
    //   const control = this.form.get('mothers_maiden_name');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.mothers_maiden_name');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.home_status) {
    //   const control = this.form.get('home_status');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_status');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.citizenship) {
    //   const control = this.form.get('citizenship');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.citizenship');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    /** HOME */
    // if (!dataForm.personal_data.home_address) {
    //   const control = this.form.get('home_address');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_address');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.home_address_rt) {
    //   const control = this.form.get('home_address_rt');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_address_rt');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.home_address_rw) {
    //   const control = this.form.get('home_address_rw');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_address_rw');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    //  if (!dataForm.personal_data.home_address_province) {
    //   const control = this.form.get('home_address_province');
    //   this.fieldValid(control);
    //    const title = this.translate.instant('app.home_address_province');
    //    this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    //  if (!dataForm.personal_data.home_address_city) {
    //   const control = this.form.get('home_address_city');
    //   this.fieldValid(control);
    //    const title = this.translate.instant('app.home_address_city');
    //    this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.home_address_district) {
    //   const control = this.form.get('home_address_district');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_address_district');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.personal_data.home_address_village) {
    //   const control = this.form.get('home_address_village');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.home_address_village');
    //   this.flashMessage.show(title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    /** END HOME */

    /** Couple Data */
    // switch (this._status) {
    //   case 'MARRIED':
    //     return;
    //     break;
    //   case 'SINGLE':
    //     return;
    //     break;
    //   case 'WIDOW':
    //     return;
    //     break;
    //   default:
    //     if (!dataForm.couple_data.first_name) {
    //       const control = this.form.get('customer_couple_data.customer_couple_data_first_name');
    //       this.fieldValid(control);
    //       const title = this.translate.instant('app.first_name');
    //       this.flashMessage.show('Couple' + title + ' is not empty !', {
    //         cssClass: 'alert-danger',
    //         showCloseBtn: true
    //       });
    //       this.valid = this.NotSave(0);
    //     }
    //     break;
    // }
    // if (!dataForm.couple_data.last_name) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_last_name');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.last_name');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.place_birth) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_place_birth');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.place_birth');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.birth_date) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_birth_date');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.birth_date');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.phone) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_phone');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.phone');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.mobile) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_mobile');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.mobile');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.couple_job) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_couple_job');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.couple_job');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_number) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_number');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_number');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.kk_number) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_kk_number');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.kk_number');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_postal_code) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_postal_code');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_postal_code');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_rt) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_rt');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_rt');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_rw) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_rw');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_rw');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_province) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_province');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_province');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_city) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_city');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_city');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_district) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_district');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_district');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.couple_data.ktp_address_village) {
    //   const control = this.form.get('customer_couple_data.customer_couple_data_ktp_address_village');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.ktp_address_village');
    //   this.flashMessage.show('Couple' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    /** END Couple */

    /** Financial */
    if (!dataForm.financial_data.fixed_income) {
      const control = this.form.get('customer_financial_data.customer_financial_data_fixed_income');
      this.fieldValid(control);
      const title = this.translate.instant('app.fixed_income');
      this.flashMessage.show('Financial' + title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    // if (!dataForm.financial_data.couple_income) {
    //   const control = this.form.get('customer_financial_data.customer_financial_data_couple_income');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.couple_income');
    //   this.flashMessage.show('Financial' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.financial_data.other_income) {
    //   const control = this.form.get('customer_financial_data.customer_financial_data_other_income');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.other_income');
    //   this.flashMessage.show('Financial' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    /** END Financial */

    /** EmerGency */
    // if (!dataForm.emergency.first_name) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_first_name');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.first_name');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.last_name) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_last_name');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.last_name');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.phone) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_phone');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.phone');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.mobile) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_mobile');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.mobile');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.relationship) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_relationship');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.relationship');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_postal_code) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_postal_code');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_postal_code');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_rt) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_rt');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_rt');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_rw) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_rw');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_rw');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_province) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_province');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_province');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_city) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_city');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_city');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_district) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_district');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_district');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //   this.valid = this.NotSave(0);
    // }
    // if (!dataForm.emergency.address_province) {
    //   const control = this.form.get('customer_emergency_contact.customer_emergency_contact_address_village');
    //   this.fieldValid(control);
    //   const title = this.translate.instant('app.address_province');
    //   this.flashMessage.show('Emergency' + title + ' is not empty !', {
    //     cssClass: 'alert-danger',
    //     showCloseBtn: true
    //   });
    //  this.valid = this.NotSave(0);
    // }
    /** END Emergency */

    /** Attachment */
    dataForm.attachfile.forEach(value => {
      if (!value.att_description) {
        this.flashMessage.show('Description Attachment is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
      this.valid = this.NotSave(0);
      }
      // if (!value.att_file) {
      //   this.flashMessage.show('File Attachment is not empty !', {
      //     cssClass: 'alert-danger',
      //     showCloseBtn: true
      //   });
      // this.valid = this.NotSave(0);
      // }
      if (!value.att_title) {
        this.flashMessage.show('Title Attachment is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
    });
    /** END Attachment */
    return this.NotSave(this.valid);
  }

  NotSave(value) {
    return value === 0 ? 0 : 1;
  }

  fieldValid(control) {
    return control.markAsTouched({ onlySelf: true });
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  public onClick(event) {
    if (!event.target.classList.contains('has-datepicker')) {
    }
  }

  back() {
    this.location.back();
  }
  changeMarital(e) {
    this._status = e.target.value;
    this.isMarried = e.target.value === 'MARRIED' ? true : false;
  }

  private async LoadProvince(): Promise<any> {
    await this.apiService
      .get('area/province/data')
      .pipe(delay(100))
      .subscribe((data: any) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              province_name: el.province_name,
              city_collection: el.city_collection,
              code: el.code,
              status: el.status
            });
        });
        this.province = [...items];
      });
  }

  changeProvince(param, event) {

    switch (param) {
      case 'ktp_address_province':
        this.id_province = event.id;
        this.params_name_city     = 'ktp_address_city';
        this.params_name_district = 'ktp_address_district';
        this.params_name_village  = 'ktp_address_village';
        break;
      case 'home_address_province':
        this.id_province = event.id;
        this.params_name_city     = 'home_address_city';
        this.params_name_district = 'home_address_district';
        this.params_name_village  = 'home_address_village';
        break;
      case 'customer_job_data_province':
        this.id_province = event.id;
        this.params_name_city     = 'customer_job_data.customer_job_data_city';
        this.params_name_district = 'customer_job_data.customer_job_data_district';
        this.params_name_village  = 'customer_job_data.customer_job_data_village';
        break;
      case 'customer_couple_data_ktp_address_province':
        this.id_province = event.id;
        this.params_name_city     = 'customer_couple_data.customer_couple_data_ktp_address_city';
        this.params_name_district = 'customer_couple_data.customer_couple_data_ktp_address_district';
        this.params_name_village  = 'customer_couple_data.customer_couple_data_ktp_address_village';
        break;
      case 'customer_emergency_contact_address_province':
        this.id_province          = event.id;
        this.params_name_city     = 'customer_emergency_contact.customer_emergency_contact_address_city';
        this.params_name_district = 'customer_emergency_contact.customer_emergency_contact_address_district';
        this.params_name_village  = 'customer_emergency_contact.customer_emergency_contact_address_village';
        break;
    }

      this.apiService.get('area/province/' + this.id_province).subscribe((data: any) => {
        const items = [];
        data.city_collection.forEach(el => {
          items.push(
            {
              id: el.id,
              city_name: el.city_name,
              city_collection: el.city_collection,
              code: el.code,
              status: el.status
            });
        });
        this.city = [...items];

        this.form.get(this.params_name_city).patchValue('');
        this.form.get(this.params_name_district).patchValue('');
        this.form.get(this.params_name_village).patchValue('');
      });
  }

  changeCity(param, event) {

    switch (param) {
      case 'ktp_address_city':
        this.id_city = event.id;
        this.paramsCity_name_district = 'ktp_address_district';
        this.paramsCity_name_village  = 'ktp_address_village';
        break;
      case 'home_address_city':
        this.id_city = event.id;
        this.paramsCity_name_district = 'home_address_district';
        this.paramsCity_name_village  = 'home_address_village';
        break;
      case 'customer_job_data_city':
        this.id_city = event.id;
        this.paramsCity_name_district = 'customer_job_data.customer_job_data_district';
        this.paramsCity_name_village  = 'customer_job_data.customer_job_data_village';
        break;
      case 'customer_couple_data_ktp_address_city':
        this.id_city = event.id;
        this.paramsCity_name_district = 'customer_couple_data.customer_couple_data_ktp_address_district';
        this.paramsCity_name_village  = 'customer_couple_data.customer_couple_data_ktp_address_village';
        break;
      case 'customer_emergency_contact_address_city':
        this.id_city          = event.id;
        this.paramsCity_name_district = 'customer_emergency_contact.customer_emergency_contact_address_district';
        this.paramsCity_name_village  = 'customer_emergency_contact.customer_emergency_contact_address_village';
        break;
    }

    this.apiService.get('area/city/' + this.id_city).subscribe((data: any) => {
      const items = [];
      data.district_collection.forEach(el => {
        items.push(
          {
            id: el.id,
            district_name: el.district_name,
            district_collection: el.district_collection,
            code: el.code,
            status: el.status
          });
      });
      this.district = [...items];
      this.form.get(this.paramsCity_name_district).patchValue('');
      this.form.get(this.paramsCity_name_village).patchValue('');
    });
  }

  changeDistrict(param, event) {

     switch (param) {
      case 'ktp_address_district':
        this.id_district = event.id;
        this.paramsDistrict_name_village  = 'ktp_address_village';
        break;
      case 'home_address_district':
        this.id_district = event.id;
         this.paramsDistrict_name_village  = 'home_address_village';
        break;
      case 'customer_job_data_district':
        this.id_district = event.id;
         this.paramsDistrict_name_village = 'customer_job_data.customer_job_data_village';
        break;
      case 'customer_couple_data_ktp_address_district':
        this.id_district = event.id;
         this.paramsDistrict_name_village = 'customer_couple_data.customer_couple_data_ktp_address_village';
        break;
       case 'customer_emergency_contact_address_district':
        this.id_district          = event.id;
         this.paramsDistrict_name_village  = 'customer_emergency_contact.customer_emergency_contact_address_village';
        break;
    }

    this.apiService.get('area/district/' + this.id_district ).subscribe((data: any) => {
      const items = [];
      data.village_collection.forEach(el => {
        items.push(
          {
            id: el.id,
            village_name: el.village_name,
            village_collection: el.village_collection,
            code: el.code,
            status: el.status
          });
      });
      this.village = [...items];
      this.form.get(this.paramsDistrict_name_village).patchValue('');
    });
  }

  /** OLD */
  // /*KTP Area Change Event*/
  // changeKTPProv(e) {
  //   console.log(e);
  //   this.apiService.get('area/province/' + e.target.value).subscribe((data: any) => {
  //     this.ktp_address_city = data.city_collection;
  //     this.ktp_address_city.unshift({
  //       id: '',
  //       code: '',
  //       city_name: '',
  //       status: '',
  //       district_collection: []
  //     });
  //     this.ktp_address_district = [];
  //     this.ktp_address_village = [];
  //   });
  // }
  // changeKTPCity(e) {
  //   this.apiService.get('area/city/' + e.target.value).subscribe((data: any) => {
  //     this.ktp_address_district = data.district_collection;
  //     this.ktp_address_village = [];
  //   });
  // }
  // changeKTPDistrict(e) {
  //   this.apiService.get('area/district/' + e.target.value).subscribe((data: any) => {
  //     this.ktp_address_village = data.village_collection;
  //   });
  // }

  // /*Home Area Change Event*/
  // changeHomeProv(e) {
  //   this.apiService.get('area/province/' + e.target.value).subscribe((data: any) => {
  //     this.home_address_city = data.city_collection;
  //     this.home_address_city.unshift({
  //       id: '',
  //       code: '',
  //       city_name: '',
  //       status: '',
  //       district_collection: []
  //     });
  //     this.home_address_district = [];
  //     this.home_address_village = [];
  //   });
  // }
  // changeHomeCity(e) {
  //   this.apiService.get('area/city/' + e.target.value).subscribe((data: any) => {
  //     this.home_address_district = data.district_collection;
  //     this.home_address_village = [];
  //   });
  // }
  // changeHomeDistrict(e) {
  //   this.apiService.get('area/district/' + e.target.value).subscribe((data: any) => {
  //     this.home_address_village = data.village_collection;
  //   });
  // }
  // /*Work Area Change Event*/
  // changeJobProv(e) {
  //   this.apiService.get('area/province/' + e.target.value).subscribe((data: any) => {
  //     this.customer_job_data_city = data.city_collection;
  //     this.customer_job_data_city.unshift({
  //       id: '',
  //       code: '',
  //       city_name: '',
  //       status: '',
  //       district_collection: []
  //     });
  //     this.customer_job_data_district = [];
  //     this.customer_job_data_village = [];
  //   });
  // }
  // changeJobCity(e) {
  //   this.apiService.get('area/city/' + e.target.value).subscribe((data: any) => {
  //     this.customer_job_data_district = data.district_collection;
  //     this.customer_job_data_village = [];
  //   });
  // }
  // changeJobDistrict(e) {
  //   this.apiService.get('area/district/' + e.target.value).subscribe((data: any) => {
  //     this.customer_job_data_village = data.village_collection;
  //   });
  // }

  // /*Couple Area Change Event*/
  // changeCoupleProv(e) {
  //   this.apiService.get('area/province/' + e.target.value).subscribe((data: any) => {
  //     this.customer_couple_data_ktp_address_city = data.city_collection;
  //     this.customer_couple_data_ktp_address_city.unshift({
  //       id: '',
  //       code: '',
  //       city_name: '',
  //       status: '',
  //       district_collection: []
  //     });
  //     this.customer_couple_data_ktp_address_district = [];
  //     this.customer_couple_data_ktp_address_village = [];
  //   });
  // }
  // changeCoupleCity(e) {
  //   this.apiService.get('area/city/' + e.target.value).subscribe((data: any) => {
  //     this.customer_couple_data_ktp_address_district = data.district_collection;
  //     this.customer_couple_data_ktp_address_village = [];
  //   });
  // }
  // changeCoupleDistrict(e) {
  //   this.apiService.get('area/district/' + e.target.value).subscribe((data: any) => {
  //     this.customer_couple_data_ktp_address_village = data.village_collection;
  //   });
  // }

  // /*Emergency Area Change Event*/
  // changeEmergencyProv(e) {
  //   this.apiService.get('area/province/' + e.target.value).subscribe((data: any) => {
  //     this.customer_emergency_contact_address_city = data.city_collection;
  //     this.customer_emergency_contact_address_city.unshift({
  //       id: '',
  //       code: '',
  //       city_name: '',
  //       status: '',
  //       district_collection: []
  //     });
  //     this.customer_emergency_contact_address_district = [];
  //     this.customer_emergency_contact_address_village = [];
  //   });
  // }
  // changeEmergencyCity(e) {
  //   this.apiService.get('area/city/' + e.target.value).subscribe((data: any) => {
  //     this.customer_emergency_contact_address_district = data.district_collection;
  //     this.customer_emergency_contact_address_village = [];
  //   });
  // }
  // changeEmergencyDistrict(e) {
  //   this.apiService.get('area/district/' + e.target.value).subscribe((data: any) => {
  //     this.customer_emergency_contact_address_village = data.village_collection;
  //   });
  // }

  duplicateValue(event) {
    const valueCopy = event.target.checked;
    if (valueCopy === true) {
      const valueKTPaddress = this.ktp_address.nativeElement.value;
      const valueKTP_rt = this.ktp_address_rt.nativeElement.value;
      const valueKTP_rw = this.ktp_address_rw.nativeElement.value;
      const valueKTPaddressprovince = this.form.get('ktp_address_province');
      const valueKTPaddresscity = this.form.get('ktp_address_city');
      const valueKTPaddressdistrict = this.form.get('ktp_address_district');
      const valueKTPaddressvillage = this.form.get('ktp_address_village');

      this.form.get('home_address').patchValue(valueKTPaddress);
      this.form.get('home_address_rt').patchValue(valueKTP_rt);
      this.form.get('home_address_rw').patchValue(valueKTP_rw);
      this.form.get('home_address_province').patchValue(valueKTPaddressprovince.value);
      this.form.get('home_address_city').patchValue(valueKTPaddresscity.value);
      this.form.get('home_address_district').patchValue(valueKTPaddressdistrict.value);
      this.form.get('home_address_village').patchValue(valueKTPaddressvillage.value);

    } else {
      this.form.get('home_address').patchValue('');
      this.form.get('home_address_rt').patchValue('');
      this.form.get('home_address_rw').patchValue('');
      this.form.get('home_address_province').patchValue('');
      this.form.get('home_address_city').patchValue('');
      this.form.get('home_address_district').patchValue('');
      this.form.get('home_address_village').patchValue('');
    }
  }
}
