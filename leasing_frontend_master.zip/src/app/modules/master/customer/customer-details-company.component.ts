import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { ApiService } from '../../../core/services';

@Component({
  selector: 'app-customer-details-company',
  templateUrl: './customer-details-company.component.html',
  styleUrls: ['./customer-details-company.component.scss'],
  animations: [fadeIn()]
})
export class CustomerDetailsCompanyComponent implements OnInit {
  row: any = [];
  constructor(
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.route.snapshot.params.id;
    console.log(id);
    return this.apiService.get('customer/company_data/' + id).subscribe(data => {
      this.row = data;
    });
  }

  back() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.row = false;
  }

}
