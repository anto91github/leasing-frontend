import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DealerComponent } from './dealer.component';
import { DealerFormComponent} from './dealer-form.component';
import { DealerDetailsComponent} from './dealer-details.component';
import { from } from 'rxjs';


const routes: Routes = [
  {
    path: '',
    component: DealerComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: DealerFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: DealerFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id',
    component: DealerDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DealerRoutingModule { }
