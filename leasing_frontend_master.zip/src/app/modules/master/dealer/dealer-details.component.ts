import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { Dealer} from './../../../core/models';
import { ApiService } from '../../../core/services';

/**
 * Dealer detail component
 */
@Component({
  selector: 'app-dealer-details',
  templateUrl: './dealer-details.component.html',
  animations: [fadeIn()]
})
export class DealerDetailsComponent implements OnInit, OnDestroy {
    dealer: Dealer;

  constructor(
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute,
  ) {}

  /**
   * Get data master
   */
  ngOnInit() {
    const id = this.route.snapshot.params.id;
    return this.apiService.get('dealer/' + id).subscribe((data: Dealer) => {
      this.dealer = data;
      // console.log(data);

    });
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  /**
   * Unsubscribe master data
   */
  ngOnDestroy(): void {
    // this.company = false;
  }
}
