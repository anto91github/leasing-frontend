import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DxDataGridModule, DxValidatorModule, DxNumberBoxModule} from 'devextreme-angular';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { DealerRoutingModule } from './dealer-routing.module';
import { DealerComponent } from './dealer.component';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';
import { DealerFormComponent } from './dealer-form.component';
import { DealerDetailsComponent } from './dealer-details.component';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask/src/currency-mask.config';
import { MaskModule } from 'soft-angular-mask';

/** Setting Currency Monney */
export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: 'left',
  allowNegative: true,
  decimal: ',',
  precision: 0,
  prefix: '',
  suffix: '',
  thousands: '.'
};
@NgModule({
  imports: [
    CommonModule,
    DealerRoutingModule,
    FormsModule,
    MaskModule,
    DxValidatorModule,
    ReactiveFormsModule,
    DxNumberBoxModule,
    FlashMessagesModule.forRoot(),
    FroalaEditorModule.forRoot(),
    FroalaViewModule.forRoot(),
    NgbModule,
    DxDataGridModule,
    CurrencyMaskModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [DealerComponent, DealerFormComponent, DealerDetailsComponent],

providers: [
  { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
],
})
export class DealerModule { }
