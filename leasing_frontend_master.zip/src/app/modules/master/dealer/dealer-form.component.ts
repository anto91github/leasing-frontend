import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl,
  FormArray
} from '@angular/forms';

import { FlashMessagesService } from 'angular2-flash-messages';
import { fadeIn } from '../../../shared/animations';
import { ApiService } from '../../../core/services';
import { LocalStorageService } from 'ngx-webstorage';
import { TranslateService } from '@ngx-translate/core';

/**
 * Dealer form component
 */
@Component({
    selector: 'app-dealer-form',
    templateUrl: './dealer-form.component.html',
    animations: [fadeIn()],
    styleUrls: ['./dealer.component.scss'],
    providers: [ApiService, TranslateService],

  })
  export class DealerFormComponent implements OnInit, OnDestroy {
    url = 'dealer/';
    types = [
      { id: 'AUTHORIZED', name: 'Authorized' },
      { id: 'NON_AUTHORIZED', name: 'Non Authorized' }
    ];
    selectedValue = null;
    id: number = null;
    row: any = [];
    form: FormGroup;
  NO_valid: number;
  [x: string]: any;

    constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private route: ActivatedRoute,
      private location: Location,
      private localStorageService: LocalStorageService,
      private apiService: ApiService,
      private flashMessage: FlashMessagesService,
      private translate: TranslateService
    ) {}
    ngOnInit() {
      this.route.params.subscribe(params => {
        this.id = params['id'];
        if (!this.id) {
          return;
        }
       this.apiService.get('dealer/' + this.id).subscribe(data => {
          this.row = data;
          this.form.patchValue(
            {
              transportation: this.row.price_formulas.transportation,
              documentation: this.row.price_formulas.documentation,
              profit: this.row.price_formulas.profit,
              admin_fee: this.row.price_formulas.admin_fee,
              dealer_fee: this.row.price_formulas.dealer_fee,
            }
          );
        });
      });
      this.form = new FormGroup(
        {
          dealer_name: new FormControl('', {
            validators: [Validators.required, Validators.minLength(3)]
          }),
          address: new FormControl('', {
            validators: Validators.required
          }),
          phone: new FormControl('', {
            validators: [Validators.required]
          }),
          fax: new FormControl('', {
            validators: Validators.required
          }),
          email: new FormControl('', {
            validators: [Validators.required, Validators.email]
          }),
          web: new FormControl('', {
            validators: Validators.required
          }),
          transportation: new FormControl('', {
            validators: Validators.required
          }),
          documentation: new FormControl('', {
            validators: Validators.required
          }),
          profit: new FormControl('', {
            validators: Validators.required
          }),
          admin_fee: new FormControl('', {
            validators: Validators.required
          }),
          dealer_fee: new FormControl('', {
            validators: Validators.required
          }),
          // formModel1: new FormControl()
        },
        { updateOn: 'blur' }
      );
    }

    save() {
    //   this.validate = this.Validation(dataForm);
    // if (this.validate === 0) {
    //   return false;
    // } else {
      console.log(this.form.value);
      this.validate = this.Validation(this.form.value);
      if (this.form.valid) {
        let result: any;
        if (!this.id) {
          const price_formula = {
            admin_fee: this.form.value.admin_fee,
            dealer_fee: this.form.value.dealer_fee,
            documentation: this.form.value.documentation,
            profit: this.form.value.profit,
            transportation: this.form.value.transportation
          };

          const dealer_header = {
            address: this.form.value.address,
            company_id: this.localStorageService.retrieve('user_company_active'),
            dealer_name: this.form.value.dealer_name,
            email: this.form.value.email,
            fax: this.form.value.fax,
            phone: this.form.value.phone,
            web: this.form.value.web,
            price_formulas: price_formula
          };
          result = this.apiService.post('dealer/', dealer_header);

          console.log(this.form.value);
          console.log(dealer_header);
        } else {
          result = this.apiService.put('dealer/' + this.id, this.form.value);
          // result = this.apiService.put('dealer/formula' + this.id, this.form.value);
        }
        result.subscribe(
          success => {
            console.log('Location URL: ' + success.headers.get('location'));
            this.router.navigate(['master/dealer']);
          },
          error => {
            this.flashMessage.show(error.error.message, {
              cssClass: 'alert-danger',
              showCloseBtn: true
            });
            console.log(error);
          }
        );
      } else {
        this.validateAllFormFields(this.form);
      }
    }
    back() {
      this.location.back();
    }
    fieldValid(control) {
      return control.markAsTouched({ onlySelf: true });
    }
    isFieldValid(field: string) {
      return !this.form.get(field).valid && this.form.get(field).touched;
    }
    displayFieldCss(field: string) {
      return {
        'has-danger': this.isFieldValid(field)
      };
    }
    validateAllFormFields(formGroup: FormGroup) {
      Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
          this.validateAllFormFields(control);
        }
      });
    }
    Validation(dataForm) {
      this.valid  = 1;
        // console.log(dataForm);
        if (!dataForm.dealer_name) {
          const control = this.form.get('dealer_name');
          this.fieldValid(control);
          const title = this.translate.instant('app.name');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.address) {
          const control = this.form.get('address');
          this.fieldValid(control);
          const title = this.translate.instant('app.address');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.phone) {
          const control = this.form.get('phone');
          this.fieldValid(control);
          const title = this.translate.instant('app.phone');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.fax) {
          const control = this.form.get('fax');
          this.fieldValid(control);
          const title = this.translate.instant('app.fax');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.email) {
          const control = this.form.get('email');
          this.fieldValid(control);
          const title = this.translate.instant('app.email');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.web) {
          const control = this.form.get('web');
          this.fieldValid(control);
          const title = this.translate.instant('app.web');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.transportation) {
          const control = this.form.get('transportation');
          this.fieldValid(control);
          const title = this.translate.instant('app.transportation');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.documentation) {
          const control = this.form.get('documentation');
          this.fieldValid(control);
          const title = this.translate.instant('app.documentation');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.profit) {
          const control = this.form.get('profit');
          this.fieldValid(control);
          const title = this.translate.instant('app.profit');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.dealer_fee) {
          const control = this.form.get('dealer_fee');
          this.fieldValid(control);
          const title = this.translate.instant('app.dealer_fee');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        if (!dataForm.admin_fee) {
          const control = this.form.get('admin_fee');
          this.fieldValid(control);
          const title = this.translate.instant('app.admin_fee');
          this.flashMessage.show(title + ' is not empty !', {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          this.valid = this.NotSave(0);
        }
        return this.NotSave(this.valid);
      }
      NotSave(value) {
        return value === 0 ? 0 : 1;
      }
    ngOnDestroy(): void {
      this.row = false;
    }

  }
