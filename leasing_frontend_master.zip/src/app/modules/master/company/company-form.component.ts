import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl
} from '@angular/forms';

import { FlashMessagesService } from 'angular2-flash-messages';
import { fadeIn } from '../../../shared/animations';
import { ApiService } from '../../../core/services';
import { TranslateService } from '@ngx-translate/core';

/**
 * Company form component
 */
@Component({
    selector: 'app-company-form',
    templateUrl: './company-form.component.html',
    animations: [fadeIn()],
    styleUrls: ['./company.component.scss']

  })
  export class CompanyFormComponent implements OnInit, OnDestroy {
    url = 'company/';
    types = [
      { id: 'AUTHORIZED', name: 'Authorized' },
      { id: 'NON_AUTHORIZED', name: 'Non Authorized' }
    ];
    selectedValue = null;
    id: number = null;
    row: any = [];
    form: FormGroup;
  NO_valid: any;
  validate: any;
  valid: any;

    constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private route: ActivatedRoute,
      private location: Location,
      private apiService: ApiService,
      private flashMessage: FlashMessagesService,
      private translate: TranslateService
    ) {}

    ngOnInit() {
      this.route.params.subscribe(params => {
        this.id = params['id'];
        if (!this.id) {
          return;
        }
        return this.apiService.get('company/' + this.id).subscribe(data => {
          this.row = data;
          console.log(this.row);
        });
      });
      this.form = new FormGroup(
        {
          company_name: new FormControl('', {
            validators: [Validators.required, Validators.minLength(3)]
          }),
          address: new FormControl('', {
            validators: Validators.required
          }),
          phone: new FormControl('', {
            validators: [Validators.maxLength(20), Validators.pattern('[0-9]*'), Validators.required]
          }),
          fax: new FormControl('', {
            validators: Validators.required
          }),
          email: new FormControl('', {
            validators: [Validators.required, Validators.email]
          }),
          web: new FormControl('', {
            validators: Validators.required
          }),
          formModel1: new FormControl()
        },
        { updateOn: 'blur' }
      );
    }

    save() {
      this.validate = this.Validation(this.form.value);
        console.log(this.form.value);
        if (this.form.valid) {
          let result: any;
          if (!this.id) {
            result = this.apiService.post('company/', this.form.value);
          } else {
            result = this.apiService.put('company/' + this.id, this.form.value);
          }
          result.subscribe(
            success => {
              console.log('Location URL: ' + success.headers.get('location'));
              this.router.navigate(['master/company']);
            },
            error => {
              this.flashMessage.show(error.error.message, {
                cssClass: 'alert-danger',
                showCloseBtn: true
              });
              console.log(error);
            }
          );
        } else {
          this.validateAllFormFields(this.form);
        }
      }
    back() {
      this.location.back();
    }

    fieldValid(control) {
      return control.markAsTouched({ onlySelf: true });
    }
    isFieldValid(field: string) {
      return !this.form.get(field).valid && this.form.get(field).touched;
    }

    displayFieldCss(field: string) {
      return {
        'has-danger': this.isFieldValid(field)
      };
    }

    validateAllFormFields(formGroup: FormGroup) {
      Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
          this.validateAllFormFields(control);
        }
      });
    }

 Validation(dataForm) {
    this.valid  = 1;
      // console.log(dataForm);
      if (!dataForm.company_name) {
        const control = this.form.get('company_name');
        this.fieldValid(control);
        const title = this.translate.instant('app.company_name');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }

      if (!dataForm.address) {
        const control = this.form.get('address');
        this.fieldValid(control);
        const title = this.translate.instant('app.address');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.phone) {
        const control = this.form.get('phone');
        this.fieldValid(control);
        const title = this.translate.instant('app.phone');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.fax) {
        const control = this.form.get('fax');
        this.fieldValid(control);
        const title = this.translate.instant('app.fax');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.email) {
        const control = this.form.get('email');
        this.fieldValid(control);
        const title = this.translate.instant('app.email');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.web) {
        const control = this.form.get('web');
        this.fieldValid(control);
        const title = this.translate.instant('app.web');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      return this.NotSave(this.valid);
    }
    NotSave(value) {
      return value === 0 ? 0 : 1;
    }

    ngOnDestroy(): void {
      this.row = false;
    }
  }
