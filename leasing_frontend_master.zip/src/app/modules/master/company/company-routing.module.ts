import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CompanyComponent } from './company.component';
import { CompanyFormComponent } from './company-form.component';
import { CompanyDetailsComponent } from './company-details.component';

const routes: Routes = [
  {
    path: '',
    component: CompanyComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: CompanyFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: CompanyFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id',
    component: CompanyDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyRoutingModule { }
