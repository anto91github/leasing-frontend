import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

import { DxDataGridComponent } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { fadeIn } from '../../../shared/animations';
import { Master } from '../../../core/models';
import { ApiService, ConfigService } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: [ ],
  animations: [fadeIn()]
})
export class CompanyComponent implements OnInit {
    [x: string]: any;
    @ViewChild(DxDataGridComponent)
    dataGrid: DxDataGridComponent;
    route = 'master/company';
    dataGridSource: any = {};
    dataGridPageSize = 10;

    constructor(
      @Inject(ApiService) apiServiceInject: ApiService,
      private apiService: ApiService,
      private location: Location,
      private router: Router,
      private translateService: TranslateService,
      private localSt: LocalStorageService,
      private config: ConfigService,
    ) {
      this.title = this.translateService.instant('app.company');

      this.allow_view = false;
      this.allow_create = false;
      this.allow_edit = false;
      this.allow_delete = false;
      this.allow_print = false;
      this.allow_export = false;
      this.page_view_permission = 'master.company.view';
      this.page_create_permission = 'master.company.create';
      this.page_edit_permission = 'master.company.edit';
      this.page_delete_permission = 'master.company.delete';
      this.page_print_permission = 'master.company.print';
      this.page_export_permission = 'master.company.export';

      this.user_permission_collection = this.localSt.retrieve('user_roles');

      for (const check of this.user_permission_collection[0].access_collection) {
        if (check.permission === this.page_view_permission) {
          this.allow_view = true;
        }
        if (check.permission === this.page_create_permission) {
          this.allow_create = true;
        }
        if (check.permission === this.page_edit_permission) {
          this.allow_edit = true;
        }
        if (check.permission === this.page_delete_permission) {
          this.allow_delete = true;
        }
        if (check.permission === this.page_print_permission) {
          this.allow_print = true;
        }
        if (check.permission === this.page_export_permission) {
          this.allow_export = true;
        }
      }
      if (this.allow_view === false) {
        alert(
          this.translateService.instant('alert.no_view') +
            this.translateService.instant('app.company')
        );
        this.location.back();
      }
      this.dataGridSource.store = new CustomStore({
        load: function(options: any) {
          options.userData.company_id = true;
          return apiServiceInject.getMaster('company', options);
        },
        remove: function(row) {
          return apiServiceInject
            .delete('company/' + row.id)
            .toPromise()
            .then(
              () => document.getElementById('btn-refresh').click(),
              error => Promise.reject(error.error.message)
            );
        }
      });
      this.dataGridPageSize = config.getConfig('paginationLength');
    }

    ngOnInit() {}

    actionRefresh() {
      this.dataGrid.instance.refresh();
    }

    actionAdd() {
      if (this.allow_create === false) {
        alert(
          this.translateService.instant('alert.no_create') +
            this.translateService.instant('app.company')
        );
        return false;
      }
      this.router.navigate([this.route, 'create']);
    }

    actionDetails(id) {
      this.router.navigate([this.route, id]);
    }

    actionEdit(id) {
      if (this.allow_edit === false) {
        alert(
          this.translateService.instant('alert.no_edit') +
          this.translateService.instant('app.company')
        );
        return false;
      }
      this.router.navigate([this.route, id, 'edit']);
    }

    actionDelete(row) {
      if (this.allow_edit === false) {
        alert(
          this.translateService.instant('alert.no_delete') +
            this.translateService.instant('app.company')
        );
        return false;
      }
      this.dataGrid.instance.deleteRow(row.rowIndex);
    }

    actionPrint() {
      console.log('Print HTML');
    }

    actionExcel() {
      if (this.allow_edit === false) {
        alert(
          this.translateService.instant('alert.no_export') +
            this.translateService.instant('app.company')
        );
        return false;
      }
      this.apiService.get('company').subscribe(
        (success: Master) => {
          const table = [];
          success.content.forEach(el => {
            table.push({
              ID: el.id,
              [this.translateService.instant('app.name')]: el.company_name,
              [this.translateService.instant('app.address')]: el.address,
              [this.translateService.instant('app.phone')]: el.phone,
              [this.translateService.instant('app.fax')]: el.fax,
              [this.translateService.instant('app.email')]: el.email,
              [this.translateService.instant('app.web')]: el.web
            });
          });
          const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
          const wb: XLSX.WorkBook = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, this.title);
          XLSX.writeFile(wb, `${this.title}.xlsx`);
        },
        error => {
          console.log(error);
        }
      );
    }

    actionPdf() {
      if (this.allow_edit === false) {
        alert(
          this.translateService.instant('alert.no_print') +
            this.translateService.instant('app.company')
        );
        return false;
      }
      const columns = [
        { title: 'No', dataKey: 'no' },
        { title: this.translateService.instant('app.name'), dataKey: 'name' },
        { title: this.translateService.instant('app.address'), dataKey: 'address' },
        { title: this.translateService.instant('app.phone'), dataKey: 'phone' },
        { title: this.translateService.instant('app.fax'), dataKey: 'fax' },
        { title: this.translateService.instant('app.email'), dataKey: 'email' },
        { title: this.translateService.instant('app.web'), dataKey: 'web' }
      ];
      const rows = [];

      this.apiService.get('company').subscribe(
        (success: any) => {
          const items = success.content;
          for (let i = 0; i < items.length; i++) {
            rows.push({
              no: `${i + 1}.`,
              name: items[i].company_name,
              address: items[i].address,
              phone: items[i].phone,
              fax: items[i].fax,
              email: items[i].email,
              web: items[i].web
            });
          }

          // Only pt supported (not mm or in)
          const doc = new jsPDF('p', 'pt');
          doc.autoTable(columns, rows, {
            addPageContent: function(data) {
              doc.text('Company', 40, 30);
            },
            margin: { top: 60 },
            bodyStyles: { valign: 'top' },
            styles: { overflow: 'linebreak', fontSize: 7 },
            columnStyles: { text: { columnWidth: 'auto' } }
          });
          window.open(doc.output('bloburl'));
        },
        error => {
          console.log(error);
        }
      );
    }
  }
