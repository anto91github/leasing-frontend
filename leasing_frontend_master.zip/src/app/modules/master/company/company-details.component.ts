import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { Company} from './../../../core/models';
import { ApiService } from '../../../core/services';

/**
 * Company detail component
 */
@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  animations: [fadeIn()]
})
export class CompanyDetailsComponent implements OnInit, OnDestroy {
  company: Company;

  constructor(
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute
  ) {}

  /**
   * Get data master
   */
  ngOnInit() {
    const id = this.route.snapshot.params.id;
    return this.apiService.get('company/' + id).subscribe((data: Company) => {
      this.company = data;
    });
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  /**
   * Unsubscribe master data
   */
  ngOnDestroy(): void {
    // this.company = false;
  }
}
