import { Component, OnInit, OnDestroy, ViewChild, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { ApiService, ConfigService } from '../../../core/services';
import { DxDataGridComponent } from 'devextreme-angular';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  providers: [TranslateService],
  animations: [fadeIn()]
})
export class ProductDetailsComponent implements OnInit, OnDestroy {
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  row: any = [];
  dataGridPageSize = 10;
  dataGridSource: any = {};

  brand: string;
  type: string;
  category: string;
  model: string;
  cylinder_capacity: string;
  fuel: string;

  // coloumns_head : string;
  // rows_head : string;
  constructor(
    @Inject(ApiService) apiServices: ApiService,
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute,
    private translateService: TranslateService,
    private config: ConfigService,
  ) {
  //   this.dataGridSource.store = new CustomStore({
  //     load: function(options: any) {
  //       return apiServiceInject.getMaster('product', options);
  //     },
  // });
}


  ngOnInit() {
    const id = this.route.snapshot.params.id;
     this.apiService.get('product/' + id).subscribe(data => {
      this.row = data;
      this.dataGridSource = this.row.stock_collection;
      // console.log(data);
      this.dataGridPageSize = this.config.getConfig('paginationLength');
    });
  }

  back() {
    this.location.back();
  }

  actionPrint() {
    const columns = [
      { title: 'No', dataKey: 'no' },
      // { title: this.translateService.instant('app.brand'), dataKey: 'brand' },
      // { title: this.translateService.instant('app.type'), dataKey: 'type' },
      // { title: this.translateService.instant('app.category'), dataKey: 'category' },
      // { title: this.translateService.instant('app.model'), dataKey: 'model' },
      // { title: this.translateService.instant('app.cylinder_capacity'), dataKey: 'cylinder_capacity' },
      // { title: this.translateService.instant('app.fuel'), dataKey: 'web' },
      { title: this.translateService.instant('app.storage_location_name'), dataKey: 'storage_location_name' },
      { title: this.translateService.instant('app.manufacture_year'), dataKey: 'manufacture_year' },
      { title: this.translateService.instant('app.vin'), dataKey: 'vin' },
      { title: this.translateService.instant('app.engine_number'), dataKey: 'engine_number' },
      { title: this.translateService.instant('app.color'), dataKey: 'color' }

    ];
    const coloumns_head = ['', '', '', ''];
      const rows_head = [
        [
          this.translateService.instant('app.brand') + ':',
          this.row.brand,
          this.translateService.instant('app.type') + ':',
          this.row.type
        ],
        [
          this.translateService.instant('app.category') + ':',
          this.row.category,
          this.translateService.instant('app.model') + ':',
          this.row.model
        ],
        [
          this.translateService.instant('app.cylinder_capacity') + ':',
          this.row.cylinder_capacity,
          this.translateService.instant('app.fuel') + ':',
          this.row.fuel
        ],
      ];
    const rows = [];

    this.apiService.get('product').subscribe(
      (success: any) => {
        const items = this.row.stock_collection;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            id: items[i].id,
            // storage_location_id: items[i].storage_location_id,
            storage_location_name: items[i].storage_location_name,
            manufacture_year: items[i].manufacture_year,
            vin: items[i].vin,
            engine_number: items[i].engine_number,
            color: items[i].color,
          });
          // console.log(items);
        }
        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(coloumns_head, rows_head, {
          addPageContent: function(data) {
            doc.text('Product', 40, 30);
          },
          theme: 'plain',
          margin: { top: 50 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1 },
          columnStyles: {
            0: { columnWidth: 70 },
            1: { columnWidth: 290 },
            2: { columnWidth: 70 }
          }
        });
        doc.autoTable(columns, rows, {
          margin: { top: 120 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  ngOnDestroy(): void {
    this.row = false;
  }
}
