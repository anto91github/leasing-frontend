import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

import { DxDataGridComponent } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { fadeIn } from '../../../shared/animations';
import { Master } from '../../../core/models';
import { ApiService, ConfigService } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';

/**
 * Product component
 */
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  providers: [TranslateService],
  animations: [fadeIn()]
})
export class ProductComponent implements OnInit {
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  title: string;
  route = 'master/products/';
  dataGridSource: any = {};
  dataGridPageSize = 10;

  page_view_permission: string;
  page_create_permission: string;
  page_edit_permission: string;
  page_delete_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_create: boolean;
  allow_edit: boolean;
  allow_delete: boolean;
  allow_print: boolean;
  allow_export: boolean;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private location: Location,
    private translateService: TranslateService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private config: ConfigService,
    private localSt: LocalStorageService
  ) {
    this.title = this.translateService.instant('app.product');
    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'master.products.view';
    this.page_create_permission = 'master.products.create';
    this.page_edit_permission = 'master.products.edit';
    this.page_delete_permission = 'master.products.delete';
    this.page_print_permission = 'master.products.print';
    this.page_export_permission = 'master.products.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.product')
      );
      this.location.back();
    }

    this.dataGridSource.store = new CustomStore({
      load: function(options: any) {
        return apiServiceInject.getMaster('product', options);
      },
      remove: function(row: any) {
        return apiService
          .delete('product/' + row.id)
          .toPromise()
          .then(
            data => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
  }

  ngOnInit() {}

  loadImage(url) {
    url = url === '' || url + '' === 'null' ? 'assets/img/no-image.png' : url;
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
          this.translateService.instant('app.product')
      );
      return false;
    }
    this.router.navigate([this.route, 'create']);
  }

  actionDetails(id) {
    this.router.navigate([this.route, id]);
  }

  actionEdit(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
          this.translateService.instant('app.product')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete(row) {
    if (this.allow_delete === false) {
      alert(
        this.translateService.instant('alert.no_delete') +
          this.translateService.instant('app.product')
      );
      return false;
    }
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

  actionPrint() {
    console.log('Print HTML');
  }

  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.product')
      );
      return false;
    }
    this.apiService.get('product').subscribe(
      (success: any) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.brand')]: el.brand,
            [this.translateService.instant('app.type')]: el.type,
            [this.translateService.instant('app.category')]: el.category,
            [this.translateService.instant('app.model')]: el.model,
            [this.translateService.instant('app.cylinder_capacity')]: el.cylinder_capacity,
            [this.translateService.instant('app.fuel')]: el.fuel
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.product')
      );
      return false;
    }
    const columns = [
      { title: 'ID', dataKey: 'id' },
      { title: this.translateService.instant('app.brand'), dataKey: 'brand' },
      { title: this.translateService.instant('app.type'), dataKey: 'type' },
      { title: this.translateService.instant('app.category'), dataKey: 'category' },
      { title: this.translateService.instant('app.model'), dataKey: 'model' },
      {
        title: this.translateService.instant('app.cylinder_capacity'),
        dataKey: 'cylinder_capacity'
      },
      { title: this.translateService.instant('app.fuel'), dataKey: 'fuel' }
    ];
    const rows = [];

    this.apiService.get('product').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            id: items[i].id,
            brand: items[i].brand,
            type: items[i].type,
            category: items[i].category,
            model: items[i].model,
            cylinder_capacity: items[i].cylinder_capacity,
            fuel: items[i].fuel
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(columns, rows, {
          theme: 'striped',
          addPageContent: function(data) {
            doc.text('Products', 40, 30);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }
}
