import { Component, OnInit, OnDestroy, ViewChild, ElementRef, Renderer } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FlashMessagesService } from 'angular2-flash-messages';
import { LocalStorageService } from 'ngx-webstorage';

import { ApiService, Product, Attachment } from '../../../core';
import { fadeIn } from '../../../shared/animations';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  animations: [fadeIn()]
})
export class ProductFormComponent implements OnInit, OnDestroy {
  types = [
    { id: 'DIESEL', name: 'Diesel' },
    { id: 'ELECTRIC', name: 'Electric' },
    { id: 'GASOLINE', name: 'Gasoline' },
    { id: 'LPG', name: 'LPG' }
  ];
  id: number = null;
  vendors: any;
  form: FormGroup;
  img_src = 'assets/img/no-image.png';
  img_added = false;
  @ViewChild('file_attachment')
  file_attachment: ElementRef;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private apiService: ApiService,
    private flashMessage: FlashMessagesService,
    private localStorageService: LocalStorageService,
    private renderer: Renderer
  ) {}

  ngOnInit() {
    this.form = new FormGroup(
      {
        vendor: new FormGroup({
          id: new FormControl('', {
            validators: [Validators.required]
          })
        }),
        brand: new FormControl('', {
          validators: [Validators.required, Validators.minLength(3)]
        }),
        type: new FormControl('', {
          validators: Validators.required
        }),
        category: new FormControl('', {
          validators: Validators.required
        }),
        model: new FormControl('', {
          validators: Validators.required
        }),
        cylinder_capacity: new FormControl('', {
          validators: Validators.required
        }),
        fuel: new FormControl('', {
          validators: Validators.required
        }),
        basic_price: new FormControl('', {
          validators: Validators.required
        }),
        picture: new FormControl('', {}),
        vendorid: new FormControl('', {})
      },
      { updateOn: 'blur' }
    );
    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (!this.id) {
        return;
      }
      return this.apiService.get('product/' + this.id).subscribe((data: Product) => {
        this.form.patchValue({
          vendor: { id: data.vendor_id },
          vendorid: data.vendor_id,
          brand: data.brand,
          type: data.type,
          category: data.category,
          model: data.model,
          cylinder_capacity: data.cylinder_capacity,
          basic_price: data.basic_price,
          fuel: data.fuel,
          picture: data.picture
        });
        this.img_src = data.picture;
      });
    });

    const company_active = this.localStorageService.retrieve('user_company_active');
    this.apiService
      .get('vendor?sort=vendorName,asc&company_id=' + company_active)
      .subscribe((data: any) => {
        const content = [];
        for (let i = 0; i < data.content.length; i++) {
          content.push({ id: data.content[i].id, name: data.content[i].vendor_name });
        }
        this.vendors = content;
      });
  }

  /**
   * Show popup dialog for choosing image
   */
  showDialog(event) {
    const eventClick = new MouseEvent('click', { bubbles: true });
    this.renderer.invokeElementMethod(this.file_attachment.nativeElement, 'dispatchEvent', [
      eventClick
    ]);
  }

  /**
   * Preview uploaded image
   */
  preview(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        this.img_src = e.target.result;
        this.img_added = true;
      };
    }
  }

  /**
   * Save new product data (attachment)
   */
  save() {
    if (this.form.valid) {
      this.form.patchValue({
        vendorid: this.form.get('vendor.id').value
      });

      if (this.img_added) {
        const inputEl: HTMLInputElement = this.file_attachment.nativeElement;
        const formData = new FormData();
        formData.append('file', inputEl.files.item(0));
        this.apiService.post('attach', formData).subscribe(
          (response: any) => {
            this.form.get('picture').patchValue(response.body.file_download_uri);
            this.saveForm();
          },
          error => {
            console.log(error);
          }
        );
      } else {
        this.saveForm();
      }
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /**
   * Save new product data (form entries)
   */
  saveForm() {
    let result_input: any;
    if (!this.id) {
      result_input = this.apiService.post('product/', this.form.value);
    } else {
      result_input = this.apiService.put('product/' + this.id, this.form.value);
    }
    result_input.subscribe(
      success => {
        if (!this.id) {
          const response_location = success.headers.get('location').split('/');
          this.id = response_location[response_location.length - 1];
        }
        const redirect_page = this.route.snapshot.params['page'];
        if (redirect_page === 'submissions') {
          this.router.navigate(['transaction/submissions/create', { product: this.id }]);
        } else {
          this.router.navigate(['master/products']);
        }
      },
      error => {
        this.flashMessage.show(error.error.message, {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        console.log(error);
      }
    );
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnDestroy(): void {
    this.vendors = false;
  }
}
