import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent } from './product.component';
import { ProductDetailsComponent } from './product-details.component';
import { ProductFormComponent } from './product-form.component';

const routes: Routes = [
  {
    path: '',
    component: ProductComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: ProductFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: ProductFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id',
    component: ProductDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule {}
