import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl
} from '@angular/forms';

import { FlashMessagesService } from 'angular2-flash-messages';
import { fadeIn } from '../../../shared/animations';
import { ApiService } from '../../../core/services';
import { SampleService, User, Master } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';


/**
 * User form component
 */
@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  animations: [fadeIn()]
})
export class UserFormComponent implements OnInit, OnDestroy {
  [x: string]: any;
  url = 'user/';
  id: number = null;
  // role = [
  //   { id: 'Administrator', name: 'Administrator' },
  //   { id: 'Accounting', name: 'Accounting' },
  //   { id: 'Finance', name: 'Finance' },
  //   { id: 'Operational', name: 'Operational' }
  // ];
  // status = [
  //   {id: 'active', name: 'Active'},
  //   {id: 'inactive', name: 'Inactive'}
  // ];
  selectedValue = null;
  row: any = [];
  form: FormGroup;
  // role_to_id = 0;
  roles: any;
  selected_roles_id;
  selected_roles_name;
  // localStorageService: any;
  idRole: any;
  roleTo: boolean;
  role_id: any;
  role_name: any;
  detailCompanyTo: boolean;
  company_name_detail: any;
  company: any[];
  company_id: any;
  company_name: any;
  is_add = false;

  passwordConfirmation = false;
  is_edit = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private apiService: ApiService,
    private localStorageService: LocalStorageService,
    private flashMessage: FlashMessagesService,
    private sampleService: SampleService
  ) {
    this.row = this.sampleService.getUser();
    // console.log(this.row);
  }

  ngOnInit() {
    this.loadCompany();
    this.loadRole();
      this.form = new FormGroup(
        {
          complete_name: new FormControl('', {
            validators: [Validators.required]
          }),
          username: new FormControl('', {
            validators: [Validators.required]
          }),
          email: new FormControl('', {
            validators: [Validators.required, Validators.email]
          }),
          company_name: new FormControl('', {
            validators: [Validators.required]
          }),
          name: new FormControl('', {
            validators: [Validators.required]
          }),
        password: new FormControl('', {
          validators: [Validators.required]
        }),
        confirm_password: new FormControl('', {
          // validators: this.passwordValidator
        }),
        old_password: new FormControl('', {
        })
      },
        { updateOn: 'blur' }
      );
      // this.route.params.subscribe(params => {
      //   this.id = params['id'];
      //   if (!this.id) {
      //     return;
      this.route.params.subscribe(params => {
        this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
        if (!this.id) {
          this.is_add = true;
          return;
        }
        this.is_edit = true;
        this.is_add = false;
        this.apiService.get('user/' + this.id).subscribe((data: any) => {
          console.log(data);
          this.form.patchValue(
            {
              complete_name: data.complete_name,
              username: data.username,
              email: data.email,
              company_name: data.companys[0].company_name,
              name: data.roles[0].name
            });
        });
    });
  }
loadCompany(): any {
      this.apiService
      .get('company')
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              company_name: el.company_name,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.company = [...items];
      });
  }

loadRole(): any {
  this.apiService
      .get('role')
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              name: el.name,
            });
        });
        this.roles = [...items];
  }
);
 }
   selectRoles(value) {
    console.log(value);
    this.selected_roles_id = value.id;
    this.selected_roles_name = value.name;
  }
  selectCompany(event) {
    console.log(event);
    if (event.id) {
      this.detailCompanyTo = true;
      this.company_name_detail = event.company_name;
    }
  }

  save() {

    // const form_post = {
    //   "complete_name": "Complete Name",
    //   "username": "username",
    //   "email": "email@gmail.com",
    //   "password": "test-123",
    //   "name": "ROLE_ADMIN",
    //   "company_name": "PT. Mobe Dwipantara"
    // };
    console.log(this.form.valid);
    if (this.form.valid) {
      if (this.form.value.password) {
      if (this.form.value.password !== this.form.value.confirm_password) {
        alert('password mismatch!');
      return false;
    }
      let result: any;
      if (!this.id) {
        result = this.apiService.post('auth/signup/', this.form.value);
      } else {
        result = this.apiService.put('user/' + this.id, this.form.value);
      }
      result.subscribe(
        success => {
          console.log('Location URL: ' + success.headers.get('location'));
          this.router.navigate(['setting/user']);
        },
        error => {
          // this.flashMessage.show(error.error.message, {
          //   cssClass: 'alert-danger',
          //   showCloseBtn: true
          // });
          // console.log(error);
           alert('Email Address already in use!');
        }
      );
    } else {
      this.validateAllFormFields(this.form);
  }
  }
}

  back() {
    this.location.back();
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnDestroy(): void {
    this.row = false;
  }
}
