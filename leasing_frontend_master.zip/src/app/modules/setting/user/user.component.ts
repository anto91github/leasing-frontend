import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { DxDataGridComponent } from 'devextreme-angular';

import { SampleService, User } from '../../../core';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { Router } from '@angular/router';
import { fadeIn } from '../../../shared/animations';
import { Master } from '../../../core/models';
import { ConfigService, ApiService } from '../../../core/services';
import { LocalStorageService } from 'ngx-webstorage';
import CustomStore from 'devextreme/data/custom_store';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styles: [],
  animations: [fadeIn()]
})
export class UserComponent implements OnInit {
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  route = 'setting/user';
  dataGridSource: any = {};
  row: any = [];
  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private location: Location,
    private sampleService: SampleService,
    private router: Router,
    private translateService: TranslateService,
    private localSt: LocalStorageService,
    private config: ConfigService,
  ) {
    this.title = this.translateService.instant('sys.user');

    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'setting.user.view';
    this.page_create_permission = 'setting.user.create';
    this.page_edit_permission = 'setting.user.edit';
    this.page_delete_permission = 'setting.user.delete';
    this.page_print_permission = 'setting.user.print';
    this.page_export_permission = 'setting.user.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.user')
      );
      this.location.back();
    }
    this.dataGridSource.store = new CustomStore({
      load: function(options: any) {
        options.userData.user_id = true;
        return apiServiceInject.getMaster('user', options);
      },
      remove: function(row) {
        return apiServiceInject
          .delete('user/' + row.id)
          .toPromise()
          .then(
            () => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
  }
  ngOnInit() {
  }

  actionRefresh() {}

  actionAdd() {
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
          this.translateService.instant('app.user')
      );
      return false;
    }
    this.router.navigate([this.route, 'create']);
  }

  actionDetails(id) {
  this.router.navigate([this.route, id]);
}

  actionEdit(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
          this.translateService.instant('app.user')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete(row) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_delete') +
          this.translateService.instant('app.user')
      );
      return false;
    }
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }
  // verifyCode() {
  //   // console.log(this.formProduct.value.security_code);
  //   if (this.form.value.security_code === '123') {
  //     this.popupVisible = false;
  //     this.formulaVisible = true;
  //   } else {
  //     alert ('Wrong security code');
  //   }
  // }


  actionPrint() {}

  /*actionPdf() {
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.name'), dataKey: 'name' },
      { title: this.translateService.instant('app.full-name'), dataKey: 'full-name' },
      { title: this.translateService.instant('app.email'), dataKey: 'email' },
      { title: this.translateService.instant('app.role'), dataKey: 'role' },
      { title: this.translateService.instant('app.status'), dataKey: 'status' }
    ];
    const rows = [];

    this.apiService.get('vendor').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            name: items[i].vendor_name,
            type: items[i].vendor_type,
            address: items[i].address,
            phone: items[i].phone,
            fax: items[i].fax,
            email: items[i].email,
            web: items[i].web
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(columns, rows, {
          addPageContent: function(data) {
            doc.text('Vendor', 40, 30);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        const uristring = doc.output('datauristring');
        const iframe = '<iframe width=\'100%\' height=\'100%\' src=\'' + uristring + '\'></iframe>';
        const x = window.open();
        x.document.open();
        x.document.write(iframe);
        x.document.close();
      },
      error => {
        console.log(error);
      }
    );
  }*/

  actionPdf(value) {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.user')
      );
      return false;
    }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.fullname'), dataKey: 'complete_name' },
      { title: this.translateService.instant('app.name'), dataKey: 'username' },
      { title: this.translateService.instant('app.email'), dataKey: 'email' },
      { title: this.translateService.instant('app.company_name'), dataKey: 'company_name' },
      { title: this.translateService.instant('sys.role'), dataKey: 'name' }
    ];
    const rows = [];

    // this.sampleService.getUserSample().subscribe(
    //   (items: User[]) => {
    //     for (let i = 0; i < items.length; i++) {
    //       rows.push({
    //         no: `${i + 1}.`,
    //         name: items[i].username,
    //         fullname: items[i].name,
    //         email: items[i].email,
    //         role: items[i].role,
    //         status: items[i].status
    //       });
    //     }
        this.apiService.get('user').subscribe(
          (success: any) => {
            const items = success.content;
            for (let i = 0; i < items.length; i++) {
              rows.push({
                no: `${i + 1}.`,
                username: items[i].username,
                complete_name: items[i].complete_name,
                email: items[i].email,
                name: items[i].roles[0].name,
                company_name : items[i].companys[0].company_name
              });
              console.log(items);
            }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(columns, rows, {
          theme: 'striped',
          margin: { top: 60 },
          addPageContent: function(data) {
            doc.text('User', 40, 30);
          },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.user')
      );
      return false;
    }
    this.apiService.get('user').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            [this.translateService.instant('app.fullname')]: el.complete_name,
            [this.translateService.instant('app.name')]: el.username,
            [this.translateService.instant('app.email')]: el.email,
            [this.translateService.instant('app.company_name')]: el.companys[0].company_name,
            [this.translateService.instant('app.role_name')]: el.roles[0].name
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }
}
