import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { User } from './../../../core/models';
import { ApiService } from '../../../core/services';

/**
 * Dealer detail component
 */
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  animations: [fadeIn()]
})
export class UserDetailsComponent implements OnInit, OnDestroy {
    user: User;

  constructor(
    private location: Location,
    private apiService: ApiService,
    private route: ActivatedRoute,
  ) {}

  /**
   * Get data master
   */
  ngOnInit() {
    const id = this.route.snapshot.params.id;
    return this.apiService.get('user/' + id).subscribe((data: User) => {
      this.user = data;
    //   console.log(data);
    });
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  /**
   * Unsubscribe master data
   */
  ngOnDestroy(): void {
    // this.user = false;
  }
}
