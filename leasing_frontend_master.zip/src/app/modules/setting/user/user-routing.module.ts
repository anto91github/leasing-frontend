import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { UserFormComponent } from './user-form.component';
import { UserDetailsComponent } from './user-details.component';

const routes: Routes = [
  {
    path: '',
    component: UserComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: UserFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: UserFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id',
    component: UserDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule {}
