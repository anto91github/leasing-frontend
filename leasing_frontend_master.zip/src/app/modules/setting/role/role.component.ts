import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { DxDataGridComponent } from 'devextreme-angular';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';


import { Role, SampleService } from '../../../core';
import { Router } from '@angular/router';
import { fadeIn } from '../../../shared/animations';
import { Master } from '../../../core/models';
import CustomStore from 'devextreme/data/custom_store';
// import { ConfigService, ApiService } from '../../../core/services';
import { ApiService, ConfigService } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  providers: [TranslateService],
  animations: [fadeIn()]
})
export class RoleComponent implements OnInit {
  [x: string]: any;
  // row: any = [];
  // @ViewChild(DxDataGridComponent) dataGrid: DxDataGridComponent;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  route = 'setting/role';
  // dataGridSource: Role[];
  dataGridSource: any = {};
  dataGridPageSize = 10;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private location: Location,
    private sampleService: SampleService,
    private router: Router,
    private translateService: TranslateService,
    private config: ConfigService,
    private localSt: LocalStorageService
  ) {
    this.title = this.translateService.instant('sys.role');

    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'setting.role.view';
    this.page_create_permission = 'setting.role.create';
    this.page_edit_permission = 'setting.role.edit';
    this.page_delete_permission = 'setting.role.delete';
    this.page_print_permission = 'setting.role.print';
    this.page_export_permission = 'setting.role.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }

    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.role')
      );
      this.location.back();
    }

    this.dataGridSource.store = new CustomStore({
      load: function(options: any) {
        return apiServiceInject.getMaster('role', options);
      }/*,
      remove: function(row) {
        return apiServiceInject
          .delete('vendor/' + row.id)
          .toPromise()
          .then(
            data => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }*/
    });


    this.dataGridPageSize = config.getConfig('paginationLength');
  }

  ngOnInit() {}

  actionRefresh() {}

  actionAdd() {
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
          this.translateService.instant('app.role')
      );
      return false;
    }
    this.router.navigate([this.route, 'create']);
  }

  actionDetails() {}

  actionEdit(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
          this.translateService.instant('app.role')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete() {}

  actionPrint() {}

  actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.role')
      );
      return false;
    }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.name'), dataKey: 'name' }
    ];
    const rows = [];

    this.sampleService.getRoleSample().subscribe(
      (items: Role[]) => {
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            name: items[i].name
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(columns, rows, {
          theme: 'striped',
          margin: { top: 60 },
          addPageContent: function(data) {
            doc.text('Role', 40, 30);
          }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.role')
      );
      return false;
    }
    this.sampleService.getRoleSample().subscribe(
      (items: Role[]) => {
        const table = [];
        items.forEach(el => {
          table.push({
            [this.translateService.instant('app.name')]: el.name
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }
}
