import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RoleComponent } from './role.component';
import { RoleFormComponent } from './role-form.component';

const routes: Routes = [
  {
    path: '',
    component: RoleComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: RoleFormComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: ':id/edit',
    component: RoleFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleRoutingModule {}
