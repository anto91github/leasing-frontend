import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl
} from '@angular/forms';
import { FlashMessagesService } from 'angular2-flash-messages';

import { fadeIn } from '../../../shared/animations';
import { SampleService, ApiService, Role } from '../../../core';

/**
 * User form component
 */
@Component({
  selector: 'app-role-form',
  templateUrl: './role-form.component.html',
  animations: [fadeIn()]
})
export class RoleFormComponent implements OnInit, OnDestroy {
  url = 'role/';
  role = [
    { id: 'Administrator', name: 'Administrator' },
    { id: 'Accounting', name: 'Accounting' },
    { id: 'Finance', name: 'Finance' },
    { id: 'Operational', name: 'Operational' }
  ];
  status = [{ id: 'active', name: 'Active' }, { id: 'inactive', name: 'Inactive' }];
  selectedValue = null;
  id: number = null;
  row: any = [];
  row_detail: any = [];
  // row_permission: any = {};
  row_permission: any = [];
  split: any = [];
  form: FormGroup;
  roles: any;
  roles_test = ['a', 'b', 'c'];
  keys: String[];
  permissions: any = [];
  permissions2: any = [];
  permissions_id: any = [];

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private flashMessage: FlashMessagesService,
    private sampleService: SampleService
  ) {
    this.row = this.sampleService.getUser();
  }

  ngOnInit() {
    const options: any = {};
    options.take = 900;
    options.skip = 100;

    this.route.params.subscribe(params => {
      this.id = params['id'];
      // for edit role

      this.apiService.get('role/' + this.id).subscribe((data2: any) => {
        this.row_permission = data2;
        for (const module2 of data2.access_collection) {
          this.permissions[module2.permission] = true;
          this.permissions_id.push(module2.id);
        }
      });

      this.apiService.get('module?page=0&size=500').subscribe((data: any) => {
        this.row_detail = data.content; // use for loop accordion in view
        for (const module of this.row_detail) {
          for (const page of module.page_collection) {
            for (const permission of page.permission_collection) {
              // check if Add or Edit
              if (!this.id) {
                // ADD PAGE
                this.permissions[permission.permission] = false; // use for check or un-check checkbox
              }
            }
          }
        }
      });

      this.apiService.get('role/' + this.id).subscribe(data => {
        this.row = data;
      });

      /*if (!this.id) {
        this.permissions[permission.permission] = false;
      }*/
      /*this.apiService.get('role/' + this.id).subscribe(data => {
        this.row = data;
      });*/

      /*const data = this.sampleService.getRole();
      const data_2 = data[this.id - 1];
      console.log(this.id);
      console.log(data);
      return (this.row = data_2);*/
    });

    this.form = new FormGroup(
      {
        role: new FormControl('', {
          validators: [Validators.required, Validators.minLength(3)]
        }),
        description: new FormControl('', {
          validators: [Validators.required]
        })
      },
      { updateOn: 'blur' }
    );
    console.log(this.form.get('role').value);
  }
  selectAll(event, module, page, permission_collection) {
    if (event.target.checked) {
      this.permissions[module + '.' + page + '.create'] = true;
      this.permissions[module + '.' + page + '.edit'] = true;
      this.permissions[module + '.' + page + '.export'] = true;
      this.permissions[module + '.' + page + '.delete'] = true;
      this.permissions[module + '.' + page + '.print'] = true;
      this.permissions[module + '.' + page + '.view'] = true;

      for (const pm of permission_collection) {
        this.permissions_id.push(pm.id);
      }
    } else {
      this.permissions[module + '.' + page + '.create'] = false;
      this.permissions[module + '.' + page + '.edit'] = false;
      this.permissions[module + '.' + page + '.export'] = false;
      this.permissions[module + '.' + page + '.delete'] = false;
      this.permissions[module + '.' + page + '.print'] = false;
      this.permissions[module + '.' + page + '.view'] = false;

      for (const pm of permission_collection) {
        for (let i = 0; i <= this.permissions_id.length - 1; i++) {
          if (this.permissions_id[i] === pm.id) {
            this.permissions_id.splice(i, 1);
          }
        }
      }
    }
  }

  isSelected(event, privilage_permission, permission_id) {
    if (event.target.checked) {
      this.permissions_id.push(permission_id);
    } else {
      // this.permissions_id.splice(privilage_permission, 1);
      for (let i = 0; i <= this.permissions_id.length - 1; i++) {
        if (this.permissions_id[i] === permission_id) {
          this.permissions_id.splice(i, 1);
        }
      }
    }
  }

  save() {
    // console.log(this.permissions);
    console.log(this.permissions_id);
    console.log(this.form.value);
    return false;
    if (this.form.valid) {
      let result: any;
      if (!this.id) {
        result = this.apiService.post('role/', this.form.value);
      } else {
        result = this.apiService.put('role/' + this.id, this.form.value);
      }
      result.subscribe(
        success => {
          console.log('Location URL: ' + success.headers.get('location'));
          this.router.navigate(['setting/user']);
        },
        error => {
          this.flashMessage.show(error.error.message, {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
          console.log(error);
        }
      );
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  back() {
    this.location.back();
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnDestroy(): void {
    this.row = false;
  }
}
