import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-form',
  templateUrl: './policy-form.component.html',
  styleUrls: ['./policy-form.component.scss']
})
export class PolicyFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
