import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfilesComponent } from './profiles.component';
import { SettingsComponent } from './settings.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/user/profiles',
    pathMatch: 'full'
  },
  {
    path: 'profiles',
    component: ProfilesComponent,
    data: {
      breadcrumb: 'sys.profiles'
    }
  },
  {
    path: 'settings',
    component: SettingsComponent,
    data: {
      breadcrumb: 'sys.settings'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
