import { Component, OnInit, Inject } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';
import { NgbModal, NgbModalRef, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Location } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormControl
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../../core';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styles: [],
  providers: [TranslateService]
})
export class ProfilesComponent implements OnInit {
  user_name: any;
  user_email: any;
  user_role: any;
  company: any;
  company_address: any;
  company_email: any;
  company_fax: any;
  company_phone: any;
  private modalRef: NgbModalRef;
  closeResult: string;
  form: FormGroup;
  id: number = null;
  messageSuccess: any;

  constructor(
    private localStorage: LocalStorageService,
    private modalService: NgbModal,
    private location: Location,
    private apiService: ApiService,
    private router: Router,
    private flashMessage: FlashMessagesService,
    private translateService: TranslateService,
    private formBuilder: FormBuilder,
  ) {
    this.user_name = localStorage.retrieve('user_details').username;
    this.user_email = localStorage.retrieve('user_details').email;
    this.user_role = localStorage.retrieve('user_roles')[0].name;
    this.company = localStorage.retrieve('user_companies')[0].company_name;
    this.company_address = localStorage.retrieve('user_companies')[0].address;
    this.company_email = localStorage.retrieve('user_companies')[0].email;
    this.company_fax = localStorage.retrieve('user_companies')[0].fax;
    this.company_phone = localStorage.retrieve('user_companies')[0].phone;
  }

  ngOnInit() {
    this.form = new FormGroup(
    {
    password: new FormControl('', {
      validators: [Validators.required]
    }),
    confirm_password: new FormControl('', {
      // validators: this.passwordValidator
    }),
    old_password: new FormControl('', {
    })
  },
    { updateOn: 'blur' }
  );
  }
  openModal(content) {
    this.modalRef = this.modalService.open(content);
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
        this.closeResult = `Dismissed ${reason}`;
    });
  }

  closeModal() {
    this.modalRef.close();
  }
  async save() {
    console.log(this.form.valid);
    if (this.form.valid) {
      if (this.form.value.old_password) {
        if (this.form.value.password !== this.form.value.confirm_password) {
          // alert('password mismatch');
          this.flashMessage.show('password mismatch', {
            cssClass: 'alert-danger',
            showCloseBtn: true,
            dalay: 3600
          });
          return false;
        }
        let ceckOldPassword: any;
        const form_ceck = {
            old_password: this.form.value.old_password,
            new_password: this.form.value.confirm_password
          };
        ceckOldPassword = this.apiService.post('auth/change_password', form_ceck);
        ceckOldPassword.subscribe(
              success => {
                  // this.messageSuccess = success.body.message;
                this.flashMessage.show(success.body.message, {
                  cssClass: 'alert-success',
                  showCloseBtn: true,
                });
                 this.closeModal();
                 alert('Your password has been changed successfully!');
              },
            error => {
              console.log(error);
              this.flashMessage.show(error.error.message, {
                cssClass: 'alert-danger',
                showCloseBtn: true
              });
            }
          );
      }
   }
  //  await this.flashMessage.show(this.messageSuccess, {
  //   cssClass: 'alert-success',
  //   showCloseBtn: true
  // });
  }

}
