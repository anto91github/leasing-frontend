import { Component, OnInit } from '@angular/core';

import { LocalStorageService } from 'ngx-webstorage';
import { Location } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-finance',
  templateUrl: './finance.component.html',
  providers: [TranslateService]
})
export class FinanceComponent implements OnInit {
  page_view_permission: string;
  page_create_permission: string;
  page_edit_permission: string;
  page_delete_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_create: boolean;
  allow_edit: boolean;
  allow_delete: boolean;
  allow_print: boolean;
  allow_export: boolean;

  constructor(
    private location: Location,
    private localSt: LocalStorageService,
    private translateService: TranslateService
  ) {
    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'report.finance.view';
    this.page_create_permission = 'report.finance.create';
    this.page_edit_permission = 'report.finance.edit';
    this.page_delete_permission = 'report.finance.delete';
    this.page_print_permission = 'report.finance.print';
    this.page_export_permission = 'report.finance.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.finance')
      );
      this.location.back();
    }
  }

  ngOnInit() {}

  actionRefresh() {}

  actionAdd() {}
}
