import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxBoxModule,
  DxNumberBoxModule
} from 'devextreme-angular';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { SimulationRoutingModule } from './simulation-routing.module';
import { SimulationComponent } from './simulation.component';

@NgModule({
  imports: [
    NgbModule,
    CommonModule,
    SimulationRoutingModule,
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxBoxModule,
    DxNumberBoxModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [SimulationComponent]
})
export class SimulationModule {}
