import { Component, OnInit, ViewChild, Inject, QueryList, ViewChildren } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent
} from 'devextreme-angular';
import notify from 'devextreme/ui/notify';
import { DxDataGridComponent } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

import { fadeIn } from '../../../shared/animations';
import { ApiService, SampleService } from './../../../core';
import { Simulation } from '../../../core/models/simulation.model';

import { LocalStorageService } from 'ngx-webstorage';
import { DatePipe, formatCurrency } from '@angular/common';

@Component({
  selector: 'app-simulation',
  templateUrl: './simulation.component.html',
  styleUrls: ['./simulation.component.scss'],
  providers: [ApiService, TranslateService],
  animations: [fadeIn()]
})
export class SimulationComponent implements OnInit {
  title: any;
  options: any = {};
  @ViewChild(DxRadioGroupComponent)
  radio_status: DxRadioGroupComponent;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  @ViewChildren(DxDropDownBoxComponent)
  dropdownBox: QueryList<DxDropDownBoxComponent>;
  dataGridSource: any = {};
  route = 'transaction/simulation';
  types = ['Flat', 'Floating'];

  productDataSource: any;
  productDetailDataSource: any;

  _productValue: number;
  _productDetailValue: number;

  _productSelectedRowKeys: number[];
  _productDetailSelectedRowKeys: number[];

  productSelectedID: any;
  productDetailSelectedID: any;
  stockCollection: any;
  _productPrice: any;

  _simulationDP: number;
  _simulationQty: number;
  _interest: number;
  _period: number;
  // _types: any;

  tipe: number;
  brand: string;
  manufacture_year: string;
  vin: string;
  price: number;
  credit_type: string;
  down_payment: number;
  qty: number;

  page_view_permission: string;
  page_create_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_create: boolean;
  allow_print: boolean;
  allow_export: boolean;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private location: Location,
    private translateService: TranslateService,
    private router: Router,
    private apiService: ApiService,
    private sampleService: SampleService,
    private localSt: LocalStorageService,
    private datePipe: DatePipe
  ) {
    this.title = this.translateService.instant('app.simulation');
    this.dataGridSource.store = [{}];

    this.allow_view = false;
    this.allow_create = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'transaction.simulation.view';
    this.page_create_permission = 'transaction.simulation.create';
    this.page_print_permission = 'transaction.simulation.print';
    this.page_export_permission = 'transaction.simulation.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.simulation')
      );
      this.location.back();
    }

    /*this.dataGridSource.store = new CustomStore({
      load: function(options: any) {
        return [];
      }
    });*/
    this.productDataSource = new CustomStore({
      loadMode: 'raw',
      key: 'id',
      load: function() {
        return apiService.getContent('product');
      }
    });
  }

  ngOnInit() {}

  get productValue(): number {
    return this._productValue;
  }

  set productValue(value: number) {
    this._productSelectedRowKeys = (value && [value]) || [];
    this._productValue = value;
  }

  get productPrice(): number {
    return this._productPrice;
  }

  set productPrice(value: number) {
    this._productPrice = value;
  }

  get productSelectedRowKeys(): number[] {
    return this._productSelectedRowKeys;
  }

  set productSelectedRowKeys(value: number[]) {
    this._productValue = (value.length && value[0]) || null;
    this._productSelectedRowKeys = value;
  }

  /*Product Detail Dropdown Function*/
  get productDetailValue(): number {
    return this._productDetailValue;
  }

  set productDetailValue(value: number) {
    this._productDetailSelectedRowKeys = (value && [value]) || [];
    this._productDetailValue = value;
  }

  get productDetailSelectedRowKeys(): number[] {
    return this._productDetailSelectedRowKeys;
  }

  set productDetailSelectedRowKeys(value: number[]) {
    this._productDetailValue = (value.length && value[0]) || null;
    this._productDetailSelectedRowKeys = value;
  }

  /**
   * Close dropdownbox after value selected
   */
  dropdownBoxChange(event) {
    this.productSelectedID = event.value;
    const hasil = this.apiService.getStockCollection('product/' + this.productSelectedID);

    this.productDetailDataSource = new CustomStore({
      loadMode: 'raw',
      key: 'id',
      load: function() {
        return hasil;
      }
    });

    this.dropdownBox.forEach(el => {
      el.instance.close();
    });
  }

  setPrice(event) {
    this.productDetailSelectedID = event.value;
    // this.apiService.get('product/' + this.productSelectedID).subscribe(
    //   success_price => {
    //     this.stockCollection = success_price['stock_collection'];
    //     this.productPrice = this.stockCollection.find(
    //       x => x.id === this.productDetailSelectedID
    //     ).price;
    //   },
    //   error => {
    //     console.log(error);
    //   }
    // );
    this.apiService.get('product/' + this.productDetailSelectedID).subscribe(
      success_price => {
        console.log(success_price);
        this.productPrice = success_price['basic_price'];
      }
    );

    this.dropdownBox.forEach(el => {
      el.instance.close();
    });
  }

  productLabel(item) {
    return item && item.brand + ' - ' + item.type;
  }

  productDetailLabel(item) {
    return item && item.manufacture_year + ' - ' + item.vin;
  }

  set simulationDP(value: number) {
    this._simulationDP = value;
  }

  get simulationDP(): number {
    return this._simulationDP;
  }

  set simulationQty(value: number) {
    this._simulationQty = value;
  }

  get simulationQty(): number {
    return this._simulationQty;
  }

  set interest(value: number) {
    this._interest = value;
  }

  get interest(): number {
    return this._interest;
  }

  set period(value: number) {
    this._period = value;
  }

  get period(): number {
    return this._period;
  }

  // set types(value: any) {
  //   this._types = ['Flat', 'Floating'];
  // }

  // get types(): any {
  //   return this._types;
  // }

  calculate(event) {
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
          this.translateService.instant('app.simulation')
      );
      return false;
    }
    // const options: any = {};

    if (this.simulationDP >= this.productPrice * this.simulationQty) {
      alert(this.translateService.instant('alert.dp_less'));
      return false;
    }
    this.apiService.get('product/' + this.productValue).subscribe(
      success_value => {
        console.log(success_value);
        this.options.tipe = success_value['type'];
        this.tipe = this.options.tipe;

        this.options.loan_type = 1; // flat rate
        const date_now = new Date();
        this.options.start_date = this.datePipe.transform(date_now, 'yyyy-MM-dd');

        this.options.brand = success_value['brand'];
        this.brand = this.options.brand;

        // this.options.manufacture = success_value['stock_collection'].find(
        //   x => x.id === this.productDetailSelectedID
        // ).manufacture_year;
        // this.manufacture_year = this.options.manufacture;

        // this.options.vin = success_value['stock_collection'].find(
        //   x => x.id === this.productDetailSelectedID
        // ).vin;
        // this.vin = this.options.vin;

        this.options.qty = this.simulationQty;
        this.qty = this.options.qty;

        this.options.loan_amount = this.options.qty * this.productPrice;
        this.price = this.options.loan_amount;

        // this.options.loan_amount = success_value['stock_collection'].find(
        //   x => x.id === this.productDetailSelectedID
        // ).price;
        // this.price = this.options.loan_amount;

        /*options.credit_type = this.radio_status.instance.option('value');
        this.credit_type = options.credit_type;*/
        this.credit_type = 'Flat';

        this.options.down_payment = this.simulationDP;
        this.down_payment = this.options.down_payment;

        this.options.interest_rate = this.interest;
        this.interest = this.options.interest_rate;

        this.options.loan_term_in_month = this.period;
        this.period = this.options.loan_term_in_month;
        this.apiService.post('loan/simulation/', this.options).subscribe(
          success_job => {
            this.dataGrid.instance.refresh();
            this.dataGridSource = success_job.body;
            event.preventDefault();
          },
          error => {
            console.log(error);
          }
        );
      },
      error => {
        console.log(error);
      }
    );

    /*this.dataGrid.instance.refresh();
    this.dataGridSource = this.apiService.getSimulation('leasing', options);*/
    event.preventDefault();
  }

  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.simulation')
      );
    }
    const today_date = new Date().toLocaleString('id-ID', {
      year: 'numeric',
      month: 'numeric',
      day: 'numeric'
    });

    if (this.dataGridSource.length === undefined) {
      alert(this.translateService.instant('alert.calcu_first'));
    } else {
      const header = [
        ['Simulation'],
        [today_date],
        [
          this.translateService.instant('app.brand'),
          this.brand,
          '',
          this.translateService.instant('app.type'),
          this.credit_type
        ],
        [
          this.translateService.instant('app.type'),
          this.tipe,
          '',
          this.translateService.instant('app.down_payment'),
          this.down_payment
        ],
        [
          // this.translateService.instant('app.manufacture_year'),
          // this.manufacture_year,
          this.translateService.instant('app.price'),
          this.price,
          '',
          this.translateService.instant('app.interest'),
          this.interest
        ],
        [
          this.translateService.instant('app.qty') + ':',
          this.qty,
          '',
          this.translateService.instant('app.period'),
          this.period
        ]
      ];

      console.log(header);
      // this.sampleService.getSimulation().subscribe(
      this.apiService.post('loan/simulation/', this.options).subscribe(
        (response: any) => {
          const items = response.body;
          const table = [];
          items.forEach(el => {
            table.push({
              [this.translateService.instant('app.due_date')]: this.datePipe.transform(
                el.payment_date,
                'yyyy-MM-dd'
              ),
              [this.translateService.instant('app.remaining_amount')]: el.balance,
              [this.translateService.instant('app.amount')]: el.principal_paid,
              [this.translateService.instant('app.interest')]: el.interest_paid,
              [this.translateService.instant('app.total_amount')]: el.payment_amount
            });
          });
          const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(header);
          // const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet([header2], {header:header2, skipHeader:false})

          XLSX.utils.sheet_add_json(ws, table, { origin: 'A8' });

          const wb: XLSX.WorkBook = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, this.title);
          XLSX.writeFile(wb, `${this.title}.xlsx`);
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.simulation')
      );
    }
    if (this.dataGridSource.length === undefined) {
      alert(this.translateService.instant('alert.calcu_first'));
    } else {
      const columns = [
        { title: 'No', dataKey: 'no' },
        { title: this.translateService.instant('app.due_date'), dataKey: 'payment_date' },
        {
          title: this.translateService.instant('app.remaining_amount'),
          dataKey: 'balance'
        },
        { title: this.translateService.instant('app.amount'), dataKey: 'principal_paid' },
        { title: this.translateService.instant('app.interest'), dataKey: 'interest_paid' },
        { title: 'Total', dataKey: 'payment_amount' }
      ];
      const rows = [];
      const today_date = new Date().toLocaleString('id-ID', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric'
      });

      const columns_head = ['', '', '', ''];
      const rows_head = [
        [
          this.translateService.instant('app.brand') + ':',
          this.brand,
          this.translateService.instant('app.type') + ':',
          this.credit_type
        ],
        [
          this.translateService.instant('app.type') + ':',
          this.tipe,
          this.translateService.instant('app.down_payment') + ':',
          this.down_payment
        ],
        [
          this.translateService.instant('app.price') + ':',
          this.price,
          this.translateService.instant('app.interest') + ':',
          this.interest
        ],
        [
          this.translateService.instant('app.qty') + ':',
          this.qty,
          this.translateService.instant('app.period') + ':',
          this.period
        ]
      ];
      // this.sampleService.getSimulation().subscribe(
      this.apiService.post('loan/simulation/', this.options).subscribe(
        (response: any) => {
          const items = response.body;
          console.log(items);
          for (let i = 0; i < items.length; i++) {
            rows.push({
              no: `${i + 1}.`,
              payment_date: this.datePipe.transform(items[i].payment_date, 'yyyy-MM-dd'),
              balance: this.formatNumber(items[i].balance),
              principal_paid: this.formatNumber(items[i].principal_paid),
              interest_paid: this.formatNumber(items[i].interest_paid),
              payment_amount: this.formatNumber(items[i].payment_amount)
            });
          }

          // Only pt supported (not mm or in)
          const doc = new jsPDF('p', 'pt');
          doc.autoTable(columns_head, rows_head, {
            addPageContent: function(data) {
              doc.text('Simulation', 40, 30);
              doc.text(today_date, 40, 50);
            },
            theme: 'plain',
            margin: { top: 50 },
            bodyStyles: { valign: 'top' },
            styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1 },
            columnStyles: {
              0: { columnWidth: 70 },
              1: { columnWidth: 290 },
              2: { columnWidth: 70 }
            }
          });
          doc.autoTable(columns, rows, {
            margin: { top: 120 },
            bodyStyles: { valign: 'top' },
            styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
            columnStyles: { text: { columnWidth: 'auto' } }
          });
          window.open(doc.output('bloburl'));
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }
}
