import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';
import { Location } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  providers: [TranslateService]
})
export class IncomeComponent implements OnInit {
  page_view_permission: string;
  user_permission_collection: any = {};
  allow_view: boolean;

  constructor(
    private location: Location,
    private localSt: LocalStorageService,
    private translateService: TranslateService
  ) {
    this.allow_view = false;
    this.page_view_permission = 'transaction.income.view';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.income')
      );
      this.location.back();
    }
  }

  ngOnInit() {}

  actionRefresh() {}

  actionAdd() {}
}
