import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { fadeIn } from '../../../shared/animations';
import { DxDataGridComponent } from 'devextreme-angular';
import { Router } from '@angular/router';
import { ApiService, ConfigService } from './../../../core';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { DatePipe, formatCurrency } from '@angular/common';
import { LocalStorageService } from 'ngx-webstorage';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import CustomStore from 'devextreme/data/custom_store';
import { Master } from '../../../core/models';

@Component({
  selector: 'app-vendor-payment',
  templateUrl: './vendor-payment.component.html',
  styleUrls: ['./vendor-payment.component.scss'],
  providers: [ApiService, TranslateService],
  animations: [fadeIn()]
})
export class VendorPaymentComponent implements OnInit {
  title: any;
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;

  dataSource: any = {};
  dataGridPageSize = 10;

  route = 'transaction/vendor-payment';

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private router: Router,
    private apiService: ApiService,
    private location: Location,
    private localSt: LocalStorageService,
    private config: ConfigService,
    private translateService: TranslateService,
    private datePipe: DatePipe,
    private httpclient: HttpClient
  ) {
    this.title = this.translateService.instant('app.vendor-payment');
    this.dataSource.store = new CustomStore({
      load: function (options: any) {
        options.userData.company_id = true;
        options.userData.custom_sort = true;
        options.userData.selector = 'id';
        options.userData.sortMethod = 'desc';
        return apiServiceInject.getMaster('invoice_payment', options);
      },
      remove: function (row) {
        return apiServiceInject
          .delete('invoice_payment/' + row.id)
          .toPromise()
          .then(
            () => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
    // console.log(this.dataSource);
  }

  ngOnInit() {

  }

  actionAdd() {
    this.router.navigate([this.route, 'create']);
  }

  actionEditPayment(id) {
    this.router.navigate([this.route, id, 'edit']);
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionExcel() {
    const company_active = this.localSt.retrieve('user_company_active');
    this.apiService.get('invoice_payment?company_id=' + company_active).subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.invoice-no')]: el.invoice_number,
            [this.translateService.instant('app.invoice-date')]: el.invoice_date,
            [this.translateService.instant('app.payment_number')]: el.payment_number,
            [this.translateService.instant('app.payment_date')]: el.payment_date,
            [this.translateService.instant('app.grn_number')]: el.grn_number,
            [this.translateService.instant('app.grn_date')]: el.grn_date,
            [this.translateService.instant('app.po-number')]: el.po_number,
            [this.translateService.instant('app.po-date')]: el.po_date,
            [this.translateService.instant('app.terms')]: el.po_terms,
            [this.translateService.instant('app.vendor')]: el.vendor_name,
            [this.translateService.instant('app.ship-to')]: el.ship_to_name,
            [this.translateService.instant('app.bill-to')]: el.bill_to_name,
            [this.translateService.instant('app.total_invoice')]: el.total_invoice,
            [this.translateService.instant('app.total_payment')]: el.total_payment,
            [this.translateService.instant('app.status')]: el.payment_status
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionPdf(value) {
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.invoice-no'), dataKey: 'invoice_number' },
      { title: this.translateService.instant('app.invoice-date'), dataKey: 'invoice_date' },
      { title: this.translateService.instant('app.payment_number'), dataKey: 'payment_number' },
      { title: this.translateService.instant('app.payment_date'), dataKey: 'payment_date' },
      { title: this.translateService.instant('app.grn_number'), dataKey: 'grn_number' },
      { title: this.translateService.instant('app.grn_date'), dataKey: 'grn_date' },
      { title: this.translateService.instant('app.po-number'), dataKey: 'po_number' },
      { title: this.translateService.instant('app.po-date'), dataKey: 'po_date' },
      { title: this.translateService.instant('app.terms'), dataKey: 'po_terms' },
      { title: this.translateService.instant('app.vendor'), dataKey: 'vendor_name' },
      { title: this.translateService.instant('app.ship-to'), dataKey: 'ship_to_name' },
      { title: this.translateService.instant('app.bill-to'), dataKey: 'bill_to_name' },
      { title: this.translateService.instant('app.total_invoice'), dataKey: 'total_invoice' },
      { title: this.translateService.instant('app.total_payment'), dataKey: 'total_payment' },
      { title: this.translateService.instant('app.status'), dataKey: 'payment_status' }
    ];
    const rows = [];
    const company_active = this.localSt.retrieve('user_company_active');
    this.apiService.get('invoice_payment?company_id=' + company_active).subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            invoice_number: items[i].invoice_number,
            invoice_date: items[i].invoice_date,
            payment_number: items[i].payment_number,
            payment_date: items[i].payment_date,
            grn_number: items[i].grn_number,
            grn_date: items[i].grn_date,
            po_number: items[i].po_number,
            po_date: items[i].po_date,
            po_terms: items[i].po_terms,
            vendor_name: items[i].vendor_name,
            ship_to_name: items[i].ship_to_name,
            bill_to_name: items[i].bill_to_name,
            total_invoice: items[i].total_invoice,
            total_payment: items[i].total_payment,
            payment_status: items[i].payment_status
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('l', 'pt');
        doc.autoTable(columns, rows, {
          addPageContent: function (data) {
            doc.text('Invoice Payment', 40, 30);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  async actionPrintPayment(value) {
    // console.log(value);
    const data_pp = await this.apiService.get('invoice_payment/' + value).toPromise();
    const vendor_id = data_pp['vendor_id'];
    // console.log(vendor_id);
    const shippTo_id = data_pp['ship_to_id'];
    const billTo_id = data_pp['bill_to_id'];

    const data_vendor = await this.apiService.get('vendor/' + vendor_id).toPromise();
    const data_ship_dealer = await this.apiService.get('dealer/' + shippTo_id).toPromise();
    const data_bill_company = await this.apiService.get('company/' + billTo_id).toPromise();

    const doc = new jsPDF('p', 'pt');
    // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.product'), dataKey: 'product' },
      { title: this.translateService.instant('app.manufacture_year'), dataKey: 'manufacture_year' },
      { title: this.translateService.instant('app.vin'), dataKey: 'vin' },
      { title: this.translateService.instant('app.engine_number'), dataKey: 'engine_number' },
      { title: this.translateService.instant('app.color'), dataKey: 'color' },
      { title: this.translateService.instant('app.unit_price'), dataKey: 'unit_price' }


    ];

    // const rows = [];
    // const data = data_pp['invoice_detail'];
    // console.log(data);
    const rows = [];
    for (let i = 0; i < data_pp['invoice_detail']['length']; i++) {
      rows.push({
        no: `${i + 1}.`,
        product: data_pp['invoice_detail'][i].product_name,
        manufacture_year: data_pp['invoice_detail'][i].manufacture_year,
        vin: data_pp['invoice_detail'][i].vin,
        engine_number: data_pp['invoice_detail'][i].engine_number,
        color: data_pp['invoice_detail'][i].color,
        unit_price: this.formatNumber(data_pp['invoice_detail'][i].unit_price),
        // product_total: this.formatNumber(data_po['po_detail'][i].sub_total)
      });
    }
    const rows_head = [];

    const col_empty = ['', ''];
    const row_empty = [];
    const columns_head = ['', '', '', ''];


    const col_before_tax = ['', '', ''];
    const row_before_tax = [
        [
          'Total Invoice',
          ':',
          this.formatNumber(data_pp['total_invoice'])
        ],
        [
          'Total Payment ',
          ':',
          this.formatNumber(data_pp['total_payment'])
        ]
      ];

    const col_after_tax = ['', '', ''];
    const row_after_tax = [
        // [
        //   'Remaining Payment',
        //   ':',
        //   this.formatNumber(data_pp['total_invoice']-data_pp['total_payment'])
        // ]
      ];

      // draw PDF
      // const po_date_format = this.datePipe.transform(data_po['po_date'], 'yyyy-MM-dd HH:mm:ss', '008Z');
      const invoice_date_format = this.datePipe.transform(data_pp['invoice_date'], 'yyyy-MM-dd');
      rows_head.push({
        0: 'GR Number: ' +  data_pp['grn_number']
      });
      rows_head.push({
        0: 'Payment Number: ' +  data_pp['payment_number']
      });
      rows_head.push({
        0: 'Invoice Number: ' +  data_pp['invoice_number']
      });
      rows_head.push({
        0: 'Invoice Date  : ' + invoice_date_format
      });
      rows_head.push({
        0: 'Status: ' +  data_pp['payment_status']
      });

      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('PAYMENT', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

      // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

    //   // status and term
    //   doc.autoTable(col_empty, row_empty, {
    //     addPageContent: function (data) {
    //       doc.setFontSize(9);
    //       doc.text('Terms : ' + data_po['po_terms'], 52, 90);
    //       doc.text('Status : ' + data_po['po_status'], 52, 100);
    //     },
    //     theme: 'plain',
    //     margin: { top: 35, left: 50 },
    //     bodyStyles: { valign: 'top' },
    //     styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
    //     columnStyles: {
    //       0: { columnWidth: 200 }
    //     }
    //   });

      // vendor
      const splitVendorAddress = doc.splitTextToSize(data_vendor['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Vendor :', 52, 125);
          doc.setFontType('normal');
          doc.text(data_vendor['vendor_name'], 52, 135);
          doc.text(splitVendorAddress, 52, 145);
          doc.text('Phone : ' + data_vendor['phone'], 52, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // ship to
      const splitShipAddress = doc.splitTextToSize(data_ship_dealer['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Ship To :', 230, 125);
          doc.setFontType('normal');
          doc.text(data_ship_dealer['dealer_name'], 230, 135);
          doc.text(splitShipAddress, 230, 145);
          doc.text('Phone: ' + data_ship_dealer['phone'], 230, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // bill to
      const splitBillAddress = doc.splitTextToSize(data_bill_company['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Bill To :', 400, 125);
          doc.setFontType('normal');
          doc.text(data_bill_company['company_name'], 400, 135);
          doc.text(splitBillAddress, 400, 145);
          doc.text('Phone: ' + data_bill_company['phone'], 400, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });

    this.apiService.get('invoice_payment/' + value).subscribe(
      (response: any) => {
      // to get y position of last autotable
      const finalY = doc.autoTable.previous.finalY + 15;
      const finalY2 = doc.autoTable.previous.finalY + 25;
      const finalY3 = doc.autoTable.previous.finalY + 45;

      // total before tax and tax
      doc.autoTable(col_before_tax, row_before_tax, {
        addPageContent: function (data) {
        },
        theme: 'plain',
        margin: { top: finalY, left: 393 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 80 },
          1: { columnWidth: 10 },
          2: { columnWidth: 70 }
        }
      });

      // total after tax
      doc.autoTable(col_after_tax, row_after_tax, {
        addPageContent: function (data) {
        },
        theme: 'plain',
        margin: { top: finalY3, left: 393 },
        bodyStyles: { valign: 'top', halign: 'right', fontStyle: 'bold', fontSize: 11 },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 80 },
          1: { columnWidth: 10 },
          2: { columnWidth: 70 }
        }
      });

      // // total
      // doc.autoTable(col_empty, row_empty, {
      //   addPageContent: function(data) {
      //     doc.setFontSize(12);
      //     doc.setFontType('bold');
      //     doc.text(440, finalY3, 'Total After Tax: 1,000,000');
      //     doc.setFontType('normal');
      //   },
      //   theme: 'plain',
      //   margin: { top: 35, left: 50 },
      //   bodyStyles: { valign: 'top', halign: 'right' },
      //   styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1},
      //   columnStyles: {
      //     0: { columnWidth: 200 }
      //   }
      // });
      window.open(doc.output('bloburl'));
    });
  }

  actionDelete(row) {
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);

  }



}
