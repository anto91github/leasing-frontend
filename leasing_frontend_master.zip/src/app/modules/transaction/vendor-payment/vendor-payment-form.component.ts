import { Component, OnInit, Inject } from '@angular/core';
import { Location } from '@angular/common';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent,
  DxFormModule,
  DxSelectBoxModule
} from 'devextreme-angular';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { LocalStorageService } from 'ngx-webstorage';

import { ApiService, Product, Attachment, Master } from '../../../core';
import { fadeIn } from '../../../shared/animations';
import DataSource from 'devextreme/data/data_source';
import ArrayStore from 'devextreme/data/array_store';
import CustomStore from 'devextreme/data/custom_store';
import { delay, concatMap, map } from 'rxjs/operators';
import { forkJoin, combineLatest, from, concat, Observable, of } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-vendor-payment-form',
  templateUrl: './vendor-payment-form.component.html',
  styleUrls: ['./vendor-payment-form.component.scss'],
  animations: [fadeIn()]
})
export class VendorPaymentFormComponent implements OnInit {
/* tslint:disable */
  id: number = null;
  form: FormGroup;
  formProduct: FormGroup;
  dataSource: any [];
  product_header: any;
  items: FormArray;
  products = [];
  status = [];
  company = [];
  _dateValue: any;
  _dateValueGRdate: any;
  idVendor = [];
  selectedVendor = [];
  vendors: any;
  invoicePaymentData = [];
  details = false;

  now: Date = new Date();
  maxDate: Date = new Date();

  // vendors = [];

  /** Vendor data */
  detailVendor = false;
  vendor_name: any;
  vendor_type: any;
  address: any;
  phone: any;
  fax: any;
  email: any;
  web: any;

  /** Ship To Data */
  detailShipTo = false;
  company_name_ShipTo = [];
  addressShipTo = [];
  phoneShipTo = [];
  faxShipTo = [];
  emailShipto = [];
  webShipTo = [];

  /** Bill To Data */
  detailBillTo = false;
  company_name_BillTo = [];
  addressBillTo = [];
  phoneBillTo = [];
  faxBillTo = [];
  emailBillTo = [];
  webBillTo = [];

  invoice_date: any;
  grn_status: any;
  bill_to_name: any;
  ship_to_name: any;
  invoice_detail = [];
  total_invoice: any;
  vendor_id: any;
  ship_to_id: any;
  bill_to_id: any;
  grn_id: any;
  po_id: any;
  company_id: any;
  grn_date: any;
  invoice_number: any;
  po_number: any;
  po_terms: any;
  po_date: any;
  totalInvoice: any;
  tax: any;
  subtotal: any;
  total: any;
  manufacture_year: any;
  engine_number: any;
  vin: any;
  statusNew: any;
  total_payment: any;
  total_after_tax: any;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private localStorageService: LocalStorageService,
    private apiService: ApiService,
    private location: Location,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.dateValue = this.now;
  }

  ngOnInit() {
    // this.loadVendors();
    // this.loadProducts();
    // this.loadStatus();
    this.loadInvoicePaymentData();
    this.loadCompany();
    this.formProduct = this.formBuilder.group({
      InvoiceDate: this.now,
      GRnumber: new FormControl('', {
        validators: Validators.required
      }),
      PaymentNumber: new FormControl('', {}),
      totalPayment: new FormControl('', {
        validators: Validators.required
      }),
      invoiceNumber: new FormControl('', {})
    });

    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (!this.id) {
        return;
      }
      const company_active = this.localStorageService.retrieve('user_company_active');
      this.apiService
        .get('vendor?sort=vendorName,asc&company_id=' + company_active)
        .subscribe((data: any) => {
          this.details = true;
          /** Disable GR Number (ng-select) */
          const control = this.formProduct.controls['GRnumber'];
          control.disable();

          data.content.forEach(val => {
            this.apiService.get('invoice_payment/' + this.id).subscribe((data: any) => {
              // console.log(data);
              this.formProduct.patchValue({
                GRnumber: data.grn_number,
                PaymentNumber: data.payment_number,
                invoiceNumber: data.po_number
              });
              this.total_payment = data.total_payment;
              this.vendor_name    = data.vendor_name;
              this.grn_status     = data.payment_status;
              this.invoice_detail = data.invoice_detail;
              this.grn_id = data.grn_id;

              this.apiService.get('goods_receipt_note/' + data.grn_id).subscribe((data: any) => {
                // console.log(data);
                this.invoice_detail  = data.grn_detail;
                this.tax             = data.tax,
                this.subtotal        = data.total_before_tax;
                this.total_after_tax = data.total_after_tax;
                this.total           = data.total_after_tax - this.total_payment;
                this.formProduct.get('totalPayment').patchValue(this.total);
              });

              /** GET Vendor Data */
              this.apiService.get('vendor/' + data.vendor_id).subscribe((data: any) => {
                this.vendor_type = data.vendor_type;
                this.address = data.address;
                this.phone = data.phone;
                this.fax = data.fax;
                this.email = data.email;
                this.web = data.web;
              });
              /** GET Ship To Data */
              this.apiService.get('dealer/' + data.ship_to_id).subscribe((data: any) => {
                this.company_name_ShipTo = data.company_name;
                this.addressShipTo = data.address;
                this.phoneShipTo = data.phone;
                this.faxShipTo = data.fax;
                this.emailShipto = data.email;
                this.webShipTo = data.web;
              });
            /** GET Bill To Data */
              this.apiService.get('company/' + data.bill_to_id).subscribe((data: any) => {
                this.company_name_BillTo = data.company_name;
                this.addressBillTo = data.address;
                this.phoneBillTo = data.phone;
                this.faxBillTo = data.fax;
                this.emailBillTo = data.email;
                this.webBillTo = data.web;
              });
            });
          });
      });
    });
  }

  get Detailproduct() {
    return this.formProduct.get('items') as FormArray;
  }

  get formItems(): FormGroup {
    return this.formProduct.get('items') as FormGroup;
  }

  private loadInvoicePaymentData(): any {
    const company_active = this.localStorageService.retrieve('user_company_active');
    this.apiService
      .get('goods_receipt_note/search/payment_status?payment_status=UNPAID')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        // console.log(data);
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              bill_to_id: el.bill_to_id,
              bill_to_name: el.bill_to_name,
              company_id: el.company_id,
              grn_date: el.grn_date,
              grn_number: el.grn_number,
              id: el.id,
              invoice_date: el.invoice_date,
              invoice_detail: el.invoice_detail,
              payment_date: el.payment_date,
              payment_number: el.payment_number,
              grn_status: el.grn_status,
              po_date: el.po_date,
              po_id: el.po_id,
              po_number: el.po_number,
              po_terms: el.po_terms,
              ship_to_id: el.ship_to_id,
              ship_to_name: el.ship_to_name,
              vendor_id: el.vendor_id,
              vendor_name: el.vendor_name,
              total_after_tax: el.total_after_tax
            });
        });
        this.invoicePaymentData = [...items];
      });
  }

  private loadCompany(): any {
    this.apiService
      .get('company')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              company_name: el.company_name,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.company = [...items];
      });
  }

  changeGRnumber(event) {
    // console.log(event);
    this.details          = true;
    this.grn_status       = event.grn_status;
    this.vendor_name      = event.vendor_name;
    this.bill_to_name     = event.bill_to_name;
    this.ship_to_name     = event.ship_to_name;
    this.totalInvoice     = event.total_after_tax;
    this.vendor_id        = event.vendor_id;
    this.ship_to_id       = event.ship_to_id;
    this.bill_to_id       = event.bill_to_id;
    this.grn_id           = event.id;
    this.grn_date         = event.grn_date;
    this.po_id            = event.po_id;
    this.company_id       = event.company_id;
    this.po_number        = event.po_number;
    this.po_terms         = event.po_terms;
    this.po_date          = event.po_date;
    this.manufacture_year = event.manufacture_year;
    this.engine_number    = event.engine_number;
    this.vin              = event.vin;

    this.apiService.get('vendor/' + event.vendor_id).subscribe((data: any) => {
      this.vendor_type = data.vendor_type;
      this.address = data.address;
      this.phone = data.phone;
      this.fax = data.fax;
      this.email = data.email;
      this.web = data.web;
    });

    this.apiService.get('goods_receipt_note/' + event.id).subscribe((data: any) => {
      // console.log(data);
      this.invoice_detail = data.grn_detail;
      this.tax = data.tax,
      this.subtotal = data.total_before_tax;
      this.total = data.total_after_tax;

    });
    /** Ship To */
    this.apiService.get('dealer/' + event.ship_to_id).subscribe((data: any) => {
      this.company_name_ShipTo = data.company_name;
      this.addressShipTo = data.address;
      this.phoneShipTo = data.phone;
      this.faxShipTo = data.fax;
      this.emailShipto = data.email;
      this.webShipTo = data.web;
    });
    this.apiService.get('company/' + event.bill_to_id).subscribe((data: any) => {
      this.company_name_BillTo = data.company_name;
      this.addressBillTo = data.address;
      this.phoneBillTo = data.phone;
      this.faxBillTo = data.fax;
      this.emailBillTo = data.email;
      this.webBillTo = data.web;
    });

    this.formProduct.get('totalPayment').patchValue(this.totalInvoice);
  }

  async save() {
    const GRnumber = this.formProduct.value.GRnumber;
    const invoiceNumber = this.formProduct.value.invoiceNumber;
    const paymentNumber = this.formProduct.value.PaymentNumber;
    const totalPayment = this.formProduct.value.totalPayment;

    /** Convert Format Date to ISO */
    /** Invoice Date */
    const Invoicedate = new Date(this.dateValue);
    const NewDateInvoicedate = Invoicedate.toISOString();

    const Paymentdate = new Date(this.now);
    const NewDatePaymentdate = Paymentdate.toISOString();

  if (this.formProduct.valid) {
    const newInvoiceDetail = [];
    this.invoice_detail.forEach(data => {
      const value = {
        product_id: data.product_id,
        product_name: data.product_name,
        manufacture_year: data.manufacture_year,
        vin: data.vin,
        engine_number: data.engine_number,
        color: data.color,
        unit_price: data.unit_price
      };
      newInvoiceDetail.push(value);
    });

    if (this.totalInvoice === totalPayment) {
      this.statusNew = 'PAID';
    } else {
      this.statusNew = 'PARTIAL';
    }
    const form_value = {
      company_id: this.company_id,
      // invoice_number: invoiceNumber,
      invoice_date: NewDateInvoicedate,
      // payment_number: paymentNumber,
      payment_date: NewDatePaymentdate,
      po_id: this.po_id,
      po_number: this.po_number,
      po_date: this.po_date,
      grn_id: this.grn_id,
      grn_number: GRnumber,
      grn_date: this.grn_date,
      po_terms: this.po_terms,
      vendor_id: this.vendor_id,
      vendor_name: this.vendor_name,
      ship_to_id: this.ship_to_id,
      ship_to_name: this.ship_to_name,
      bill_to_id: this.bill_to_id,
      bill_to_name: this.bill_to_name,
      total_invoice: this.totalInvoice,
      total_payment: totalPayment,
      payment_status: this.statusNew,
      invoice_detail: newInvoiceDetail
    };
    const StatusPayment = {
      payment_status: this.statusNew
    };
    // console.log(form_value);
      if (!this.id) {
        this.apiService.post('invoice_payment', form_value).subscribe(
          success => {
            console.log(success);
          },
          error => {
            console.log(error);
          }
        );

        // update paymet status in GRN
        this.apiService.put('goods_receipt_note/payment_status/'+ this.grn_id, StatusPayment).subscribe(
          success => {
            console.log(success);
            this.router.navigate(['transaction/vendor-payment']);
          },error => {
            console.log(error);
          }              
        );
      } else {

        const sum_repayment      = this.total_payment + totalPayment;
        const status             = this.total_after_tax === sum_repayment ? 'PAID' : 'PARTIAL';
        const form_PUT_repayment = { total_payment: sum_repayment };
        const form_PUT_status    = { payment_status: status };

        await this.apiService.put('invoice_payment/total_payment/' + this.id, form_PUT_repayment).subscribe(
          async success => {
           await this.apiService.put('invoice_payment/payment_status/' + this.id, form_PUT_status).subscribe(
              success => {
                console.log(success);
                this.router.navigate(['transaction/vendor-payment']);
              },
              error => {
                console.log(error);
              }
            );
          },
          error => {
            console.log(error);
          }
        );
          // update paymet status in GRN
          console.log(status);
        this.apiService.put('goods_receipt_note/payment_status/'+ this.grn_id, form_PUT_status).subscribe(
          success => {
            console.log(success);
            this.router.navigate(['transaction/vendor-payment']);
          },error => {
            console.log(error);
          }              
        );

      }
    } else {
      this.validateAllFormFields(this.formProduct);
    }
  }

  back() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.vendors = false;
  }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = (value && [value]) || [];
    this._dateValue = value;
  }

  get dateValueGRDate(): any {
    return this._dateValueGRdate;
  }

  set dateValueGRDate(value: any) {
    this._dateValueGRdate = (value && [value]) || [];
    this._dateValueGRdate = value;
  }

  isFieldValid(field: string) {
    return !this.formProduct.get(field).valid && this.formProduct.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  addItem($event) {

  }

}
