import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VendorPaymentComponent } from './vendor-payment.component';
import { VendorPaymentFormComponent } from './vendor-payment-form.component';

const routes: Routes = [
  {
    path: '',
    component: VendorPaymentComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: VendorPaymentFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: VendorPaymentFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VendorPaymentRoutingModule { }
