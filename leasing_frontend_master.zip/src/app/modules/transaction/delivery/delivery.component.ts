import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { fadeIn } from '../../../shared/animations';
import CustomStore from 'devextreme/data/custom_store';
// import { ApiService, ConfigService } from './../../../core';
import { ApiService, SampleService } from './../../../core/services';
import { TranslateService } from '@ngx-translate/core';
import { DxDataGridComponent, DxNumberBoxModule } from 'devextreme-angular';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

import { Master } from '../../../core/models';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-delivery',
  templateUrl: './delivery.component.html',
  styleUrls: ['./delivery.component.scss'],
  providers: [/*ApiService,*/ TranslateService],
  animations: [fadeIn()]
})
export class DeliveryComponent implements OnInit {
  route = 'transaction/delivery';
  dataSource: any = {};
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  id: string;
  title: any;
  delivered_collection_before = [];
  sub_detail_list = [];
  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private translateService: TranslateService,
    private router: Router
  ) {
    this.title = this.translateService.instant('app.delivery');
    this.dataSource.store = new CustomStore({
      load: function (options: any) {
        options.userData.company_id = true;
        options.userData.custom_sort = true;
        options.userData.selector = 'id';
        options.userData.sortMethod = 'desc';

        console.log(apiServiceInject.getMaster('delivery/all', options));
        return apiServiceInject.getMaster('delivery/all', options);
      }
      // ,
      // remove: function (row) {
      //   return apiServiceInject
      //     .delete('delivery/' + row.id)
      //     .toPromise()
      //     .then(
      //       () => document.getElementById('btn-refresh').click(),
      //       error => Promise.reject(error.error.message)
      //     );
      // }
    });
   }

  ngOnInit() {
  }

  actionRefresh() {
    // this.dataGrid.instance.refresh();
  }

  actionAdd() {
    this.router.navigate([this.route, 'create']);
  }

  actionEdit(id) {
    this.router.navigate([this.route, id, 'info']);
  }

  actionExcel() {
    this.apiService.get('delivery/all/').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.delivery_number')]: el.delivery_number,
            [this.translateService.instant('sys.date')]: el.delivered_date,
            [this.translateService.instant('app.fullname')]: el.customer_name
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionPdf() {

    // if (this.allow_print === false) {
    //   alert(
    //     this.translateService.instant('alert.no_print') +
    //       this.translateService.instant('app.transfer_stock')
    //   );
    //   return false;
    // }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.delivery_number'), dataKey: 'delivery_number' },
      { title: this.translateService.instant('sys.date'), dataKey: 'delivered_date' },
      { title: this.translateService.instant('app.fullname'), dataKey: 'customer_name' },
    ];
    const rows = [];
    this.apiService.get('delivery/all/').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            delivery_number: items[i].delivery_number,
            delivered_date: items[i].delivered_date,
            customer_name: items[i].customer_name,
          });
          console.log(items);
        }

    // Only pt supported (not mm or in)
    const doc = new jsPDF('p', 'pt');
    doc.autoTable(columns, rows, {
      theme: 'striped',
      margin: { top: 60 },
      addPageContent: function(data) {
        doc.text('Delivery', 40, 30);
      },
      bodyStyles: { valign: 'top' },
      styles: { overflow: 'linebreak', fontSize: 7 },
      columnStyles: { text: { columnWidth: 'auto' } }
    });
    window.open(doc.output('bloburl'));
  },
  error => {
    console.log(error);
  }
);
  }
  async actionPrintDetail(value) {
    console.log(value);
    const data_delivery = await this.apiService.get('delivery/' + value).toPromise();
    console.log(data_delivery);
    const sub_id = data_delivery['submission_id'];
    const data_delivery_submission =  await this.apiService.get('submission/' + sub_id ).toPromise();
    const check_delivered_api = await this.apiService.get(
      'delivery/by?submission_id=' + data_delivery['submission_id']).toPromise();
    const check_delivered = check_delivered_api['content'];
      console.log(check_delivered);

    check_delivered.forEach(element => {
      element.delivery_details.forEach(element2 => {
        const detail = {
          product_id : element2.product_id,
          sku_id : element2.sku_id
        };
        this.delivered_collection_before.push(detail);
      });
    });
    console.log(this.delivered_collection_before);

    // loop for submission detail list
    // data_delivery_submission['submission_details'].forEach(element => {
    //   let initial_qty = 0;
    //   for (let i = 0; i < this.delivered_collection_before.length; i++) {
    //     if (this.delivered_collection_before[i].product_id === element.product_id) {
    //       initial_qty = initial_qty + 1;
    //     }
    //   }
    //   const temp_detail = {
    //     product_name : element.product_name,
    //     qty : element.qty,
    //     qty_delivered: initial_qty
    //   };
    //   this.sub_detail_list.push(temp_detail);
    // });

    const doc = new jsPDF('p', 'pt');
    // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.product'), dataKey: 'product_id' },
      { title: this.translateService.instant('app.vin'), dataKey: 'vin' },
      { title: this.translateService.instant('app.engine_number'), dataKey: 'engine_number' },
      { title: this.translateService.instant('app.manufacture_year'), dataKey: 'manufacture_year' },
      { title: this.translateService.instant('app.color'), dataKey: 'color' }
    ];

    const rows = [];
    // if (data_delivery_submission['submission_details'].product_id ===
    // data_delivery['delivery_details'].product_id) {
    //   for (let i = 0; i < data_delivery['delivery_details']['length']; i++) {
    //   rows.push({
    //     no: `${i + 1}.`,
    //     product_id: data_delivery['delivery_details'][i].product_id,
    //     vin: data_delivery['delivery_details'][i].vin,
    //     engine_number: data_delivery['delivery_details'][i].engine_number,
    //     color: data_delivery['delivery_details'][i].color,
    //     manufacture_year: data_delivery['delivery_details'][i].manufacture_year
    //   });
    // }

    // }
    for (let i = 0; i < data_delivery['delivery_details']['length']; i++) {
      rows.push({
        no: `${i + 1}.`,
        product_id: data_delivery['delivery_details'][i].product_id,
        vin: data_delivery['delivery_details'][i].vin,
        engine_number: data_delivery['delivery_details'][i].engine_number,
        color: data_delivery['delivery_details'][i].color,
        manufacture_year: data_delivery['delivery_details'][i].manufacture_year
      });
    }
    const rows_head = [];

    const col_empty = ['', ''];
    const row_empty = [];
    const row_submission = [];
    const columns_head = ['', '', '', ''];
    const col_submission = [
      // { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.product_id'), dataKey: 'product_id' },
      { title: this.translateService.instant('app.product'), dataKey: 'product_name' },
      { title: this.translateService.instant('app.qty'), dataKey: 'qty' },
      { title: this.translateService.instant('app.qty_delivered'), dataKey: 'qty_delivered' },
      { title: this.translateService.instant('app.remains'), dataKey: 'remains' },
    ];
      data_delivery_submission['submission_details'].forEach(element => {
      let initial_qty = 0;
      for (let i = 0; i < this.delivered_collection_before.length; i++) {
        if (this.delivered_collection_before[i].product_id === element.product_id) {
          initial_qty = initial_qty + 1;
        }
      }
      const no = 0;
      row_submission.push({
        product_id: element.product_id,
        product_name: element.product_name,
        qty: element.qty,
        qty_delivered: initial_qty,
        remains: element.qty - initial_qty
      });
    });

    // for (let i = 0; i < data_delivery_submission['submission_details']['length']; i++) {
    //   row_submission.push({
    //     no: `${i + 1}.`,
    //     product_id: data_delivery_submission['submission_details'][i].product_id,
    //     product_name: data_delivery_submission['submission_details'][i].product_name,
    //     qty: data_delivery_submission['submission_details'][i].qty,
    //     qty_delivered: initial_qty,
    //     remains: data_delivery_submission['submission_details'][i].qty - initial_qty
    //   });
    // }

      // draw PDF
      rows_head.push({
        0: 'Delivery Number :' +  data_delivery['delivery_number']
      });
      rows_head.push({
        0: 'Submission Number : ' + data_delivery['submission_number']
      });
      rows_head.push({
        0: 'Customer Name: '  + data_delivery['customer_name']
      });
      rows_head.push({
        0: 'Leasing Note : '  + data_delivery['leasing_note']
      });
      rows_head.push({
        0: 'Date : ' + data_delivery['delivered_date']
      });
      rows_head.push({
        0: 'Dealer Name : ' + data_delivery['dealer_name']
      });
      rows_head.push({
        0: 'Delivered By : ' + data_delivery['delivered_by']
      });

      // rows_head.push({
      //   0: this.translateService.instant('app.status: ' ) + data_delivery['customer_name']
      // });

      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('DELIVERY DETAILS', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

      // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

       // table detail
       doc.autoTable(col_submission, row_submission, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });
      this.apiService.get('delivery/' + value).subscribe(
        (response: any) => {
        // to get y position of last autotable
        const finalY = doc.autoTable.previous.finalY ;

        // Product Detail
        doc.autoTable(columns, rows, {
          addPageContent: function (data) {
          },
          theme: 'grid',
          margin: { top: finalY },
          bodyStyles: { valign: 'top' },
          headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
          styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
          columnStyles: {
            no: { columnWidth: 25 },
            product_qty: { columnWidth: 25 },
            product: { halign: 'left' },
            text: { columnWidth: 'auto' }
          }
        });
      window.open(doc.output('bloburl'));
    });
  }
}

