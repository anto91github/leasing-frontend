import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { HttpClient, HttpClientModule} from '@angular/common/http';
import { DeliveryRoutingModule } from './delivery-routing.module';
import { DeliveryComponent } from './delivery.component';
import { DeliveryFormComponent } from './delivery-form.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxDateBoxModule,
  DxNumberBoxModule,
  DxBoxModule,
  DxTextBoxModule,
  DxPopupModule,
  DxTemplateModule,
  DxTreeViewModule,
  DxSelectBoxModule,
  DxCheckBoxModule
} from 'devextreme-angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    NgSelectModule,
    SharedModule,
    DeliveryRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DxTreeViewModule,
    FlashMessagesModule.forRoot(),
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxDateBoxModule,
    DxPopupModule,
    DxButtonModule,
    DxTemplateModule,
    DxNumberBoxModule,
    DxBoxModule,
    DxTextBoxModule,
    DxSelectBoxModule,
    DxCheckBoxModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [DeliveryComponent, DeliveryFormComponent]
})
export class DeliveryModule { }
