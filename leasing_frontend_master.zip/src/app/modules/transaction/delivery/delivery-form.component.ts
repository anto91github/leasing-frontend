import { Component, OnInit, ViewChildren, Inject, ViewChild, QueryList } from '@angular/core';
import { Location } from '@angular/common';
import { DxDataGridComponent } from 'devextreme-angular';
import { ApiService, ConfigService } from '../../../core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { fadeIn } from '../../../shared/animations';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent,
  DxPopupModule,
  DxTemplateModule
} from 'devextreme-angular';
import { Router, ActivatedRoute } from '@angular/router';
import { submission } from '../../../core/samples';
// import { HttpClient } from '@angular/common/http';
import CustomStore from 'devextreme/data/custom_store';
import { DatePipe, formatCurrency } from '@angular/common';

@Component({
  selector: 'app-delivery-form',
  templateUrl: './delivery-form.component.html',
  styleUrls: ['./delivery-form.component.scss'],
  animations: [fadeIn()]
  // providers: [ApiService]
})
export class DeliveryFormComponent implements OnInit {
  @ViewChild(DxDataGridComponent)
  @ViewChild(DxRadioGroupComponent) radio_status: DxRadioGroupComponent;
  @ViewChildren(DxDropDownBoxComponent) dropdownBox: QueryList<DxDropDownBoxComponent>;
  dataGrid: DxDataGridComponent;
  dataGridSource: any = {};
  formDelivery: FormGroup;
  id: number = null;

  submissionCollection: any;
  selected_submission_id;
  selected_submission_no;
  selected_dealer_name;
  selected_dealer_id;
  selected_customer_name;
  selected_leasing_note;
  selected_company_id;
  selected_customer_company_id;
  selected_company_name;
  selected_customer_personal_id;

  delivered_date;
  status = ['UNDELIVERED', 'PARTIAL', 'DELIVERED'];

  sub_detail_length;
  sub_detail;
  sub_detail_list = [];
  delivered_collection_before = [];
  product_stock_data;

  allMode: string;
  checkBoxesMode: string;

  _dateValue: any;
  now: Date = new Date();

  _productSelectedRowKeys: number[];
  is_edit = false;

  // gridBoxValue: any;

  constructor(
    private location: Location,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private apiService: ApiService,
    // http: HttpClient,
    private datePipe: DatePipe,
  ) {
    this.allMode = 'allPages';
    this.checkBoxesMode = 'always';
   }

  ngOnInit() {
    this.formDelivery = this.formBuilder.group({
      delivery_no: new FormControl('', {
      }),
      submission_no: new FormControl('', {
      }),
      dealer_id: new FormControl('', {
      }),
      delivery_status: new FormControl('', {
      }),
      leasing_note: new FormControl('', {
      }),
      delivered_by: new FormControl('', {
      })
    });
    this.route.params.subscribe(async params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      this._dateValue = this.now;
      if (this.id) { // is edit
        this.is_edit = true;
        const delivery_edit_data = await this.apiService.get('delivery/' + this.id).toPromise();
        const delivery_detail = delivery_edit_data['delivery_details'];
        const submission_detail =  await this.apiService.get('submission/' + delivery_edit_data['submission_id']).toPromise();
        this.formDelivery.patchValue({
          delivery_no: delivery_edit_data['delivery_number'],
          submission_no: delivery_edit_data['submission_number'],
          delivered_by: delivery_edit_data['delivered_by'],
          leasing_note: delivery_edit_data['leasing_note']
        });
        this._dateValue = delivery_edit_data['delivered_date'];
        this.selected_dealer_name = delivery_edit_data['dealer_name'];
        this.selected_customer_name = delivery_edit_data['customer_name'];

        const check_delivered_api = await this.apiService.get(
          'delivery/by?submission_id=' + delivery_edit_data['submission_id']).toPromise();
        const check_delivered = check_delivered_api['content'];
        console.log(check_delivered);

        check_delivered.forEach(element => {
          element.delivery_details.forEach(element2 => {
            const detail = {
              product_id : element2.product_id,
              sku_id : element2.sku_id
            };
            this.delivered_collection_before.push(detail);
          });
        });

        // loop for submission detail list
        submission_detail['submission_details'].forEach(element => {
          let initial_qty = 0;
          for (let i = 0; i < this.delivered_collection_before.length; i++) {
            if (this.delivered_collection_before[i].product_id === element.product_id) {
              initial_qty = initial_qty + 1;
            }
          }
          const temp_detail = {
            product_name : element.product_name,
            qty : element.qty,
            qty_delivered: initial_qty
          };
          this.sub_detail_list.push(temp_detail);
        });

        // this.dataGridSource
        // loop for product detail
        const dataGridTemp = [];
        delivery_detail.forEach(async element => {
          const stock_api = await this.apiService.get('product_stock/' + element.sku_id).toPromise();
          const product_name = stock_api['product_name'];
          const data_temp = {
            vin : element.vin,
            engine_number : element.engine_number,
            manufacture_year : element.manufacture_year,
            color : element.color,
            product_name : product_name
          };
          dataGridTemp.push(data_temp);
        });
        this.dataGridSource = dataGridTemp;
        console.log(dataGridTemp);
      }

      const submission_api = await this.apiService.get(
        'submission/by?submission_status=APPROVED&has_schedule=TRUE&size=500&sort=id,desc'
        ).toPromise();
      this.submissionCollection = submission_api['content'];

    });
  }

  get productSelectedRowKeys(): number[] {
    return this._productSelectedRowKeys;
  }

  set productSelectedRowKeys(value: number[]) {
    // this._customerValue = (value.length && value[0]) || null;
    this._productSelectedRowKeys = value;
  }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = value;
  }


  async selectSubmissonNo(value) {
    console.log(value);
    this.sub_detail_list = [];
    this.delivered_collection_before = [];
    this.sub_detail_length = value['submission_details'].length;
    this.sub_detail = value['submission_details'];

    const check_delivered_api = await this.apiService.get('delivery/by?submission_id=' + value.id).toPromise();
    const check_delivered = check_delivered_api['content'];

    check_delivered.forEach(element => {
      element.delivery_details.forEach(element2 => {
        const detail = {
          product_id : element2.product_id,
          sku_id : element2.sku_id
        };
        this.delivered_collection_before.push(detail);
      });
    });

    // loop for display submission detail
    this.sub_detail.forEach(element => {
      let initial_qty = 0;
      for (let i = 0; i < this.delivered_collection_before.length; i++) {
        if (this.delivered_collection_before[i].product_id === element.product_id) {
          initial_qty = initial_qty + 1;
        }
      }
      const temp_detail = {
        product_name : element.product_name,
        qty : element.qty,
        qty_delivered: initial_qty
      };
      this.sub_detail_list.push(temp_detail);
    });

    this.selected_submission_no = value.submission_number;
    this.selected_dealer_id = value.dealer_id;
    this.selected_dealer_name = value.dealer_name;
    this.selected_customer_name = value.customer_name;
    this.selected_company_name = value.company_name;
    this.selected_customer_personal_id = value.customer_personal_id;

    this.selected_company_id = value.company_id;
    this.selected_submission_id = value.id;
    this.formDelivery.patchValue({leasing_note : value.leasing_note});

    const product_list_all = [];
    this.sub_detail.forEach(async element => {
      const product_id = element.product_id;
        const product_detail_api = await this.apiService.get(
          'product_stock/by?dealer_id=' + this.selected_dealer_id + '&product_id=' + product_id + '&sales_status=AVAILABLE'
          ).toPromise();

        const each_array = product_detail_api['content'];
          each_array.forEach(async element2 => {
            await product_list_all.push(element2);
          });
    });

    this.dataGridSource = product_list_all;
  }

  calculateSelectedRow(options) {
    if (options.name === 'SelectedRowsSummary') {
        if (options.summaryProcess === 'start') {
            options.totalValue = 0;
        } else if (options.summaryProcess === 'calculate') {
          if (options.component.isRowSelected(options.value.id)) {
                // options.totalValue = options.totalValue + options.value.id;
                options.totalValue = options.totalValue + 1;
            }
        }
    }
  }

  onSelectionChanged(e) {
    e.component.refresh(true);
  }

  back() {
    this.location.back();
  }

  checkClosed() {

  }

  async save(event) {
    // console.log(this.productSelectedRowKeys);
    // console.log(this.sub_detail);

    const myDate    = new Date(this._dateValue);
    const delivery_date_post = myDate.toISOString();

    const post_detail = [];
    const sub_detail_compare = [];
    let is_valid = 0;

    this.sub_detail.forEach(data_2 => { // get detail from submission
      let initial_qty = 0;
      for (let i = 0; i < this.delivered_collection_before.length; i++) {
        if (this.delivered_collection_before[i].product_id === data_2.product_id) {
          initial_qty = initial_qty + 1;
        }
      }
      const qty_remains = data_2.qty - initial_qty;
      const sub_detail_loop = {
        product_name: data_2.product_name,
        product_id: data_2.product_id,
        qty_order: data_2.qty,
        qty_delivered: initial_qty,
        qty_remains: qty_remains
      };
      sub_detail_compare.push(sub_detail_loop);
    });

    if (this.productSelectedRowKeys !== undefined) {
      for (const data of this.productSelectedRowKeys) {
        // this.apiService.get('product_stock/' + data).subscribe(data_stock => {
          const data_stock = await this.apiService.get('product_stock/' + data).toPromise();
          const product_detail_loop = {
            color: data_stock['color'],
            engine_number: data_stock['engine_number'],
            manufacture_year: data_stock['manufacture_year'],
            product_id: data_stock['master_product_id'],
            sku_id: data_stock['id'],
            vin: data_stock['vin']
          };
          post_detail.push(product_detail_loop);
           // compare selected item with detail submission data
           for (let i = 0; i < sub_detail_compare.length; i++ ) {
            let qty_delivered = sub_detail_compare[i].qty_delivered;
            if (sub_detail_compare[i].product_id === data_stock['master_product_id']) {
              qty_delivered = qty_delivered + 1;
            }
            sub_detail_compare[i].qty_delivered = qty_delivered;
          }
    }
    console.log(sub_detail_compare);
    // validation
    for (const element of sub_detail_compare) {
      if ( element.qty_delivered > element.qty_order) {
        alert(element.product_name + ' is more than Qty ordered');
        is_valid = 1;
      }

    }
    if (is_valid === 1) {
      return false;
    }
  }

    const post_value = {
      company_id: this.selected_company_id,
      company_name: this.selected_company_name,
      customer_company_id: this.selected_company_id,
      customer_name: this.selected_customer_name,
      customer_personal_id: this.selected_customer_personal_id,
      dealer_id: this.selected_dealer_id,
      dealer_name: this.selected_dealer_name,
      delivered_by: this.formDelivery.value.delivered_by,
      delivered_date: delivery_date_post,
      // delivery_number: this.formDelivery.value.delivery_no,
      // delivery_status: this.formDelivery.value.delivery_status,
      leasing_note: this.formDelivery.value.leasing_note,
      submission_id: this.selected_submission_id,
      submission_number: this.selected_submission_no,
      delivery_details: post_detail
    };
    // console.log(sub_detail_compare);
    // console.log(post_detail);

    // api change status of selected product to SOLD
    post_detail.forEach( data => {
      console.log(data);
      const status_update = {
        sales_status: 'SOLD'
      };
     this.apiService.put('product_stock/sales_status/' + data.sku_id, status_update).subscribe(
      success => {
        console.log(success);
      },
      error => {
        console.log(error);
      });
    });

    // api save / post
    this.apiService.post('delivery/', post_value).subscribe(
      success => {
        console.log(success);
        this.router.navigate(['transaction/delivery']);
      },
      error => {
        console.log(error);
    });

    // update has_delivered status to CLOSED if all item qty_remains = 0
    // let can_closed = false;
    // const toggle = sub_detail_compare.every(item => {
    //   if (item.qty_remains === 0) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // });
    // console.log(sub_detail_compare);
    // console.log(toggle);



  }

}
