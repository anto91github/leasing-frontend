import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeliveryComponent } from './delivery.component';
import { DeliveryFormComponent} from './delivery-form.component';

const routes: Routes = [
  {
    path: '',
    component: DeliveryComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: DeliveryFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/info',
    component: DeliveryFormComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeliveryRoutingModule { }
