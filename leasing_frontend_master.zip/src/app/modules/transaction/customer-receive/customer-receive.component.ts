import { Component, OnInit } from '@angular/core';
import { fadeIn } from '../../../shared/animations';

@Component({
  selector: 'app-customer-receive',
  templateUrl: './customer-receive.component.html',
  styles: [],
  animations: [fadeIn()]
})
export class CustomerReceiveComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
