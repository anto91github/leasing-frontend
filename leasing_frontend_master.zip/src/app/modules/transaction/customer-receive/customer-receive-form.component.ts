import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { delay } from 'rxjs/operators';
import { LocalStorageService } from 'ngx-webstorage';

import { fadeIn } from '../../../shared/animations';
import { ApiService, Master } from '../../../core';

@Component({
  selector: 'app-customer-receive-form',
  changeDetection: ChangeDetectionStrategy.Default,
  templateUrl: './customer-receive-form.component.html',
  animations: [fadeIn()]
})
export class CustomerReceiveFormComponent implements OnInit {
  form: FormGroup;
  formProduct: FormGroup;
  items: FormArray;
  products = [];
  vendors = [];

  constructor(
    private apiService: ApiService,
    private localStorageService: LocalStorageService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.loadProducts();
    this.loadVendors();
    this.formProduct = this.formBuilder.group({
      date: '',
      vendor: '',
      items: this.formBuilder.array([this.createItem()])
    });
  }
  get formItems(): FormGroup {
    return this.formProduct.get('items') as FormGroup;
  }

  private loadProducts() {
    this.apiService
      .get('product')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(product => {
          product.stock_collection.forEach(stock => {
            items.push({
              id: stock.id,
              title: product.brand + ' - ' + product.type + ' - ' + product.model,
              category: product.category,
              cylinder: product.cylinder,
              fuel: product.fuel,
              model: product.model,
              picture: product.picture,
              price: stock.price,
              color: stock.color,
              engine_number: stock.engine_number,
              manufacture_year: stock.manufacture_year,
              vin: stock.vin
            });
          });
        });
        this.products = [...items];
      });
  }

  private loadVendors(): any {
    const company_active = this.localStorageService.retrieve('user_company_active');
    this.apiService
      .get('vendor?sort=vendorName,asc&company_id=' + company_active)
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push({ id: el.id, title: el.vendor_name, type: el.vendor_type });
        });
        this.vendors = [...items];
      });
  }

  private createItem(): FormGroup {
    return this.formBuilder.group({ product: '', price: 0, amount: 0, total: 0 });
  }

  changeProduct(event, i: number) {
    const control = <FormArray>this.formProduct.controls['items'];
    control.at(i).patchValue({ price: event.price, amount: 1, total: event.price });
    console.log('Current item ', control.value[i]);
  }

  addItem($event): void {
    this.items = this.formProduct.get('items') as FormArray;
    this.items.push(this.createItem());
  }

  editItem(event, i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    control.at(i).patchValue({ total: control.value[i].price * control.value[i].amount });
    console.log('Current item ', control.value[i]);
  }

  deleteItem(i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    control.removeAt(i);
  }

  save(): void {
    console.log('save');
    console.log(this.form.value);
  }

  back(): void {
    console.log('back');
  }
}
