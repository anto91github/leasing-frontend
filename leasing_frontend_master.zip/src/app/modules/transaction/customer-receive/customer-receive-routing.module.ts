import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerReceiveComponent } from './customer-receive.component';
import { CustomerReceiveFormComponent } from './customer-receive-form.component';

const routes: Routes = [
  {
    path: '',
    component: CustomerReceiveComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: CustomerReceiveFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerReceiveRoutingModule {}
