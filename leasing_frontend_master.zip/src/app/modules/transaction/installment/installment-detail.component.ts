import { Component, OnInit, Inject, ElementRef, ViewChild, Renderer } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

import { fadeIn } from '../../../shared/animations';
import { installment } from '../../../core/samples';
import { LocalStorageService } from 'ngx-webstorage';
import { ApiService, Product, Attachment, Master, ConfigService } from '../../../core';
import { Installment } from '../../../core/models/installment.model';
import { DxDataGridComponent } from 'devextreme-angular';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-installment-detail',
  templateUrl: './installment-detail.component.html',
  providers: [TranslateService],
  animations: [fadeIn()]
})
export class InstallmentDetailComponent implements OnInit {
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  row: any = [];
  dataGridPageSize = 10;
  dataGridSource: any = {};
  dataGridPageSizePenalty = 10;
  dataGridSourcePenalty: any = {};
  installment: any;
  id: number = null;

  payment_date: any;
  payment_status: any;
  submission_number: any;
  product_name: any;
  customer_name: any;
  leasing_id: any;
  balance: any;
  interest_paid: any;
  principal_paid: any;
  payment_amount: any;
  installment_amount: any;
  installment_date: any;
  leasing_type: any;
  dealer_name: any;
  repayment_schedule_details: any;
  repayment_schedule_penalty: any;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private location: Location,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService,
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private router: Router,
    private renderer: Renderer,
    private config: ConfigService,
    private sanitizer: DomSanitizer
  ) {

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];

      this.apiService
        .get('repayment_schedule/' + this.id)
        .subscribe((data: any) => {
          console.log(data);
          this.dealer_name = data.dealer_name;
          this.payment_status = data.repayment_status;
          this.submission_number = data.submission_number;
          this.leasing_type = data.leasing_type;
          this.customer_name = data.customer_name;
          this.leasing_id = data.leasing_id;
          this.balance = data.balance;
          this.interest_paid = data.interest_paid;
          this.principal_paid = data.principal_paid;
          this.payment_amount = data.payment_amount;
          this.installment_amount = data.repayment_amount;
          this.installment_date = data.payment_date;
          this.repayment_schedule_details = data.repayment_schedule_details;
          this.repayment_schedule_penalty = data.repayment_schedule_penalty;

          this.dataGridSource = this.repayment_schedule_details;
          // console.log(data);
          this.dataGridPageSize = this.config.getConfig('paginationLength');

          const items = [];
          items.push(this.repayment_schedule_penalty);
          this.dataGridSourcePenalty = items;
          this.dataGridPageSizePenalty = this.config.getConfig('paginationLength');
        });
    });
  }

  loadImage(url) {
    url = url === '' || url + '' === 'null' ? 'assets/img/no-image.png' : url;
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  /**
   * Print preview with PDF format
   */
  print() {
    const columns = [
      { title: 'No', dataKey: 'no' }
      // { title: this.translateService.instant('app.period'), dataKey: 'period' },
      // { title: this.translateService.instant('app.due_date'), dataKey: 'due_date' },
      // { title: 'Total', dataKey: 'total' },
      // { title: this.translateService.instant('app.penalty'), dataKey: 'penalty' },
      // { title: this.translateService.instant('app.marital_status'), dataKey: 'status' }
    ];
    const rows = [];

    const columns_head = [
      // this.translateService.instant('app.customer'),
      // this.translateService.instant('app.product')
    ];
    const rows_head = [
      ['BB King', 'Bajaj B'],
      ['Perumahan Reni Jaya Baru Block BB2 Jln.Beratasa 3 No.06', 'JSA 1360'],
      ['Pamulang - Tangerang selatan, 15416', 'Passenger Carrier'],
      ['085238476598', 'D-IV CNG'],
      ['viralim@yahoo.com', ' ']
    ];

    // this.sampleService.getInstallment().subscribe(
    //   (items: Installment[]) => {
    //     for (let i = 0; i < items.length; i++) {
    //       rows.push({
    //         no: `${i + 1}.`,
    //         period: items[i].period,
    //         due_date: items[i].due_date,
    //         total: items[i].total,
    //         penalty: items[i].penalty,
    //         status: items[i].status
    //       });
    //     }

    //     const doc = new jsPDF('p', 'pt');
    //     doc.autoTable(columns_head, rows_head, {
    //       addPageContent: function(data, title) {
    //         doc.text('Details of Installment', 40, 30);
    //       },
    //       theme: 'plain',
    //       margin: { top: 40 },
    //       bodyStyles: { valign: 'top' },
    //       styles: { overflow: 'linebreak', fontSize: 7,cellPadding:1 },
    //       columnStyles: { text: { columnWidth: 'auto' } }
    //     });
    //     doc.autoTable(columns, rows, {
    //       margin: { top: 160 },
    //       bodyStyles: { valign: 'top' },
    //       styles: { overflow: 'linebreak', fontSize: 7 },
    //       columnStyles: { text: { columnWidth: 'auto' } }
    //     });
    //     window.open(doc.output('bloburl'));
    //   },
    //   error => {
    //     console.log(error);
    //   }
    // );
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }
}
