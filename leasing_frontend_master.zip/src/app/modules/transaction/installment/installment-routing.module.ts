import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InstallmentComponent } from './installment.component';
import { InstallmentFormComponent } from './installment-form.component';
import { InstallmentDetailComponent } from './installment-detail.component';

const routes: Routes = [
  {
    path: '',
    component: InstallmentComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: ':id/pay',
    component: InstallmentFormComponent,
    data: {
      breadcrumb: 'app.pay'
    }
  },
  {
    path: ':id',
    component: InstallmentDetailComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InstallmentRoutingModule {}
