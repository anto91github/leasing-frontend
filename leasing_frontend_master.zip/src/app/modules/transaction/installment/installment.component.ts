import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { ApiService} from './../../../core/services';
import { fadeIn } from '../../../shared/animations';
import { Installment, SampleService, ConfigService } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';
import { DxDataGridComponent, DxNumberBoxModule } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import { Master } from '../../../core/models';

@Component({
  selector: 'app-installment',
  templateUrl: './installment.component.html',
  providers: [ApiService, TranslateService],
  animations: [fadeIn()]
})
export class InstallmentComponent implements OnInit {
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  dataGridSource: any = {};
  dataGridPageSize = 10;

  route = 'transaction/installment/';

  page_view_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_print: boolean;
  allow_export: boolean;

  constructor(
    @Inject(ApiService) apiServices: ApiService,
    @Inject(ApiService) apiServiceInject: ApiService,
    private apiService: ApiService,
    private translateService: TranslateService,
    private sampleService: SampleService,
    private router: Router,
    private config: ConfigService,
    private datePipe: DatePipe,
    private localSt: LocalStorageService
  ) {
    this.title = this.translateService.instant('app.installment');

    this.allow_view = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'transaction.installment.view';
    this.page_print_permission = 'transaction.installment.print';
    this.page_export_permission = 'transaction.installment.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.installment')
      );
      this.location.back();
    }

    this.dataGridSource.store = new CustomStore({
      load: function (options: any) {
        return apiServiceInject.getSubmissionApprove('submission/by', options);
      },
      remove: function (row: any) {
        return apiService
          .delete('submission/' + row.id)
          .toPromise()
          .then(
            data => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
  }

  ngOnInit() {}

  actionDetails(data) {
    // console.log(data);
    this.router.navigate([this.route, data.value]);
  }

  actionCheck(data) {
    // console.log(data);
    // this.router.navigate([this.route, data.columnIndex, 'pay']);
    this.router.navigate([this.route, data.value, 'pay']);
  }

  actionDelete(row) { }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {}

// Print For Detail Installment
 async actionPrint(value) {
   // alert('PRINT');

    const data_installment = await this.apiService.get('submission/' + value).toPromise();
  // //  console.log(data_installment);
    const doc = new jsPDF('p', 'pt');
  //   // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    // Only pt supported (not mm or in)
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: 'Payment No', dataKey: 'payment_number' },
      { title: 'Payment Date', dataKey: 'payment_date' },
      { title: 'Balance', dataKey: 'balance' },
      { title: 'Principal Paid', dataKey: 'principal_paid' },
      { title: 'Interest', dataKey: 'interest_paid' },
      { title: 'Payment Amount', dataKey: 'payment_amount' },
      { title: 'Penalty', dataKey: 'penalty' },
      { title: 'Total Repayment', dataKey: 'total_repayment' },
      { title: 'Repayment Penalty', dataKey: 'repayment_penalty' },
      { title: 'Status', dataKey: 'repayment_status' },
  ];

    const rows = [];
    //  let penalty = 0;
    // for (let i = 0; i < data_installment['repayment_schedules']['length']; i++ ) {
    //   rows.push({
    //     no: `${i + 1}.`,
    //     payment_number: data_installment['repayment_schedules'][i].payment_number,
    //     payment_date: data_installment['repayment_schedules'][i].payment_date,
    //     balance: data_installment['repayment_schedules'][i].balance,
    //     principal_paid: data_installment['repayment_schedules'][i].principal_paid,
    //     interest_paid : data_installment['repayment_schedules'][i].interest_paid,
    //     payment_amount: data_installment['repayment_schedules'][i].payment_amount,
    //     repayment_penalty: data_installment['repayment_schedules'][i].repayment_penalty,
    //     total_repayment: data_installment['repayment_schedules'][i].total_repayment,
    //     // payment_amount: data_installment['repayment_schedules'][i].repayment_penalty,
    //     repayment_status : data_installment['repayment_schedules'][i].repayment_status,
    //   });
    // }

    data_installment['repayment_schedules'].forEach(element => {
      let penalty = 0;
      let repayment_penalty = 0;
      let total_repayment = 0;

      if (element['repayment_penalty']) {
        repayment_penalty = element['repayment_penalty'];
      }
      if (element['repayment_schedule_penalty']) {
        total_repayment = element['total_repayment'];
      }
      if (element['repayment_schedule_penalty']) {
        penalty = element['repayment_schedule_penalty']['penalty_amount'];
      }

      rows.push({
        no: element.payment_number,
        payment_number: element.payment_number,
        payment_date: element.payment_date,
        balance: element.balance,
        principal_paid: element.principal_paid,
        interest_paid : element.interest_paid,
        payment_amount: element.payment_amount,
        penalty : penalty,
        repayment_penalty: repayment_penalty,
        total_repayment: total_repayment,
        // payment_amount: data_installment['repayment_schedules'][i].repayment_penalty,
        repayment_status : element.repayment_status,
      });
    });
    const rows_head = [];
    const col_empty = ['', ''];
    const row_empty = [];
    const columns_head = ['', '', '', ''];


  //   const col_before_tax = ['', '', ''];
  //   const row_before_tax = [
  //       [
  //         'Total Invoice',
  //         ':',
  //         this.formatNumber(data_pp['total_invoice'])
  //       ],
  //       [
  //         'Total Payment ',
  //         ':',
  //         this.formatNumber(data_pp['total_payment'])
  //       ]
  //     ];

  //   const col_after_tax = ['', '', ''];
  //   const row_after_tax = [
  //       // [
  //       //   'Remaining Payment',
  //       //   ':',
  //       //   this.formatNumber(data_pp['total_invoice']-data_pp['total_payment'])
  //       // ]
  //     ];

  //     // draw PDF
      rows_head.push({
        0: 'Submission Number: ' +  data_installment['submission_number']
      });
      rows_head.push({
        0: 'submission_date: ' +  data_installment['submission_date']
      });
      rows_head.push({
        0: 'Dealer: ' +  data_installment['dealer_name']
      });
      rows_head.push({
        0: 'Customer  : ' + data_installment['customer_name']
      });
      rows_head.push({
        0: 'Type: ' +  data_installment['leasing_type']
      });
      rows_head.push({
        0: 'Interest: ' +  data_installment['interest']
      });
      rows_head.push({
        0: 'Down Payment: ' +  data_installment['down_payment']
      });

      rows_head.push({
        0: 'Period: ' +  data_installment['period']
      });
      rows_head.push({
        0: 'Total: ' +  data_installment['total_price']
      });



      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('INSTALLMENT SCHEDULE', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

     // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });


       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });
     window.open(doc.output('bloburl'));
   }

   actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.installment')
      );
      return false;
    }

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.submission_number'), dataKey: 'submission_number' },
      { title: this.translateService.instant('app.submission_date'), dataKey: 'submission_date' },
      { title: this.translateService.instant('app.dealer'), dataKey: 'dealer_name' },
      { title: this.translateService.instant('app.customer'), dataKey: 'customer_name' },
      { title: this.translateService.instant('app.type'), dataKey: 'leasing_type' },
      { title: this.translateService.instant('app.interest'), dataKey: 'interest' },
      { title: this.translateService.instant('app.down_payment'), dataKey: 'down_payment' },
      { title: this.translateService.instant('app.period'), dataKey: 'period' },
      { title: this.translateService.instant('app.total'), dataKey: 'total_price' },
      { title: this.translateService.instant('app.status'), dataKey: 'submission_status' },
  ];
    const rows = [];
    const company_id = this.localSt.retrieve('user_company_active');
    this.apiService.get('submission/by?submission_status=APPROVED&has_schedule=TRUE&company_id=' + company_id )
    .subscribe((success: any) => {
      const items = success.content;
    console.log(items);
      for (let i = 0; i < items.length; i++) {
        rows.push({
          no: `${i + 1}.`,
          submission_number: items[i].submission_number,
          submission_date: items[i].submission_date,
          dealer_name: items[i].dealer_name,
          customer_name: items[i].customer_name,
          leasing_type : items[i].leasing_type,
          interest: items[i].interest,
          down_payment : items[i].down_payment,
          period : items[i].period,
          total_price: items[i].total_price,
          submission_status : items[i].submission_status,
        });
      }

      // Only pt supported (not mm or in)
      const doc = new jsPDF('p', 'pt');
      doc.autoTable(columns, rows, {
              addPageContent: function() {
                doc.text('Installment', 40, 30);
              },
              margin: { top: 60 },
              bodyStyles: { valign: 'top' },
              styles: { overflow: 'linebreak', fontSize: 7 },
              columnStyles: { text: { columnWidth: 'auto' } }
            });
            window.open(doc.output('bloburl'));
    });
  }

  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.installment')
      );
      return false;
    }
  //   this.sampleService.getInstallment().subscribe(
  //     (items: Installment[]) => {
  //       const table = [];
  //       items.forEach(el => {
  //         table.push({
  //           ID: el.id,
  //           [this.translateService.instant('app.period')]: el.period,
  //           [this.translateService.instant('app.due_date')]: el.due_date,
  //           [this.translateService.instant('app.product')]: el.product,
  //           ['Total']: el.total,
  //           [this.translateService.instant('app.penalty')]: el.penalty,
  //           ['Status']:
  //             el.status === 'paid'
  //               ? this.translateService.instant('app.paid')
  //               : this.translateService.instant('app.unpaid')
  //         });
  //       });
  //       const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
  //       const wb: XLSX.WorkBook = XLSX.utils.book_new();
  //       XLSX.utils.book_append_sheet(wb, ws, this.title);
  //       XLSX.writeFile(wb, `${this.title}.xlsx`);
  //     },
  //     error => {
  //       console.log(error);
  //     }
  //   );
  // }
  const company_active = this.localSt.retrieve('user_company_active');
    this.apiService.get('submission/by?submission_status=APPROVED&has_schedule=TRUE&company_id=' + company_active).subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.submission_number')]: el.submission_number,
            [this.translateService.instant('app.submission_date')]: el.submission_date,
            [this.translateService.instant('app.dealer')]: el.dealer_name,
            [this.translateService.instant('app.customer')]: el.customer_name,
            [this.translateService.instant('app.type')]: el.leasing_type,
            [this.translateService.instant('app.interest')]: el.interest,
            [this.translateService.instant('app.down_payment')]: el.down_payment,
            [this.translateService.instant('app.period')]: el.period,
            [this.translateService.instant('app.total')]: el.total_price,
            [this.translateService.instant('app.status')]: el.submission_status
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }
  async actionPrintDetail(value) {
    const data_instde = await this.apiService.get('repayment_schedule/' + value).toPromise();
    console.log(data_instde);
    const doc = new jsPDF('p', 'pt');
  //   // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    // Only pt supported (not mm or in)
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: 'Payment Date', dataKey: 'payment_date' },
      { title: 'Payment Amount', dataKey: 'payment_amount' },
      { title: 'Payment Note', dataKey: 'payment_note' },
      // { title: 'Img', dataKey: 'payment_proof' }
  ];

    const rows = [];
    for (let i = 0; i < data_instde['repayment_schedule_details']['length']; i++ ) {
      console.log(data_instde['repayment_schedule_details'][i].payment_proof);
      rows.push({
        no: `${i + 1}.`,
        payment_date : data_instde['repayment_schedule_details'][i].payment_date,
        payment_amount: data_instde['repayment_schedule_details'][i].payment_amount,
        payment_note: data_instde['repayment_schedule_details'][i].payment_note
      });
    }

    const rows_head = [];
    const col_empty = ['', ''];
    const row_empty = [];
    const columns_head = ['', '', '', ''];
    const col_penalty = [
      { title: 'No', dataKey: 'no' },
      { title: 'Payment Date', dataKey: 'payment_date' },
      { title: 'Penalty Amount', dataKey: 'penalty_amount' },
      { title: 'Due Date', dataKey: 'due_date' },
      { title: 'Status', dataKey: 'penalty_status' },
    ];

    const rows_penalty = [];
    // for (let i = 0; i < data_instde['repayment_schedule_details']['length']; i++ ) {
      rows_penalty.push({
        no: `${1}.`,
        payment_date : data_instde['repayment_schedule_penalty'].payment_date,
        penalty_amount: data_instde['repayment_schedule_penalty'].penalty_amount,
        due_date: data_instde['repayment_schedule_penalty'].due_date,
        penalty_status: data_instde['repayment_schedule_penalty'].penalty_status,
      });
     // header detail installment
      rows_head.push({
        0: 'Customer  : ' + data_instde['customer_name']
      });
      rows_head.push({
        0: 'Installment Date: ' +  data_instde['repayment_date']
      });
      rows_head.push({
        0: 'Dealer: ' +  data_instde['dealer_name']
      });
      rows_head.push({
        0: 'Type: ' +  data_instde['leasing_type']
      });
      rows_head.push({
        0: 'Submission No: ' +  data_instde['submission_number']
      });



      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('Detail Installment', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

     // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });


       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });



    this.apiService.get('repayment_schedule/' + value).subscribe(
      (response: any) => {
      // to get y position of last autotable
      const finalY = doc.autoTable.previous.finalY + 15;
  //     const finalY2 = doc.autoTable.previous.finalY + 25;
  //     const finalY3 = doc.autoTable.previous.finalY + 45;

      // Penalty
      doc.autoTable(col_penalty, rows_penalty, {
        addPageContent: function (data) {
        },
        theme: 'grid',
        margin: { top: finalY },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });

     window.open(doc.output('bloburl'));
 });
   }
  }

