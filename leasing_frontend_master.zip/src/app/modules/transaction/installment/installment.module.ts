import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';

import { InstallmentRoutingModule } from './installment-routing.module';
import { InstallmentComponent } from './installment.component';
import { InstallmentFormComponent } from './installment-form.component';
import { InstallmentDetailComponent } from './installment-detail.component';
import { MaskModule } from 'soft-angular-mask';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask/src/currency-mask.config';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxDateBoxModule,
  DxNumberBoxModule,
  DxBoxModule,
  DxFormModule,
  DxSelectBoxModule,
  DxCheckBoxModule
} from 'devextreme-angular';
import { NgSelectModule } from '@ng-select/ng-select';

/** Setting Currency Monney */
export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: 'left',
  allowNegative: true,
  decimal: '.',
  precision: 0,
  prefix: '',
  suffix: '',
  thousands: '.'
};

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    InstallmentRoutingModule,
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxDateBoxModule,
    DxNumberBoxModule,
    DxBoxModule,
    DxFormModule,
    DxCheckBoxModule,
    DxSelectBoxModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    CurrencyMaskModule,
    MaskModule,
    FlashMessagesModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function (http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [InstallmentComponent, InstallmentFormComponent, InstallmentDetailComponent],
  providers: [
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ],
})
export class InstallmentModule { }
