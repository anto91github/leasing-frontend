import { Component, OnInit, Inject, ElementRef, ViewChild, Renderer } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { fadeIn } from '../../../shared/animations';
import { installment } from '../../../core/samples';
import { LocalStorageService } from 'ngx-webstorage';
import { ApiService, Product, Attachment, Master } from '../../../core';
import { FlashMessagesService } from 'angular2-flash-messages';
import { angularMath } from 'angular-ts-math';

@Component({
  selector: 'app-installment-form',
  templateUrl: './installment-form.component.html',
  styleUrls: ['./installment-form.component.scss'],
  animations: [fadeIn()]
})
export class InstallmentFormComponent implements OnInit {
/* tslint:disable */
  img_src = 'assets/img/no-image.png';
  img_src_penalty = 'assets/img/no-image.png';
  img_added = false;
  @ViewChild('file_attachment')
  file_attachment: ElementRef;

  @ViewChild('file_attachment_penalty')
  file_attachment_penalty: ElementRef;

  @ViewChild('InstallmentAmount')
  InstallmentAmount: ElementRef;

  formProduct: FormGroup;
  id: number = null;
  form: FormGroup;
  installment: any;
  now: Date = new Date();
  maxDate: Date = new Date();
  _dateValue: any;

  payment_date: any;
  repayment_status: any;
  submission_number: any;
  product_name: any;
  customer_name: any;
  leasing_id: any;
  balance = 0;
  sub_total = 0;
  payment = 0;
  interest_paid: any;
  principal_paid: any;
  payment_amount: any;
  installment_amount: any;

  priceInstallment: any;
  repayment_schedule_details: any;
  repayment_schedule_penalty: any;
  id_installment: any;
  company_id: any;
  dealer_id: any;
  dealer_name: any;
  customer_personal_id: any;
  customer_company_id: any;
  company_name: any;
  leasing_type: any;
  down_payment: any;
  period: any;
  payment_number: any;
  interest: any;
  repayment_date: any;
  repayment_amount = 0;
  submission_id: any;
  form_put_repayment_schedule: any;
  balance_original = 0;
  formData_attachment: any;
  formData_attachment_penalty: any;
  repayment_penalty = 0;
  form_repayment_details_penalty: any;
  penalty_status: any;
  acc = false;
  repaymentPenalty_value: any;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private location: Location,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService,
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private router: Router,
    private renderer: Renderer,
    private flashMessage: FlashMessagesService
  ) {
    this.dateValue = this.now;
  }

  ngOnInit() {
    this.form = new FormGroup(
      {
        // InvoiceDate: this.now,
        installment_date: new FormControl('', {
          // validators: Validators.required
        }),
        installment_amount: new FormControl('', {
          validators: Validators.required
        }),
        repayment_penalty: new FormControl('', {
          // validators: Validators.required
        }),
        payment_note: new FormControl('', {
          // validators: Validators.required
        }),
        payment_proof: new FormControl('', {}),
        payment_proof_penalty: new FormControl('', {})
      },
      { updateOn: 'blur' }
    );

    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (!this.id) {
        return;
      }
      this.apiService
        .get('repayment_schedule/' + this.id)
        .subscribe((data: any) => {
          this.id_installment       = data.id;
          this.submission_number    = data.submission_number;
          this.submission_id        = data.submission_id;
          this.company_id           = data.company_id;
          this.company_name         = data.company_name;
          this.dealer_id            = data.dealer_id;
          this.dealer_name          = data.dealer_name;
          this.customer_personal_id = data.customer_personal_id;
          this.customer_company_id  = data.customer_company_id;
          this.customer_name        = data.customer_name;
          this.leasing_type         = data.leasing_type;
          this.interest_paid        = data.interest_paid;
          this.down_payment         = data.down_payment;
          this.period               = data.period;
          this.payment_number       = data.payment_number;
          this.payment_date         = data.payment_date;
          this.interest             = data.interest;
          this.principal_paid       = data.principal_paid;
          this.payment_amount       = data.payment_amount;
          this.repayment_date       = data.repayment_date;
          this.payment_amount       = data.payment_amount;
          this.balance =  data.payment_amount;
          this.repayment_amount     = data.repayment_amount;
          // this.repayment_penalty = data.repayment_penalty;
          // this.repayment_penalty = data.repayment_schedule_penalty.penalty_amount;
          this.balance_original     = data.balance;
          this.repayment_status     = data.repayment_status;
          this.repayment_schedule_details = data.repayment_schedule_details;
          this.repayment_schedule_penalty = data.repayment_schedule_penalty;


          /** Parameter Pasrsing Data */
          this.sub_total = data.payment_amount;

          if (!this.repayment_schedule_penalty) {
              this.repayment_penalty = 0;
              this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
          } else {
            if (!this.repayment_schedule_penalty.penalty_amount) {
              this.repayment_penalty = 0;
              this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
            }
            if (this.repayment_schedule_penalty.penalty_status === 'PAID') {
              this.repayment_penalty = 0;
              this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
            }
          }

          /** Calculate Repayment Schedule Details Payment Amount*/
          const sum = this.repayment_schedule_details;
          const outValue = [];
          for (let i = 0; i < sum.length; i++) {
            outValue.push(sum[i].payment_amount);
          }
          if (outValue.length === 0) {
            this.form.get('installment_amount').patchValue(this.balance);
            if (!this.repayment_schedule_penalty) {
              this.repayment_penalty = 0;
              this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
            } else {
              if (!this.repayment_schedule_penalty.penalty_amount) {
                this.repayment_penalty = 0;
                this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
              } else {
                this.repayment_penalty = this.repayment_schedule_penalty.penalty_amount;
                this.form.get('repayment_penalty').patchValue(this.repayment_schedule_penalty.penalty_amount);
              }
              if (this.repayment_schedule_penalty.penalty_status === 'PAID') {
                this.repayment_penalty = 0;
                this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
              }
            }
          } else {
            const reducer = (accumulator, currentValue) => accumulator + currentValue;
            this.payment = outValue.reduce(reducer);
            // this.balance = this.sub_total - this.payment;
            // this.balance = this.financial(this.sub_total - this.payment);

            this.balance = Number(angularMath.getNumberWithDecimals(this.sub_total - this.payment, 2));
            this.form.get('installment_amount').patchValue(this.balance);

            if (!this.repayment_schedule_penalty) {
              this.repayment_penalty = 0;
              this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
            } else {
              if (!this.repayment_schedule_penalty.penalty_amount) {
                this.repayment_penalty = 0;
                this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
              } else {
                this.repayment_penalty = this.repayment_schedule_penalty.penalty_amount;
                this.form.get('repayment_penalty').patchValue(this.repayment_schedule_penalty.penalty_amount);
              }
              if (this.repayment_schedule_penalty.penalty_status === 'PAID') {
                this.repayment_penalty = 0;
                this.form.get('repayment_penalty').patchValue(this.repayment_penalty);
              }
            }
          }
        });
    });
  }

  financial(x) {
    return Number(parseFloat(x).toFixed(2));
  }

  save() {
    if (this.form.valid) {
      if (this.img_added) {
          const inputEl: HTMLInputElement        = this.file_attachment.nativeElement;
          const inputElPenalty: HTMLInputElement = this.file_attachment_penalty.nativeElement;
          this.formData_attachment         = new FormData();
          this.formData_attachment_penalty = new FormData();

          if (inputEl.files.item(0)) {
            this.formData_attachment.append('file', inputEl.files.item(0));
            this.apiService.post('attach', this.formData_attachment).subscribe(
            (response: any) => {
              this.form.get('payment_proof').patchValue(response.body.file_download_uri);
                if (!inputElPenalty.files.item(0)) {
                  this.saveForm();
                } else {
                  this.formData_attachment_penalty.append('file', inputElPenalty.files.item(0));
                  this.apiService.post('attach', this.formData_attachment_penalty).subscribe(
                    (response: any) => {
                      this.form.get('payment_proof_penalty').patchValue(response.body.file_download_uri);
                      this.saveForm();
                    },
                    error => {
                      console.log(error);
                    }
                  );
                }
            },
            error => { console.log(error); }
          );
         }
          return false;
        } else {
          this.saveForm();
          return false;
        }
      }
  }
  checkPaymentStatus(payment, db_amount) {
    // unpaid, paid, partial
    // 0     , 2   , 1
    let payment_status = 0;

    if (payment === 0) {
      payment_status = 0;
    } else {
      if (payment === db_amount) {
        payment_status = 2;
      } else {
        payment_status = 1;
      }
    }

    return payment_status;
  }

  checkPenaltyStatus(schedule_penalty) {
    // empty, unpaid, paid
    // 0     , 1      , 2
    let penalty_status = 0;

    if (schedule_penalty) {
      if (schedule_penalty.repayment_amount !==0) {
        penalty_status = 2;
      } else {
        penalty_status = 1;
      }
    } else {
      penalty_status = 0;
    }

    return penalty_status;
  }

  async saveForm() {
    const form = this.form.value;
    /** Convert Format Date to ISO */
    const installmentDate    = new Date(this.dateValue);
    const NewInstallmentDate = installmentDate.toISOString();

    if (form.installment_amount) {
      if (form.installment_amount > this.balance) { // yang dibayarkan tidak boleh lebih dari principal nya
        this.flashMessage.show('Repayment amount are not permitted for more than the amount of fines !', {
          cssClass: 'alert-danger',
          showCloseBtn: true,
          dalay: 3600
        });
        return false;
      }
    }

    if (form.repayment_penalty || this.repayment_penalty) {
      if (form.repayment_penalty > this.repayment_penalty) { // pinalti yg dibayar tidak boleh melebihi dr yg ditentukan
        this.flashMessage.show('Payment penalties are not permitted for more than the amount of fines !', {
          cssClass: 'alert-danger',
          showCloseBtn: true,
          dalay: 3600
        });
        return false;
      }
      if (form.repayment_penalty === this.repayment_penalty) {
        this.penalty_status = 'PAID';
        this.repayment_penalty = form.repayment_penalty;
      }
      if (form.repayment_penalty === 0) {
        this.acc = true;
      } else { // pinalti tidak boleh kurang dr yg ditentukan
        if (form.repayment_penalty < this.repayment_penalty) {
          this.flashMessage.show('Payment penalties are not permitted for less than the amount of fines !', {
            cssClass: 'alert-danger',
            showCloseBtn: true,
            dalay: 3600
          });
          return false;
        }
      }

      this.form_repayment_details_penalty = {
        repayment_penalty: { id: this.id_installment },
        due_date: this.repayment_schedule_penalty.due_date,
        penalty_amount: this.repayment_schedule_penalty.penalty_amount,
        payment_date: NewInstallmentDate,
        repayment_amount: form.repayment_penalty,
        penalty_status: this.penalty_status,
        proof_payment: form.payment_proof_penalty
      };

      await this.apiService.put('repayment_schedule/penalty/' + this.repayment_schedule_penalty.id, this.form_repayment_details_penalty)
      .subscribe(
        success => {
          console.log(success);
        },
        error => {
          console.log(error);
        }
      );
    }

    const form_repayment_details = {
      repayment_detail: { id: this.id_installment },
      payment_amount: form.installment_amount,
      payment_date: NewInstallmentDate,
      payment_note: form.payment_note,
      payment_proof: form.payment_proof
    };

    await this.apiService.post('repayment_schedule/detail/', form_repayment_details).subscribe(
      async success => {
        await this.apiService
        .get('repayment_schedule/' + this.id)
        .subscribe(async (data: any) => {
          this.repayment_schedule_details = data.repayment_schedule_details;
          this.repayment_schedule_penalty = data.repayment_schedule_penalty;

           /** Calculate Repayment Schedule Details Payment Amount*/
           const sum = this.repayment_schedule_details;
           const outValue = [];
           for (let i = 0; i < sum.length; i++) {
             outValue.push(sum[i].payment_amount);
           }
           if (outValue.length === 0) {
              return;
           } else {
             const reducer = (accumulator, currentValue) => accumulator + currentValue;
             this.payment = outValue.reduce(reducer);
           }

          if (data.repayment_schedule_penalty){
            if (data.repayment_schedule_penalty.repayment_amount === data.repayment_penalty) { // kondisi belum dibayar ?

             if (data.repayment_schedule_penalty.repayment_amount === 0) {
               this.repaymentPenalty_value = form.repayment_penalty;
             } else {
               this.repaymentPenalty_value = data.repayment_schedule_penalty.repayment_amount;
               this.repayment_penalty      = data.repayment_schedule_penalty.repayment_amount;
             }

            } else {
              this.repaymentPenalty_value = data.repayment_schedule_penalty.repayment_amount;
            }
          }

          const payment_status = this.checkPaymentStatus(this.payment, this.payment_amount);
          const penalty_status = this.checkPenaltyStatus(data.repayment_schedule_penalty);
          const join_status = payment_status.toString()+ penalty_status.toString();

          let installment_status;

          switch (join_status) {
            case '00' :
              installment_status = 'UNPAID';
              break;
            case '20' :
              installment_status = 'PAID';
              break;
            case '10' :
              installment_status = 'PARTIAL';
              break;
            case '01' :
              installment_status = 'UNPAID';
              break;
            case '21' :
              installment_status = 'PARTIAL';
              break;
            case '11' :
              installment_status = 'PARTIAL';
              break;
            case '02' :
              installment_status = 'PARTIAL';
              break;
            case '22' :
              installment_status = 'PAID';
              break;
            case '12' :
              installment_status = 'PARTIAL';
              break;
            default:
              installment_status = 'UNPAID';
              break;
          }
          const form_put_repayment_schedule = {
            submission_repayment: { id: this.submission_id },
            submission_number: this.submission_number,
            company_id: this.company_id,
            company_name: this.company_name,
            dealer_id: this.dealer_id,
            dealer_name: this.dealer_name,
            customer_personal_id: this.customer_personal_id,
            customer_company_id: this.customer_company_id,
            customer_name: this.customer_name,
            leasing_type: this.leasing_type,
            interest: this.interest,
            down_payment: this.down_payment,
            period: this.period,
            payment_number: this.payment_number,
            payment_date: this.payment_date,
            interest_paid: this.interest_paid,
            principal_paid: this.principal_paid,
            payment_amount: this.payment_amount,
            balance: this.balance_original,
            /** UPDATE */
            repayment_date: NewInstallmentDate,
            repayment_amount: this.payment,
            // repayment_status: this.repayment_status,
            repayment_status: installment_status,
            repayment_penalty: this.repaymentPenalty_value
          };

          await this.apiService.put('repayment_schedule/' + this.id_installment, form_put_repayment_schedule).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );
        });
        this.router.navigate(['transaction/installment']);
      },
      error => {
        console.log(error);
      }
    );

    console.log(form_repayment_details);



  }

  back() {
    this.location.back();
  }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = (value && [value]) || [];
    this._dateValue = value;
  }

  /**
  * Show popup dialog for choosing image
  */
  showDialog(event) {
    const eventClick = new MouseEvent('click', { bubbles: true });
    this.renderer.invokeElementMethod(this.file_attachment.nativeElement, 'dispatchEvent', [
      eventClick
    ]);
    return false;
  }
  showDialogPenlaty(event) {
    const eventClick = new MouseEvent('click', { bubbles: true });
    this.renderer.invokeElementMethod(this.file_attachment_penalty.nativeElement, 'dispatchEvent', [
      eventClick
    ]);
    return false;
  }
  /**
   * Preview uploaded image
   */
  preview(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        this.img_src = e.target.result;
        this.img_added = true;
      };
    }
  }

  previewPenlaty(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        this.img_src_penalty = e.target.result;
        // this.img_added = true;
      };
    }
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
