import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VendorInvoiceRoutingModule } from './vendor-invoice-routing.module';
import { VendorInvoiceComponent } from './vendor-invoice.component';
import { VendorInvoiceFormComponent } from './vendor-invoice-form.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxDateBoxModule,
  DxNumberBoxModule,
  DxBoxModule,
  DxFormModule,
  DxSelectBoxModule
} from 'devextreme-angular';

@NgModule({
  imports: [
    CommonModule,
    VendorInvoiceRoutingModule,
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxDateBoxModule,
    DxNumberBoxModule,
    DxBoxModule,
    DxFormModule,
    DxSelectBoxModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function (http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [VendorInvoiceFormComponent, VendorInvoiceComponent]
})
export class VendorInvoiceModule { }
