import { Component, OnInit, ViewChild } from '@angular/core';
import { DxDataGridComponent } from 'devextreme-angular';
import { Router } from '@angular/router';
import { ApiService, SampleService } from '../../../core';
import { fadeIn } from '../../../shared/animations';

@Component({
  selector: 'app-vendor-invoice',
  templateUrl: './vendor-invoice.component.html',
  styleUrls: ['./vendor-invoice.component.scss'],
  animations: [fadeIn()]
})
export class VendorInvoiceComponent implements OnInit {
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  dataGridSource: any = [];
  // dataSource: any = {};
  dataGridPageSize = 10;
  route = 'transaction/vendor-invoice';

  constructor(
    private router: Router,
    private apiService: ApiService,
    private sampleService: SampleService
    ) { }

  ngOnInit() {

    this.sampleService.getVendorInvoiceSample().subscribe(
      data => {
        console.log(data);
        this.dataGridSource = data;
      },
      error => {
        console.log(error);
      }
    );
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {
    this.router.navigate([this.route, 'create']);
  }

  actionEdit(id) {
    console.log(id);
  }

  actionPdf() { }

  actionExcel() { }

  actionDelete(row) {
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }

}
