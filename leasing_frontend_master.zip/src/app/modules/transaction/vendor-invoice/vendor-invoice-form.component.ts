import { Component, OnInit, Inject } from '@angular/core';
import { fadeIn } from '../../../shared/animations';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent,
  DxFormModule,
  DxSelectBoxModule
} from 'devextreme-angular';
import { LocalStorageService } from 'ngx-webstorage';
import { ApiService } from '../../../core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-vendor-invoice-form',
  templateUrl: './vendor-invoice-form.component.html',
  styleUrls: ['./vendor-invoice-form.component.scss'],
  animations: [fadeIn()]
})
export class VendorInvoiceFormComponent implements OnInit {
  vendors: any;
  dataSource: any[];
  form: FormGroup;
  now: Date = new Date();
  maxDate: Date = new Date();

  constructor(
    private router: Router,
    private apiService: ApiService,
    private location: Location,
    private localStorageService: LocalStorageService
  ) { }

  ngOnInit() {
    this.form = new FormGroup(
      {
        vendor_id: new FormGroup({
          id: new FormControl('', {
            validators: [Validators.required]
          })
        })
      });

    const company_active = this.localStorageService.retrieve('user_company_active');
    this.apiService
      .get('vendor?sort=vendorName,asc&company_id=' + company_active)
      .subscribe((data: any) => {
        const content = [];
        for (let i = 0; i < data.content.length; i++) {
          content.push({ id: data.content[i].id, name: data.content[i].vendor_name });
        }
        this.vendors = content;
      });
  }

  save(event) {
    console.log(this.dataSource);
    return false;
  }

  back() {
    this.location.back();
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }
}
