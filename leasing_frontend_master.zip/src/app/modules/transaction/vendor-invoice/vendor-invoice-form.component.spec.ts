import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorInvoiceFormComponent } from './vendor-invoice-form.component';

describe('VendorInvoiceFormComponent', () => {
  let component: VendorInvoiceFormComponent;
  let fixture: ComponentFixture<VendorInvoiceFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VendorInvoiceFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorInvoiceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
