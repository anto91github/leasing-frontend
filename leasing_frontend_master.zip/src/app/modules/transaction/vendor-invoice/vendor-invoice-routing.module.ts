import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VendorInvoiceComponent } from './vendor-invoice.component';
import { VendorInvoiceFormComponent } from './vendor-invoice-form.component';

const routes: Routes = [
  {
    path: '',
    component: VendorInvoiceComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: VendorInvoiceFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VendorInvoiceRoutingModule { }
