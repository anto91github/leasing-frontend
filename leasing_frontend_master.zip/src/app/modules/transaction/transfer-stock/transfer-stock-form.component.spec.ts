import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferStockFormComponent } from './transfer-stock-form.component';

describe('TransferStockFormComponent', () => {
  let component: TransferStockFormComponent;
  let fixture: ComponentFixture<TransferStockFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferStockFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferStockFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
