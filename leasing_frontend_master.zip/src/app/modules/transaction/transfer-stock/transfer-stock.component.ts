import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { fadeIn } from '../../../shared/animations';
import { DxDataGridComponent } from 'devextreme-angular';
import { Router } from '@angular/router';
import { ApiService, ConfigService } from './../../../core';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { DatePipe, formatCurrency } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import CustomStore from 'devextreme/data/custom_store';
import { Location } from '@angular/common';
import { LocalStorageService } from 'ngx-webstorage';
import { DomSanitizer } from '@angular/platform-browser';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { Master } from '../../../core/models';
import { map, mergeMap, concatMap, delay, concat } from 'rxjs/operators';


@Component({
  selector: 'app-transfer-stock',
  templateUrl: './transfer-stock.component.html',
  styleUrls: ['./transfer-stock.component.scss'],
  animations: [fadeIn()]
})
export class TransferStockComponent implements OnInit {
  title: any;
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;

  dataSource: any = {};
  vendor_address: any;
  po_collection_data: any = [];
  dataGridPageSize = 10;
  route = 'transaction/transfer-stock';

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private router: Router,
    private apiService: ApiService,
    private location: Location,
    private localSt: LocalStorageService,
    private config: ConfigService,
    private translateService: TranslateService,
    private datePipe: DatePipe,
    private httpclient: HttpClient
  ) {
    this.title = this.translateService.instant('app.transfer-stock');
    this.dataSource.store = new CustomStore({
      load: function (options: any) {
        options.userData.company_id = true;
        return apiServiceInject.getMaster('transfer_stock', options);
      },
      remove: function (row) {
        return apiServiceInject
          .delete('transfer_stock/' + row.id)
          .toPromise()
          .then(
            () => document.getElementById('btn-refresh').click(),
            error => Promise.reject(error.error.message)
          );
      }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
  }

  ngOnInit() {
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {
    this.router.navigate([this.route, 'create']);
  }

  actionEdit(id) {
    console.log(id);
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete(row) {
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }

  actionPdf() {
    // alert('PRINT TRANSFER STOCK - PDF');
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.transfer_stock')
      );
      return false;
    }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.transfer_number'), dataKey: 'transfer_number' },
      { title: this.translateService.instant('app.from'), dataKey: 'from_dealer_name' },
      { title: this.translateService.instant('app.destination'), dataKey: 'dest_dealer_name' },
      { title: this.translateService.instant('app.transfer_note'), dataKey: 'transfer_note' }
    ];
    const rows = [];
    this.apiService.get('transfer_stock').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            transfer_number: items[i].transfer_number,
            from_dealer_name: items[i].from_dealer_name,
            dest_dealer_name: items[i].dest_dealer_name,
            transfer_note: items[i].transfer_note
          });
          console.log(items);
        }

    // Only pt supported (not mm or in)
    const doc = new jsPDF('p', 'pt');
    doc.autoTable(columns, rows, {
      theme: 'striped',
      margin: { top: 60 },
      addPageContent: function(data) {
        doc.text('Transfer Stock', 40, 30);
      },
      bodyStyles: { valign: 'top' },
      styles: { overflow: 'linebreak', fontSize: 7 },
      columnStyles: { text: { columnWidth: 'auto' } }
    });
    window.open(doc.output('bloburl'));
  },
  error => {
    console.log(error);
  }
);
}

  actionExcel() {
    // alert('PRINT TRANSFER STOCK - EXCEL');
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.transfer_stock')
      );
      return false;
    }
    this.apiService.get('transfer_stock').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.transfer_number')]: el.transfer_number,
            [this.translateService.instant('app.from')]: el.from_dealer_name,
            [this.translateService.instant('app.destination')]: el.dest_dealer_name,
            [this.translateService.instant('app.transfer_note')]: el.transfer_note
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }


  async actionPrintRowData(value) {
    // alert('PRINT TRANSFER STOCK - One Data');
    const data_ts = await this.apiService.get('transfer_stock/' + value).toPromise();
    console.log(data_ts);
    const fromTo_id = data_ts['from_dealer_id'];
    const destTo_id = data_ts['dest_dealer_id'];

    const data_from_dealer =  await this.apiService.get('dealer/' + fromTo_id).toPromise();
    const data_destination_dealer = await this.apiService.get('dealer/' + destTo_id).toPromise();

    const doc = new jsPDF('p', 'pt');
    // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: 'SKU', dataKey: 'sku_id' },
      { title: this.translateService.instant('app.product'), dataKey: 'product_name' },
      { title: this.translateService.instant('app.vin'), dataKey: 'vin' },
      { title: this.translateService.instant('app.engine_number'), dataKey: 'engine_number' },
      { title: this.translateService.instant('app.color'), dataKey: 'color' },
      { title: this.translateService.instant('app.manufacture_year'), dataKey: 'manufacture_year' },
    ];

    const rows = [];
    for (let i = 0; i < data_ts['transfer_stock_details']['length']; i++) {
      rows.push({
        no: `${i + 1}.`,
        sku_id : data_ts['transfer_stock_details'][i].sku_id,
        product_name: data_ts['transfer_stock_details'][i].product_name,
        vin: data_ts['transfer_stock_details'][i].vin,
        engine_number: data_ts['transfer_stock_details'][i].engine_number,
        color: data_ts['transfer_stock_details'][i].color,
        manufacture_year: data_ts['transfer_stock_details'][i].manufacture_year
      });
    }
    const rows_head = [];

    const col_empty = ['', ''];
    const row_empty = [];
    const columns_head = ['', '', '', ''];

      // draw PDF
      rows_head.push({
        0: 'Transfer Number: ' +  data_ts['transfer_number']
      });
      rows_head.push({
        0: 'Status : ' + data_ts['transfer_status']
      });
      rows_head.push({
        0: 'Transfer Note: ' + data_ts['transfer_note']
      });

      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('TRANSFER STOCK DETAILS', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

      // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // from
      const splitFromAddress = doc.splitTextToSize(data_from_dealer['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('From :', 230, 125);
          doc.setFontType('normal');
          doc.text(data_from_dealer['dealer_name'], 230, 135);
          doc.text(splitFromAddress, 230, 145);
          doc.text('Phone: ' + data_from_dealer['phone'], 230, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // destination
      const splitDestinationAddress = doc.splitTextToSize(data_destination_dealer['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Destination :', 400, 125);
          doc.setFontType('normal');
          doc.text(data_destination_dealer['dealer_name'], 400, 135);
          doc.text(splitDestinationAddress, 400, 145);
          doc.text('Phone: ' + data_destination_dealer['phone'], 400, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });
      window.open(doc.output('bloburl'));
  }
}
