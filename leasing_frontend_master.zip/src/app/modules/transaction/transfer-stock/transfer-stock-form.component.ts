import { Component, OnInit, ChangeDetectionStrategy, ViewChild, Injectable, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { map, mergeMap, concatMap, delay } from 'rxjs/operators';
import { LocalStorageService } from 'ngx-webstorage';
import { Location } from '@angular/common';
import { Observable, concat } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { fadeIn } from '../../../shared/animations';
import { ApiService, Master, Product } from '../../../core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  DxDataGridComponent,
  DxRadioGroupComponent,
  DxDropDownBoxComponent
 } from 'devextreme-angular';
import { TranslateService } from '@ngx-translate/core';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-transfer-stock-form',
  templateUrl: './transfer-stock-form.component.html',
  styleUrls: ['./transfer-stock-form.component.scss'],
  animations: [fadeIn()]
})
export class TransferStockFormComponent implements OnInit {
  [x: string]: any;
  form: FormGroup;
  items: FormArray;
  detailFrom = false;
  details_destination = false;
  dataGridSource: any = {};
  @ViewChild(DxDataGridComponent)
  @ViewChild(DxRadioGroupComponent) radio_status: DxRadioGroupComponent;
  @ViewChildren(DxDropDownBoxComponent) dropdownBox: QueryList<DxDropDownBoxComponent>;
  dataGrid: DxDataGridComponent;
  _productSelectedRowKeys: number[];

  constructor(
    private apiService: ApiService,
    private localStorageService: LocalStorageService,
    private formBuilder: FormBuilder,
    private location: Location,
    private router: Router,
    private route: ActivatedRoute,
    private translate: TranslateService,
    private flashMessage: FlashMessagesService,
  ) { }

  ngOnInit() {
    this.loadStatus();
    this.loadDealer();

    this.form = this.formBuilder.group({
      // date: new FormControl('', {
      //   // validators: Validators.required
      // }),
      from: new FormControl('', {
        validators: Validators.required
      }),
      from_id: new FormControl('', {}),
      destination: new FormControl('', {
        validators: Validators.required
      }),
      destination_id: new FormControl('', {}),
      transfer_status: new FormControl('', {
        validators: Validators.required
      }),
      transfer_note: new FormControl('', {}),
      items: this.formBuilder.array([]),
      items_2: this.formBuilder.array([])
    },
      { updateOn: 'blur' });
  }

  private loadDealer(): any {
    this.apiService
      .get('dealer')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              dealer_name: el.dealer_name,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.dealer = [...items];
      });
  }

  changeFrom(event) {
    if (event.id === this.id_destination) {
      this.form.get('from').patchValue('');
      this.dealer_id  = '';
      this.detailFrom = false;

      const control = <FormArray>this.form.controls['items'];
      const item_delete = control.value;

      for (let i = 0; i < item_delete.length; i++) {
        control.removeAt(i);
        control.removeAt(0);
      }

      const title = this.translate.instant('app.from');
      this.flashMessage.show('The ' + title + ' cannot be the same as the destination dealer', {
        cssClass: 'alert-danger',
        showCloseBtn: true
      });
      this.loadProducts();
      return false;
    }
    if (event) {
      this.detailFrom = true;
      this.dealer_id = event.id;
      this.from_dealer_name = event.dealer_name;
      this.from_address = event.address;
      this.from_phone = event.phone;
      this.from_fax = event.fax;
      this.from_email = event.email;
      this.from_web = event.web;
      this.form.get('from_id').patchValue(event.id);
      this.loadProducts();
    } else {
      this.detailFrom = false;
    }
  }

  changeDesnination(event) {
    if (event.id === this.dealer_id) {
      this.form.get('destination').patchValue('');
      this.details_destination = false;
        const title = this.translate.instant('app.destination');
        this.flashMessage.show('The ' + title +  ' cannot be the same as the shipping dealer', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        return false;
    }
    if (event.id) {
      this.details_destination = true;
      this.id_destination = event.id;
      this.desnination_dealer_name = event.dealer_name;
      this.desnination_address = event.address;
      this.desnination_phone = event.phone;
      this.desnination_fax = event.fax;
      this.desnination_email = event.email;
      this.desnination_web = event.web;
      this.form.get('destination_id').patchValue(event.id);
    } else {
      this.details_destination = false;
    }
  }

  private loadProducts() {
    this.apiService
      .get('product_stock/per_dealer?dealer_id=' + this.dealer_id + '&sales_status=AVAILABLE')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(product => {
          items.push({
            id: product.id,
            master_product_id: product.master_product_id,
            title: product.product_brand + ' - ' + product.product_name + ' - ' + product.vin,
            engine_number: product.engine_number,
            manufacture_year: product.manufacture_year,
            sales_status: product.sales_status,
            picture: product.master_product_picture,
            vin: product.vin,
            color: product.color,
            storage_location_name: product.storage_location_name,
            storage_location_id: product.storage_location_id
          });
        });
        this.products = [...items];

        const control = <FormArray>this.form.controls['items'];
        const item_delete = control.value;
        item_delete.forEach(element => {
          if (element.product !== '') {
            const id_need_remove = element.sku_id;
            const index = this.products.findIndex(x => x.id === id_need_remove);
            this.products.splice(index, 1); // remove element if already selected
          }
        });
      });
  }

  deleteItem(i: number): void {
    const control   = <FormArray>this.form.controls['items'];
    const control_2 = <FormArray>this.form.controls['items_2'];

    this.loadProducts();
    control.removeAt(i);
    control_2.removeAt(i);
  }

  private loadStatus() {
    const status = [
      { id: 'DELIVERED', name: 'Delivered' },
      { id: 'REJECT', name: 'Reject' },
      { id: 'REQUEST', name: 'Request' }
    ];
    this.transferStatus = [...status];
  }

  get Detailproduct() {
    return this.form.get('items') as FormArray;
  }
  get formItems(): FormGroup {
    return this.form.get('items') as FormGroup;
  }

  private createItem(): FormGroup {
    return this.formBuilder.group({
      sku_id: '',
      product_id: '',
      product_name: '',
      vin: '',
      engine_number: '',
      manufacture_year: '',
      color: ''
    });
  }

  private createItem_2(): FormGroup {
    return this.formBuilder.group({
      product: '',
      product_id: '',
      storage_location_id: '',
      storage_location_name: '',
      color: '',
      manufacture_year: '',
      vin: '',
      engine_number: '',
      sales_status: ''
    });
  }

  addItem($event): void {
    this.items = this.form.get('items') as FormArray;
    this.items.push(this.createItem());
    this.items_2 = this.form.get('items_2') as FormArray;
    this.items_2.push(this.createItem_2());
  }

  changeProduct(event, i: number) {
    const control = <FormArray>this.form.controls['items'];
    const control_2 = <FormArray>this.form.controls['items_2'];

    control.at(i).patchValue({
      sku_id: event.id,
      product_id: event.master_product_id,
      product_name: event.title,
      color: event.color,
      manufacture_year: event.manufacture_year,
      vin: event.vin,
      engine_number: event.engine_number
    });

    control_2.at(i).patchValue({
      product: event.id,
      product_id: event.master_product_id,
      storage_location_id: event.storage_location_id,
      storage_location_name: event.storage_location_name,
      color: event.color,
      manufacture_year: event.manufacture_year,
      vin: event.vin,
      engine_number: event.engine_number,
      sales_status: event.sales_status
    });
    this.loadProducts();
    // console.log('Current item ', control.value[i]);
    // console.log('Current item ', control_2.value[i]);
  }

  async save() {
    const value_form = this.form.value;
    const company_active = this.localStorageService.retrieve('user_company_active');
    if (this.form.valid) {
      if (!this.id) {
        const form_transfer_stock = {
          company_id: company_active,
          from_dealer_id: value_form.from_id,
          from_dealer_name: value_form.from,
          dest_dealer_id: value_form.destination_id,
          dest_dealer_name: value_form.destination,
          transfer_note: value_form.transfer_note,
          transfer_status: value_form.transfer_status,
          transfer_stock_details: value_form.items
        };
        await this.apiService.post('transfer_stock/', form_transfer_stock).subscribe(
          async success => {
            value_form.items_2.forEach(async value => {
              const datas = {
                product: { id: value.product_id },
                storage_location_id: value_form.destination_id,
                storage_location_name: value_form.destination,
                color: value.color,
                manufacture_year: value.manufacture_year,
                vin: value.vin,
                engine_number: value.engine_number,
                sales_status: value.sales_status
              };

              this.apiService.put('product_stock/' + value.product, datas).subscribe(
              success_product_stock => {
                console.log(success_product_stock);
              },
              error_product_stock => {
                console.log(error_product_stock);
              }
            );
            });
            console.log(success);
          },
          error => {
            console.log(error);
          }
        );
        this.router.navigate(['transaction/transfer-stock']);
      } else {
        /** PUT */
        console.log('Nothing');
      }
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  back(): void {
    this.location.back();
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
