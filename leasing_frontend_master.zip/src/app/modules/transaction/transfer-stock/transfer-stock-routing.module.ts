import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransferStockComponent } from './transfer-stock.component';
import { TransferStockFormComponent } from './transfer-stock-form.component';


const routes: Routes = [
  {
    path: '',
    component: TransferStockComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: TransferStockFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: TransferStockFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TransferStockRoutingModule { }
