import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SubmissionComponent } from './submission.component';
import { SubmissionFormComponent } from './submission-form.component';
import { SubmissionDetailsComponent } from './submission-details.component';

const routes: Routes = [
  {
    path: '',
    component: SubmissionComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: SubmissionFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: SubmissionFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  },
  {
    path: ':id',
    component: SubmissionDetailsComponent,
    data: {
      breadcrumb: 'sys.details'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SubmissionRoutingModule { }
