import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { DxDataGridComponent, DxNumberBoxModule } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import notify from 'devextreme/ui/notify';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';

import { ApiService, SampleService } from './../../../core/services';
import { fadeIn } from '../../../shared/animations';
import { ConfigService } from '../../../core/services';
import { Master, Submission } from '../../../core/models';
import { LocalStorageService } from 'ngx-webstorage';
import { async } from '@angular/core/testing';
import { DatePipe, formatCurrency } from '@angular/common';

@Component({
  selector: 'app-submission',
  templateUrl: './submission.component.html',
  providers: [ApiService, TranslateService],
  animations: [fadeIn()]
})
export class SubmissionComponent implements OnInit {
  title: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  route = 'transaction/submissions/';
  dataGridSource: Submission[];
  dataSource: any = {};

  page_view_permission: string;
  page_create_permission: string;
  page_edit_permission: string;
  page_delete_permission: string;
  page_print_permission: string;
  page_export_permission: string;

  user_permission_collection: any = {};
  allow_view: boolean;
  allow_create: boolean;
  allow_edit: boolean;
  allow_delete: boolean;
  allow_print: boolean;
  allow_export: boolean;
  row: any;

  constructor(
    @Inject(ApiService) apiServices: ApiService,
    private location: Location,
    private apiService: ApiService,
    private sampleService: SampleService,
    private translateService: TranslateService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private config: ConfigService,
    private localSt: LocalStorageService,
    private datePipe: DatePipe,
  ) {
    this.title = this.translateService.instant('app.submission');
    // this.dataGridSource = this.sampleService.getSubmission();

    this.dataSource.store = new CustomStore({
      load: function (options: any) {
        options.userData.company_id = true;
        console.log(apiServices.getMaster('submission', options));
        return apiServices.getMaster('submission', options);
      }
      // ,
      // remove: function (row) {
      //   return apiServiceInject
      //     .delete('goods_receipt/' + row.id)
      //     .toPromise()
      //     .then(
      //       () => document.getElementById('btn-refresh').click(),
      //       error => Promise.reject(error.error.message)
      //     );
      // }
    });

    this.allow_view = false;
    this.allow_create = false;
    this.allow_edit = false;
    this.allow_delete = false;
    this.allow_print = false;
    this.allow_export = false;
    this.page_view_permission = 'transaction.submissions.view';
    this.page_create_permission = 'transaction.submissions.create';
    this.page_edit_permission = 'transaction.submissions.edit';
    this.page_delete_permission = 'transaction.submissions.delete';
    this.page_print_permission = 'transaction.submissions.print';
    this.page_export_permission = 'transaction.submissions.export';

    this.user_permission_collection = this.localSt.retrieve('user_roles');

    for (const check of this.user_permission_collection[0].access_collection) {
      if (check.permission === this.page_view_permission) {
        this.allow_view = true;
      }
      if (check.permission === this.page_create_permission) {
        this.allow_create = true;
      }
      if (check.permission === this.page_edit_permission) {
        this.allow_edit = true;
      }
      if (check.permission === this.page_delete_permission) {
        this.allow_delete = true;
      }
      if (check.permission === this.page_print_permission) {
        this.allow_print = true;
      }
      if (check.permission === this.page_export_permission) {
        this.allow_export = true;
      }
    }
    if (this.allow_view === false) {
      alert(
        this.translateService.instant('alert.no_view') +
          this.translateService.instant('app.submission')
      );
      this.location.back();
    }
  }

  ngOnInit() {
  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {
    if (this.allow_create === false) {
      alert(
        this.translateService.instant('alert.no_create') +
          this.translateService.instant('app.submission')
      );
      return false;
    }
    this.router.navigate([this.route, 'create']);
  }

  actionDetails(id) {
    this.router.navigate([this.route, id]);
  }

  actionEdit(id) {
    if (this.allow_edit === false) {
      alert(
        this.translateService.instant('alert.no_edit') +
          this.translateService.instant('app.submission')
      );
      return false;
    }
    this.router.navigate([this.route, id, 'edit']);
  }

  actionDelete(row) {
    if (this.allow_delete === false) {
      alert(
        this.translateService.instant('alert.no_delete') +
          this.translateService.instant('app.submission')
      );
      return false;
    }
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }

  async actionPrintDetail(value) {
    const data_product = await this.apiService.get('submission/' + value).toPromise();
    // console.log(data_product);
    const doc = new jsPDF('p', 'pt');
    // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: 'Product', dataKey: 'product_name' },
      { title: 'Basic Price', dataKey: 'basic_price' },
      { title: 'Sell Price', dataKey: 'sell_price' },
      { title: 'Qty', dataKey: 'qty' },
      { title: 'Total Price', dataKey: 'total_price' }
    ];

    const rows = [];
    for (let i = 0; i < data_product['submission_details']['length']; i++) {
      rows.push({
        no: `${i + 1}.`,
        product_name: data_product['submission_details'][i].product_name,
        basic_price: data_product['submission_details'][i].basic_price,
        sell_price : data_product['submission_details'][i].sell_price,
        qty: data_product['submission_details'][i].qty,
        total_price: data_product['submission_details'][i].total_price
      });
    }
    const rows_head = [];

    const col_empty = ['', ''];
    const row_empty = [];
    const columns_head = ['', '', '', ''];


    const col_amount = ['', '', ''];
    const row_amount = [
        [
          'Total Amount',
          ':',
          this.formatNumber(data_product['total_price'])
        ],
      ];

      // draw header
      rows_head.push({
        0: 'Submission Number: ' +  data_product['submission_number']
      });
      rows_head.push({
        0: 'Date: ' +  data_product['submission_date']
      });
      rows_head.push({
        0: 'Dealer  : ' + data_product['dealer_name']
      });
      rows_head.push({
        0: 'Down Payment  : ' + data_product['down_payment']
      });
      rows_head.push({
        // 0: 'Customer Type  : ' + data_product['customer_type']
      });
      rows_head.push({
        0: 'Leasing Note  : ' + data_product['leasing_note']
      });
      rows_head.push({
        0: 'Period  : ' + data_product['period']
      });
      rows_head.push({
        0: 'Interest  : ' + data_product['interest']
      });
      rows_head.push({
        0: 'Submission Status  : ' + data_product['submission_status']
      });

      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('SUBMISSION DETAIL', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

      // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });
      this.apiService.get('submission/' + value).subscribe(
        (response: any) => {
        // to get y position of last autotable
        const finalY = doc.autoTable.previous.finalY + 15;

       // total amount
       doc.autoTable(col_amount, row_amount, {
        addPageContent: function (data) {
        },
        theme: 'plain',
        margin: { top: finalY, left: 393 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 80 },
          1: { columnWidth: 10 },
          2: { columnWidth: 70 }
        }
      });
      window.open(doc.output('bloburl'));
});
}


  actionExcel() {
    if (this.allow_export === false) {
      alert(
        this.translateService.instant('alert.no_export') +
          this.translateService.instant('app.submission')
      );
      return false;
    }
    this.apiService.get('submission').subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            [this.translateService.instant('app.submission_number')]: el.submission_number,
            [this.translateService.instant('sys.date')]: el.submission_date,
            [this.translateService.instant('app.fullname')]: el.customer_name,
            [this.translateService.instant('app.period')]: el.period,
            [this.translateService.instant('app.down_payment')]: el.down_payment,
            [this.translateService.instant('app.interest')]: el.interest,
            [this.translateService.instant('app.submission_status')]: el.submission_status,
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionPdf() {
    if (this.allow_print === false) {
      alert(
        this.translateService.instant('alert.no_print') +
          this.translateService.instant('app.submission')
      );
      return false;
    }
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.submission_number'), dataKey: 'submission_number' },
      { title: this.translateService.instant('sys.date'), dataKey: 'submission_date' },
      { title: this.translateService.instant('app.fullname'), dataKey: 'customer_name' },
      { title: this.translateService.instant('app.period'), dataKey: 'period' },
      { title: this.translateService.instant('app.down_payment'), dataKey: 'down_payment' },
      { title: this.translateService.instant('app.interest'), dataKey: 'interest' },
      { title: this.translateService.instant('app.submission_status'), dataKey: 'submission_status' },
    ];
    const rows = [];

    this.apiService.get('submission').subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            submission_number: items[i].submission_number,
            submission_date: items[i].submission_date,
            customer_name: items[i].customer_name,
            period: items[i].period,
            down_payment: items[i].down_payment,
            interest: items[i].interest,
            submission_status: items[i].submission_status
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('p', 'pt');
        doc.autoTable(columns, rows, {
          addPageContent: function(data) {
            doc.text('Submission', 40, 40);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }

  async generateRepayment(value) {
    const submission_data = await this.apiService.get('submission/' + value).toPromise();
    const today = new Date();
    // const simulation_date = this.datePipe.transform(today, 'yyyy-MM-dd');
    const simulation_date = submission_data['submission_date'];
    const simulation_options = {
      start_date: simulation_date,
      loan_amount: submission_data['total_price'],
      down_payment: submission_data['down_payment'],
      interest_rate: submission_data['interest'],
      loan_term_in_month: submission_data['period'],
      loan_type: 1,
      company_id: submission_data['company_id']
  };
    const payment_schedule_api = await this.apiService.post('loan/simulation/', simulation_options).toPromise();

    for (const key in payment_schedule_api.body) {
      if (!payment_schedule_api.body.hasOwnProperty(key)) { continue; }
        const data_repayment = payment_schedule_api.body[key];

        const submission_id = {
          id: value
        };
        const param = {
          submission_repayment: submission_id,
          submission_number: submission_data['submission_number'],
          company_id: submission_data['company_id'],
          company_name: submission_data['company_name'],
          dealer_id: submission_data['dealer_id'],
          dealer_name: submission_data['dealer_name'],
          customer_personal_id: submission_data['customer_personal_id'],
          customer_company_id: submission_data['customer_company_id'],
          customer_name: submission_data['customer_name'],
          leasing_type: 'FLAT',
          interest: submission_data['interest'],
          down_payment: submission_data['down_payment'],
          period: submission_data['period'],
          payment_number: data_repayment['payment_number'],
          payment_date: this.datePipe.transform(data_repayment['payment_date'], 'yyyy-MM-dd'),
          interest_paid: data_repayment['interest_paid'],
          principal_paid: data_repayment['principal_paid'],
          payment_amount: data_repayment['payment_amount'],
          balance: data_repayment['balance'],
          // repayment_date: 'a',
          // repayment_amount: 'a',
          repayment_status: 'UNPAID'
        };

        // this.apiService.post('repayment_schedule/', param).subscribe(
        //   success => {
        //     console.log(success);
        //   },
        //   error => {
        //     console.log(error);
        // });
        await this.apiService.post('repayment_schedule/', param).toPromise();
        const myDate  = new Date(submission_data['submission_date']);
        const submission_date = myDate.toISOString();
        // edit has_schedule in submission table

        const submisison_edit_data = {
          company_id: submission_data['company_id'],
          submission_number: submission_data['submission_number'],
          // submission_date: submission_date,
          submission_date: submission_data['submission_date'],
          company_name: submission_data['company_name'],
          customer_personal_id: submission_data['customer_personal_id'],
          customer_company_id: submission_data['customer_company_id'],
          dealer_id: submission_data['dealer_id'],
          dealer_name: submission_data['dealer_name'],
          leasing_note: submission_data['leasing_note'],
          total_price: submission_data['total_price'],
          customer_name: submission_data['customer_name'],
          leasing_type: submission_data['leasing_type'],
          has_schedule: 'TRUE',
          interest: submission_data['interest'],
          down_payment: submission_data['down_payment'],
          period: submission_data['period'],
          submission_status: submission_data['submission_status']
        };
        await this.apiService.put('submission/' + value, submisison_edit_data).toPromise();
    }
    alert('Success Generate Repayment Schedule');
    this.dataGrid.instance.refresh();
    // this.router.navigate(['transaction/submissions']);
  }
}
