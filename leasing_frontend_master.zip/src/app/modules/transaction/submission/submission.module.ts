import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxDateBoxModule,
  DxNumberBoxModule,
  DxBoxModule,
  DxTextBoxModule,
  DxPopupModule,
  DxTemplateModule
} from 'devextreme-angular';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SubmissionRoutingModule } from './submission-routing.module';
import { SubmissionFormComponent } from './submission-form.component';
import { SubmissionComponent } from './submission.component';
import { SubmissionDetailsComponent } from './submission-details.component';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask/src/currency-mask.config';
import { NgSelectModule } from '@ng-select/ng-select';

/** Setting Currency Monney */
export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: 'left',
  allowNegative: true,
  decimal: ',',
  precision: 0,
  prefix: '',
  suffix: '',
  thousands: '.'
};
@NgModule({
  imports: [
    CommonModule,
    NgSelectModule,
    SharedModule,
    SubmissionRoutingModule,
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxDateBoxModule,
    DxPopupModule,
    DxButtonModule,
    DxTemplateModule,
    FormsModule,
    ReactiveFormsModule,
    DxNumberBoxModule,
    DxBoxModule,
    DxTextBoxModule,
    NgbModule,
    CurrencyMaskModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [SubmissionComponent, SubmissionFormComponent, SubmissionDetailsComponent],
  providers: [
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ],
})
export class SubmissionModule {}
