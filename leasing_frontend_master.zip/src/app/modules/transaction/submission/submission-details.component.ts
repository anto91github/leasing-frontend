import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-submission-details',
  templateUrl: './submission-details.component.html',
  styles: []
})
export class SubmissionDetailsComponent implements OnInit {
  constructor(private location: Location) {}
  leasing: any;

  ngOnInit() {}

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }
}
