import { Component, OnInit, ViewChild, ViewChildren, Inject, QueryList } from '@angular/core';
import { Location } from '@angular/common';
import { Http, HttpModule } from '@angular/http';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent,
  DxPopupModule,
  DxTemplateModule
} from 'devextreme-angular';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import notify from 'devextreme/ui/notify';
import CustomStore from 'devextreme/data/custom_store';
import { Router, ActivatedRoute } from '@angular/router';
import { delay, concatMap, map } from 'rxjs/operators';

import { fadeIn } from '../../../shared/animations';
import { ApiService, ConfigService} from '../../../core/services';
import { Master } from '../../../core';
import { LocalStorageService } from 'ngx-webstorage';
import { DatePipe, formatCurrency } from '@angular/common';
import { DxDataGridComponent } from 'devextreme-angular';
import { TranslateService } from '@ngx-translate/core';

interface SimulationDetail {
  due_date: string;
  balance: number;
  principal_paid: number;
  interest_paid: number;
  monthly_payment: number;
}
@Component({
  selector: 'app-submission-form',
  templateUrl: './submission-form.component.html',
  animations: [fadeIn()],
  providers: [ApiService]
})

export class SubmissionFormComponent implements OnInit {
  @ViewChild(DxDataGridComponent)
  @ViewChild(DxRadioGroupComponent) radio_status: DxRadioGroupComponent;
  @ViewChildren(DxDropDownBoxComponent) dropdownBox: QueryList<DxDropDownBoxComponent>;
  dataGrid: DxDataGridComponent;
  [x: string]: any;
  row: any = [];
  now: Date = new Date();
  maxDate: Date = new Date();
  status = ['SUBMISSION', 'APPROVED', 'REJECTED'];
  cust_collection = ['Personal', 'Company'];
  id: number = null;
  is_edit = false;
  dataGridEdit: any = {};
  formProduct: FormGroup;
  customerDataSource: any;
  _customerValue: number;
  _customerSelectedRowKeys: number[];

  productDataSource: any;
  _productValue: number;
  _productSelectedRowKeys: number[];

  productDetailDataSource: any;
  _productDetailValue: number;
  _productDetailSelectedRowKeys: number[];

  productDetailSelectedID: any;
  stockCollection: any;
  productPrice: any;
  productPrice2: any;

  _submission_no: any;
  installment_detail = [];
  installment_details: SimulationDetail[] = [];

  global_product_price: any;
  company_id_from_edit: any;
  company_name_from_edit: any;
  sub_date_for_edit: any;

  master_product_id: number;

  _dateValue: any;
  submissionQty: number;
  subTotal: number;

  products = [];
  items: FormArray;

  dealerCollection = [];
  cust_type = 1;
  popupVisible = false;
  formulaVisible = false;

  popup_basic_price = 0;
  transport_fee = 0;
  doc_fee = 0;
  profit = 0;
  admin_fee = 0;
  dealer_fee = 0;
  dataGridPageSize = 10;

  customer_company_id_edit: any;
  customer_personal_id_edit: any;

  has_schedule_edit: any;

  constructor(
    private location: Location,
    private router: Router,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService,
    private formBuilder: FormBuilder,
    private apiService2: ApiService,
    private datePipe: DatePipe,
    @Inject(ApiService) apiService: ApiService,
    private config: ConfigService,
    private translateService: TranslateService
  ) {
    // this.customerDataSource = new CustomStore({
    //   loadMode: 'raw',
    //   key: 'id',
    //   load: function() {
    //     return apiService.getContent('customer/personal_data');
    //   }
    // });

    this.productDataSource = new CustomStore({
      loadMode: 'raw',
      key: 'id',
      load: function() {
        return apiService.getContent('product');
      }
    });
    this.dateValue = this.now;
  }

  ngOnInit() {
    // this.loadProducts();

    this.formProduct = this.formBuilder.group({
      submission_no: new FormControl('', {
      }),
      submission_interest: new FormControl('', {
      }),
      down_payment: new FormControl('', {
      }),
      submission_period: new FormControl('', {
      }),
      submission_status: new FormControl('', {
      }),
      customer_name: new FormControl('', {
      }),
      product_name: new FormControl('', {
      }),
      sub_date: new FormControl('', {
      }),
      sub_dp: new FormControl('', {
      }),
      sub_interest: new FormControl('', {
      }),
      sub_period: new FormControl('', {
      }),
      product_detail: new FormControl('', {
      }),
      dealer_id: new FormControl('', {
      }),
      dealer_name: new FormControl('', {
      }),
      security_code: new FormControl('', {
      }),
      cust_type_radio: new FormControl('', {
      }),
      cust_type: new FormControl('', {
      }),
      leasing_note: new FormControl('', {
      }),
      total_product_edit: new FormControl('', {
      }),
      items: this.formBuilder.array([])
    });
    this.loadDealer();
    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (params.product) {
        this._customerSelectedRowKeys = [parseInt(params.product, 10)];
        this._productValue = parseInt(params.product, 10);
      }
      if (params.customer) {
        this._customerSelectedRowKeys = [parseInt(params.customer, 10)];
        this._productValue = parseInt(params.customer, 10);
      }
      if (this.id) { // is edit
        this.is_edit = true;
        let cust_type;
        this.apiService2.get('submission/' + this.id).subscribe(data => {
          if (data['customer_company_id'] === 0) {
            cust_type = 'PERSONAL';
          } else {
            cust_type = 'COMPANY';
          }
          this.customer_personal_id_edit = data['customer_personal_id'];
          this.customer_company_id_edit = data['customer_company_id'];
          this.has_schedule_edit = data['has_schedule'];
          this.row = data;
          this.dataGridEdit = this.row.submission_details;
          console.log(this.dataGridEdit);

          this.dataGridPageSize = this.config.getConfig('paginationLength');

          this.formProduct.patchValue({
            submission_no : data['submission_number'],
            customer_name: data['customer_name'],
            cust_type_radio: cust_type,
            product_name: data['product_name'],
            dealer_id: data['dealer_id'],
            dealer_name: data['dealer_name'],
            sub_date: this.datePipe.transform(data['submission_date'], 'yyyy-MM-dd'),
            sub_dp : data['down_payment'],
            sub_interest: data['interest'],
            sub_period: data['period'],
            submission_status: data['submission_status'],
            leasing_note : data['leasing_note'],
            total_product_edit: data['total_price']
          });

          // this.apiService2.get('product_stock/' + data['sku_id']).subscribe(detail => {
          //   this.formProduct.patchValue({
          //     product_detail: detail['manufacture_year'] + ' - ' + detail['vin']
          //   });
          // });
          this.global_product_price = data['product_price'];
          this.customerValue = data['customer_id'];
          this.productValue = data['sku_id'];
          this.company_id_from_edit = data['company_id'];
          this.company_name_from_edit = data['company_name'];
          this.sub_date_for_edit = data['submission_date'];
          this.productPrice = data['product_price'];
          this.subTotal = data['product_price'];
        });
      }
    });
  }

  async loadDealer() {
    const dealer_api = await this.apiService2.get('dealer').toPromise();
    const dealer = [];
    this.dealerCollection = dealer_api['content'];
  }

  get customerValue(): number {
    return this._customerValue;
  }

  set customerValue(value: number) {
    this._customerSelectedRowKeys = (value && [value]) || [];
    this._customerValue = value;
  }

  get customerSelectedRowKeys(): number[] {
    return this._customerSelectedRowKeys;
  }

  set customerSelectedRowKeys(value: number[]) {
    this._customerValue = (value.length && value[0]) || null;
    this._customerSelectedRowKeys = value;
  }

  get productValue(): number {
    return this._productValue;
  }

  set productValue(value: number) {
    this._productSelectedRowKeys = (value && [value]) || [];
    this._productValue = value;
  }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = (value && [value]) || [];
    this._dateValue = value;
  }

  // get cust_type(): number {
  //   return this._cust_type;
  // }

  // set cust_type(value: number) {
  //   this._cust_type = value;
  // }

  get productSelectedRowKeys(): number[] {
    return this._productSelectedRowKeys;
  }

  set productSelectedRowKeys(value: number[]) {
    this._productValue = (value.length && value[0]) || null;
    this._productSelectedRowKeys = value;
  }

   /*Product Detail Dropdown Function*/
   get productDetailValue(): number {
    return this._productDetailValue;
  }

  set productDetailValue(value: number) {
    this._productDetailSelectedRowKeys = (value && [value]) || [];
    this._productDetailValue = value;
  }

  get productDetailSelectedRowKeys(): number[] {
    return this._productDetailSelectedRowKeys;
  }

  set productDetailSelectedRowKeys(value: number[]) {
    this._productDetailValue = (value.length && value[0]) || null;
    this._productDetailSelectedRowKeys = value;
  }

  customerFullname(item) {
    return item && item.first_name + ' ' + item.last_name;
  }

  companyFullname(item) {
    return item && item.company_name;
  }

  productLabel(item) {
    return item && item.brand + ' - ' + item.type;
  }

  productDetailLabel(item) {
    return item && item.manufacture_year + ' - ' + item.vin;
  }

  setPrice(event) {
    this.productDetailSelectedID = event.value;
    // this.apiService2.get('product/' + this.master_product_id).subscribe(
    //   success_price => {
    //     this.stockCollection = success_price['stock_collection'];
    //     this.productPrice = this.stockCollection.find(
    //       x => x.id === this.productDetailSelectedID
    //     ).price;
    //   },
    //   error => {
    //     console.log(error);
    //   }
    // );
    this.apiService2.get('product/' + this.productDetailSelectedID).subscribe(
      success_price => {
        this.productPrice = success_price['basic_price'];
        this.calculateFormula(0);
      }
    );
    this.dropdownBox.forEach(el => {
      el.instance.close();
    });
  }

  setSubTotal(event) {
    console.log(event.value);
    this.submissionQty = event.value;
    this.subTotal = this.submissionQty * this.productPrice2;
  }

  selectDealer(event) {
    this.transport_fee = event.price_formulas.transportation;
    this.doc_fee = event.price_formulas.documentation;
    this.profit = event.price_formulas.profit;
    this.dealer_fee = event.price_formulas.dealer_fee;
    this.admin_fee = event.price_formulas.admin_fee;
  }

  /**
   * Close dropdownbox after value selected
   */
  dropdownBoxCustomerChange(event) {
    this.dropdownBox.forEach(el => {
      el.instance.close();
    });
  }

  async setCustomerType(event) {
    this.customerValue = null;
    if (event.value === 'Personal') {
      const cust_data = await this.apiService2.get('customer/personal_data').toPromise();
      const cust_data_2 = cust_data['content'];
      this.cust_type = 1;

      this.customerDataSource = new CustomStore({
        loadMode: 'raw',
        key: 'id',
        load: function() {
          return cust_data_2;
        }
      });
    } else {
      const company_data = await this.apiService2.get('customer/company_data').toPromise();
      const company_data_2 = company_data['content'];
      this.cust_type = 2;

      this.customerDataSource = new CustomStore({
        loadMode: 'raw',
        key: 'id',
        load: function() {
          return company_data_2;
        }
      });

    }
  }

  dropdownBoxChange(event) {
    this.master_product_id = event.value;
    console.log(this.master_product_id);

    const hasil = this.apiService2.getStockCollection('product/' + this.master_product_id);

    this.productDetailDataSource = new CustomStore({
      loadMode: 'raw',
      key: 'id',
      load: function() {
        return hasil;
      }
    });

    this.dropdownBox.forEach(el => {
      el.instance.close();
    });
  }

  /**
   * Save new data submission
   */
  async save(event) {
    const company_id = this.localStorageService.retrieve('user_company_active');
    const company_name_active = this.localStorageService.retrieve('user_companies')[0].company_name;
    const submission_date = this.dateValue.toISOString();
    const today = new Date();
    const simulation_date = this.datePipe.transform(today, 'yyyy-MM-dd');
    let customerCompanyId = null;
    let customerPersonalId = null;

    const dealer_collection = await this.apiService2.get('dealer/' + this.formProduct.value.dealer_id).toPromise();
    const dealer_name = dealer_collection['dealer_name'];

    if (this.cust_type === 1) {
      customerPersonalId = this.customerValue;
      customerCompanyId = 0;
    } else {
      customerCompanyId = this.customerValue;
      customerPersonalId = 0;
    }

    if (!this.id) {
      let customer_name;

      if (this.cust_type === 1) {
        const customer_collection = await this.apiService2.get('customer/personal_data/' + this.customerValue).toPromise();
        customer_name = customer_collection['first_name'] + ' ' + customer_collection['last_name'];
      } else {
        const customer_company_collection = await this.apiService2.get('customer/company_data/' + this.customerValue).toPromise();
        customer_name = customer_company_collection['company_name'];
      }

    // const product_collection = await this.apiService2.get('product/' + this.productValue).toPromise();
    // const product_collection = await this.apiService2.get('product_stock/' + this.productDetailSelectedID).toPromise();
    // const product_name = product_collection['product_type'];

      const simulation_options = {
          start_date: simulation_date,
          // loan_amount: product_collection['price'],
          // loan_amount: product_collection['price'] * this.submissionQty,
          loan_amount: this.subTotal,
          down_payment: this.formProduct.value.down_payment,
          interest_rate: this.formProduct.value.submission_interest,
          loan_term_in_month: this.formProduct.value.submission_period,
          loan_type: 1,
          company_id: company_id
      };
        // const installment_collection = await this.apiService2.post('loan/simulation/', simulation_options).toPromise();
        const installment_value = [];
        // this.global_product_price = product_collection['price'];

        const product = this.formProduct.value.items;
        const submission_detail = [];

        product.forEach(data => {
          const sell_price = data.price + data.documentation_fee + data.profit + data.transport_fee +
                             (data.price * data.admin_fee / 100) + (data.price * data.dealer_fee / 100);
          const total_detail = sell_price * data.amount;
          const updatedataProductDetail = {
            admin_fee: data.admin_fee,
            basic_price: data.price,
            dealer_fee: data.dealer_fee,
            documentation_fee: data.documentation_fee,
            // id: data.product,
            product_id: data.product,
            product_name: data.name,
            profit: data.profit,
            qty: data.amount,
            transportation_fee: data.transport_fee,
            sell_price: sell_price,
            total_price: total_detail
          };
          submission_detail.push(updatedataProductDetail);
        });

        const form_value = {
          company_id: company_id,
          company_name: company_name_active,
          customer_company_id: customerCompanyId,
          customer_name: customer_name,
          customer_personal_id: customerPersonalId,
          dealer_id: this.formProduct.value.dealer_id,
          dealer_name: dealer_name,
          down_payment: this.formProduct.value.down_payment,
          interest: this.formProduct.value.submission_interest,
          leasing_note: this.formProduct.value.leasing_note,
          leasing_type: 'FLAT',
          has_schedule: 'FALSE',
          period: this.formProduct.value.submission_period,
          submission_date: submission_date,
          // submission_number: this.formProduct.value.submission_no,
          submission_status: this.formProduct.value.submission_status,
          total_price: this.sum_total,
          submission_details: submission_detail
        };

        // console.log(form_value);
        this.apiService2.post('submission/', form_value).subscribe(
          success => {
            console.log(success);
            this.router.navigate(['transaction/submissions']);
          },
          error => {
            console.log(error);
        });
    } else {
      const form_edit = {
        company_id: this.company_id_from_edit,
        // submission_number: this.formProduct.value.submission_no,
        submission_date: this.sub_date_for_edit,
        company_name: this.company_name_from_edit,
        // customer_personal_id: this.customerValue,
        customer_personal_id: this.customer_personal_id_edit,
        customer_company_id: this.customer_company_id_edit,
        dealer_id: this.formProduct.value.dealer_id,
        dealer_name: this.formProduct.value.dealer_name,
        leasing_note: this.formProduct.value.leasing_note,
        total_price: this.formProduct.value.total_product_edit,
        customer_name: this.formProduct.value.customer_name,
        sku_id: this.productValue,
        product_name: this.formProduct.value.product_name,
        product_price: this.global_product_price,
        leasing_type: 'FLAT',
        has_schedule: this.has_schedule_edit,
        interest: this.formProduct.value.sub_interest,
        down_payment: this.formProduct.value.sub_dp,
        period: this.formProduct.value.sub_period,
        submission_status: this.formProduct.value.submission_status,
      };
      console.log(form_edit);

      this.apiService2.put('submission/' + this.id, form_edit).subscribe(
        success => {
          console.log(success);
          this.router.navigate(['transaction/submissions']);
        },
        error => {
          console.log(error);
      });
    }

    event.preventDefault();
  }

  // showFormula(event, i: number) {
    showFormula(i) {
    this.popupVisible = true;
    this.selected_item_index = i;

    const control = <FormArray>this.formProduct.controls['items'];
    // control.at(i).patchValue({ total: control.value[i].price * control.value[i].amount });

    this.popup_basic_price = control.controls[i].value.price;
    this.calculateInPopup();
    // const formula_result = this.calculateFormula(i);

    // control.at(i).patchValue({ total: formula_result });
  }

  verifyCode() {
    // console.log(this.formProduct.value.security_code);
    if (this.formProduct.value.security_code === '123') {
      this.popupVisible = false;
      this.formulaVisible = true;
    } else {
      alert ('Wrong security code');
      // this.translateService.instant('alert.security_code');
    }
  }

  calculateFormula(flag) {
    const total = this.popup_basic_price + this.transport_fee + this.doc_fee + this.profit +
                  (this.popup_basic_price * this.dealer_fee / 100) + (this.popup_basic_price * this.admin_fee / 100);

    this.addedValue = this.total - this.sum_total;
    this.submissionQty = 0;
    this.subTotal = 0;
    this.formulaVisible = false;

    // const control = <FormArray>this.formProduct.controls['items'];
    // if (this.selected_item_index !== undefined) {
    //   control.at(this.selected_item_index).patchValue({ total: total });
    // }
    return total;
  }

  calculateFormula2() {
    const total = this.popup_basic_price + this.transport_fee + this.doc_fee + this.profit +
                  (this.popup_basic_price * this.dealer_fee / 100) + (this.popup_basic_price * this.admin_fee / 100);
    const control = <FormArray>this.formProduct.controls['items'];
    const qty = control.controls[this.selected_item_index].value.amount;
    const total_with_qty = total * qty;

    if (this.selected_item_index !== undefined) {
      control.at(this.selected_item_index).patchValue({
        total: total,
        total_with_qty: total_with_qty,
        transport_fee: this.transport_fee,
        documentation_fee: this.doc_fee,
        profit: this.profit,
        dealer_fee: this.dealer_fee,
        admin_fee: this.admin_fee
      });
    }
    const total2 = this.formProduct.value.items;
    const outValue = [];
    for (let j = 0; j < total2.length; j++) {
      outValue.push(total2[j].total_with_qty);
    }
    const reducer  = (accumulator, currentValue) => accumulator + currentValue;
    this.sum_total = outValue.reduce(reducer);

    this.formulaVisible = false;
  }

  calculateInPopup() {
    this.pop_up_total = this.popup_basic_price + this.transport_fee + this.doc_fee + this.profit +
                          (this.popup_basic_price * this.dealer_fee / 100) + (this.popup_basic_price * this.admin_fee / 100);
    console.log('calcu pop-up = ' + this.pop_up_total);
  }

  get formItems(): FormGroup {
    return this.formProduct.get('items') as FormGroup;
  }

  private loadProducts() {
    this.apiService2
      .get('product')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(product => {
          // product.stock_collection.forEach(stock => {
          items.push({
            id: product.id,
            title: product.brand + ' - ' + product.type + ' - ' + product.model,
            category: product.category,
            cylinder: product.cylinder,
            fuel: product.fuel,
            model: product.model,
            picture: product.picture,
            price: product.basic_price
            // color: stock.color,
            // engine_number: stock.engine_number,
            // manufacture_year: stock.manufacture_year,
            // vin: stock.vin
          });
          // });
        });
        this.products = [...items];
        const control = <FormArray>this.formProduct.controls['items'];
        const item_delete = control.value;

        item_delete.forEach(element => {
          if (element.product !== '') {
            const id_need_remove = element.product;
            const index = this.products.findIndex(x => x.id === id_need_remove);
            this.products.splice(index, 1); // remove element if already selected
          }
        });

        // this.selected_product_add.forEach(element => {
        //     const id_need_remove = element;
        //     const index = this.products.findIndex(x => x.id === id_need_remove);
        //     this.products.splice(index, 1); // remove element if already selected
        //   }
        // );
      });
  }

  private createItem(): FormGroup {
    return this.formBuilder.group({ product: '', price: 0, amount: 0, total: 0, total_with_qty: 0, name: '',
    transport_fee: 0, documentation_fee: 0, profit: 0 , dealer_fee: 0, admin_fee: 0 });
  }

  changeProduct(event, i: number) {
    // alert(event.id);
    const control = <FormArray>this.formProduct.controls['items'];
    control.at(i).patchValue({ price: event.price, amount: 1, total: event.price, name: event.title });

    this.popup_basic_price = control.controls[i].value.total;
    const formula_result = this.calculateFormula(null);
    control.at(i).patchValue({
      total: formula_result,
      total_with_qty: formula_result,
      transport_fee: this.transport_fee,
      documentation_fee: this.doc_fee,
      profit: this.profit,
      dealer_fee: this.dealer_fee,
      admin_fee: this.admin_fee
    });

    const total = this.formProduct.value.items;
    const outValue = [];
    for (let j = 0; j < total.length; j++) {
      outValue.push(total[j].total_with_qty);
    }
    const reducer  = (accumulator, currentValue) => accumulator + currentValue;
    this.sum_total = outValue.reduce(reducer);
    // this.calculateFormula();
    this.taxVal    = null;
    this.grand_total_value = 0;
    // back here
    // this.selected_product_add.push(event.id);
    this.loadProducts();

    console.log('Current item ', control.value[i]);
  }

  editItem(event, i: number): void {
    // alert('editItem()');
    const control = <FormArray>this.formProduct.controls['items'];
    // control.at(i).patchValue({ total: control.value[i].price * control.value[i].amount });

    // this.popup_basic_price = control.controls[i].value.total;
    // this.calculateInPopup();
    // const formula_result = this.calculateFormula(null);
    const unit_price = control.controls[i].value.total;
    const qty = control.controls[i].value.amount;
    const result = unit_price * qty;

    control.at(i).patchValue({
      // total: formula_result,
      total_with_qty: result,
      transport_fee: this.transport_fee,
      documentation_fee: this.doc_fee,
      profit: this.profit,
      dealer_fee: this.dealer_fee,
      admin_fee: this.admin_fee
     });

    const total = this.formProduct.value.items;

    const outValue = [];
    for (let j = 0; j < total.length; j++) {
      outValue.push(total[j].total_with_qty);
    }
    const reducer = (accumulator, currentValue) => accumulator + currentValue;
    this.sum_total = outValue.reduce(reducer);
    // this.calculateFormula();

    console.log('Current item ', control.value[i]);
  }

  deleteItem(i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    const total   = this.formProduct.value.items;
    const product_detail_id = control.at(i).value.id;
    const reducer = (accumulator, currentValue) => accumulator + currentValue;
    console.log(control.at(i));

    if (!product_detail_id) {
      this.sum_total = 0;
      this.taxVal = 0;
      this.grand_total_value = 0;

      const outValue = [];
      for (let s = 0; s < total.length; s++) {
        outValue.push(total[s].total);
      }

      const sum = outValue.splice(1);
      let val = 0;
      for (let i = 0; i < sum.length; i++) {
        val += sum[i];
      }
      this.sum_total = val;
      this.calculateFormula(0);
      // return;
    }
      this.apiService2.delete('purchase_order/detail/' + product_detail_id).subscribe(
        success => { },
        error => { }
      );
    const outValue2 = [];
    for (let s = 0; s < total.length; s++) {
       outValue2.push(total[s].total);
    }
    const AllItemsValue =  outValue2.reduce(reducer);
    this.sum_total = AllItemsValue - outValue2.splice(i)[0];
    this.calculateFormula(0);

    const sum = outValue2.splice(1);
    let val = 0;
    for (let i = 0; i < sum.length; i++) {
      val += sum[i];
    }
    // this.sum_total = val;
    this.loadProducts();
    control.removeAt(i);
  }

  addItem($event): void {
    this.loadProducts();
    this.items = this.formProduct.get('items') as FormArray;
    this.items.push(this.createItem());
  }

  /**
   * Back to previous location
   */
  back() {
    this.location.back();
  }

  /**
   * Redirect to new location with data
   */
  redirect(url) {
    this.router.navigate([`master/${url}/create`, { page: 'submissions', id: this.id }]);
  }
}
