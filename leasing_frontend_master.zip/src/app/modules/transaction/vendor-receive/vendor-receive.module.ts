import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VendorReceiveRoutingModule } from './vendor-receive-routing.module';
import { VendorReceiveComponent } from './vendor-receive.component';
import { VendorReceiveFormComponent } from './vendor-receive-form.component';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {
  DxValidatorModule,
  DxValidationSummaryModule,
  DxDataGridModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxDropDownBoxModule,
  DxDateBoxModule,
  DxNumberBoxModule,
  DxBoxModule,
  DxFormModule,
  DxSelectBoxModule
} from 'devextreme-angular';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    NgSelectModule,
    VendorReceiveRoutingModule,
    DxValidatorModule,
    DxValidationSummaryModule,
    DxDataGridModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxDropDownBoxModule,
    DxDateBoxModule,
    DxNumberBoxModule,
    DxBoxModule,
    DxFormModule,
    DxSelectBoxModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  declarations: [VendorReceiveComponent, VendorReceiveFormComponent]
})
export class VendorReceiveModule { }
