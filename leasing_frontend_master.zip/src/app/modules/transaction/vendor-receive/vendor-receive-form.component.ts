import { Component, OnInit, Inject } from '@angular/core';
import { Location, DatePipe } from '@angular/common';
import {
  DxButtonModule,
  DxRadioGroupModule,
  DxValidatorModule,
  DxValidationSummaryModule,
  DxRadioGroupComponent,
  DxValidatorComponent,
  DxDropDownBoxComponent,
  DxFormModule,
  DxSelectBoxModule
} from 'devextreme-angular';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { LocalStorageService } from 'ngx-webstorage';

import { ApiService, Product, Attachment, Master } from '../../../core';
import { fadeIn } from '../../../shared/animations';
import DataSource from 'devextreme/data/data_source';
import ArrayStore from 'devextreme/data/array_store';
import CustomStore from 'devextreme/data/custom_store';
import { delay, concatMap, map } from 'rxjs/operators';
import { forkJoin, combineLatest, from, concat, Observable, of } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { DISABLED } from '@angular/forms/src/model';


@Component({
  selector: 'app-vendor-receive-form',
  templateUrl: './vendor-receive-form.component.html',
  styleUrls: ['./vendor-receive-form.component.scss'],
  animations: [fadeIn()]
})
export class VendorReceiveFormComponent implements OnInit {
/* tslint:disable */
  [x: string]: any;
  id: number = null;
  form: FormGroup;
  formProduct: FormGroup;
  dataSource: any [];
  product_header: any;
  items: FormArray;
  products = [];
  tempData = [];
  status = [];
  gr_status = [];
  company = [];
  company_id_from_po: any;
  _dateValue: any;
  idVendor = [];
  selectedVendor = [];
  vendors: any;

  now: Date = new Date();
  maxDate: Date = new Date();
  sumValue = 0;
  taxVal = null;
  sum_total = 0;

  grand_total_value = 0;
  // vendors = [];

  /** Vendor data */
  detailVendor = false;
  vendor_name: any;
  vendor_type: any;
  address: any;
  phone: any;
  fax: any;
  email: any;
  web: any;

  /** Ship To Data */
  detailShipTo = false;
  company_name_ShipTo = [];
  addressShipTo = [];
  phoneShipTo = [];
  faxShipTo = [];
  emailShipto = [];
  webShipTo = [];

  /** Bill To Data */
  detailBillTo = false;
  company_name_BillTo = [];
  addressBillTo = [];
  phoneBillTo = [];
  faxBillTo = [];
  emailBillTo = [];
  webBillTo = [];
  test_a = 0;
  poNumber_collection = [];

  gr_header = {};
  have_gr_number = false;
  po_id: any;

  product_name;
  options: any;
  number = [];
  index_custom = 0;
  is_edit = false;

  total_ordered;
  received_qty;

  po_selected = false;
  year_collection = [null];
  not_valid_product = [];

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private localStorageService: LocalStorageService,
    private apiService: ApiService,
    private location: Location,
    private formBuilder: FormBuilder,
    private router: Router,
    private datePipe: DatePipe,
    private route: ActivatedRoute
  ) {
    this.dateValue = this.now;
  }

  ngOnInit() {
    this.formProduct = this.formBuilder.group({
      date: this.now,
      // vendor: '',
      vendor: new FormControl('', {
      }),
      status: new FormControl('', {
      }),
      GR_status: new FormControl('', {
      }),
      terms: new FormControl('', {
      }),
      POnumber: new FormControl('', {
      }),
      GRnumber: new FormControl('', {
      }),
      GRdate: new FormControl('', {
      }),
      shipTo: new FormControl('', {
      }),
      billTo: new FormControl('', {
      }),
      vin: new FormControl('', {
        // validators: Validators.required
      }),
      items: this.formBuilder.array([])
    });

    this.route.params.subscribe(async params => {

      let year_now = this.now.getFullYear()+1;
      for (let i =0 ; i < 4 ; i++) {
        year_now = year_now - 1 ;
        this.year_collection.push(year_now);
      }

      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (!this.id) { // if not edit
          this.loadPoNumber();
          this.loadGRStatus();
          this.is_edit = false;
        return;
      }
      // else edit
      this.is_edit = true;
      // this.loadProducts(this.id);
      this.gr_header = await this.apiService.get('goods_receipt_note/' + this.id).toPromise();
      const po_id_edit = this.gr_header['po_id'];
      this.loadProductsEdit(this.id);

      return this.apiService.get('purchase_order/' + po_id_edit).subscribe((data) => {
      // get only number from string
        let po_terms = data['po_terms'].match(/\d/g);
        po_terms = po_terms.join('');

      this.company_id_from_po = data['company_id'];
      const po_detail = data['po_detail'];
      this.detailVendor = true;
      this.detailShipTo = true;
      this.detailBillTo = true;
      this.product_name = 'ini nama label';
      // this.sum_total = data['total_before_tax'];

      // header data
      console.log(this.gr_header);
      this.formProduct.patchValue({
        GR_status: this.gr_header['grn_status']
      });

      this.formProduct.patchValue({
          date: this.datePipe.transform(data['po_date'], 'yyyy-MM-dd HH:mm:ss', '008Z'),
          POnumber: this.gr_header['po_number'],
          GRnumber: ((this.gr_header) ? this.gr_header['grn_number'] : ''),
          GRdate: (
            (this.gr_header) ?
              this.datePipe.transform(this.gr_header['grn_date'], 'yyyy-MM-dd HH:mm:ss', '008Z') : this.now),
          status: data['po_status'],
          terms: data['po_terms'],
          vendor: data['vendor_id'],
          shipTo: data['ship_to_id'],
          billTo: data['bill_to_id']
        });

      this.total_before_tax = this.gr_header['total_before_tax'];
      this.total_after_tax  = this.gr_header['total_after_tax'];
      this.tax = this.gr_header['tax'];
      this.po_id = this.gr_header['po_id'];
      this.total_ordered = 0;
      this.grn_status = this.gr_header['grn_status'];
      //count ordered qty
      data['po_detail'].forEach(e => {
       this.total_ordered = this.total_ordered + e.qty;
      });

        // detail card vendor
        this.apiService.get('vendor/' + data['vendor_id']).subscribe((data_vendor: any) => {
          this.vendor_name = data_vendor.vendor_name;
          this.vendor_type = data_vendor.vendor_type;
          this.address = data_vendor.address;
          this.phone = data_vendor.phone;
          this.fax = data_vendor.fax;
          this.email = data_vendor.email;
          this.web = data_vendor.web;
        });
        // detail card vendor ship To
        this.apiService.get('dealer/' + data['ship_to_id']).subscribe((data_shipTo: any) => {
          this.company_name_ShipTo = data_shipTo.dealer_name;
          this.ship_to_name = data_shipTo.dealer_name;
          this.addressShipTo = data_shipTo.address;
          this.phoneShipTo = data_shipTo.phone;
          this.faxShipTo = data_shipTo.fax;
          this.emailShipto = data_shipTo.email;
          this.webShipTo = data_shipTo.web;
        });
        // detail card vendor Bill To
        this.apiService.get('company/' + data['bill_to_id']).subscribe((data_billTo: any) => {
          this.company_name_BillTo = data_billTo.company_name;
          this.bill_to_name = data_billTo.company_name;
          this.addressBillTo = data_billTo.address;
          this.phoneBillTo = data_billTo.phone;
          this.faxBillTo = data_billTo.fax;
          this.emailBillTo = data_billTo.email;
          this.webBillTo = data_billTo.web;
        });
      });
    });
  }

  private loadGRStatus() {
    const GR_status = [
        { id: 'PARTIAL', name: 'Partial' },
        { id: 'RECEIVED', name: 'Received' }
      ];
      this.gr_status = [...GR_status];
  }

  private async loadPoNumber() {
    const po_number_api = await this.apiService
      .get('purchase_order/search?po_status=APPROVED&grn_status=NOT_RECEIVED&size=500&sort=id,desc')
      .toPromise();
    const po = [];
    po_number_api['content'].forEach(val => {
      po.push({
        po_id: val.id,
        po_number: val.po_number,
        po_date: val.po_date,
        po_status: val.po_status,
        po_terms: val.po_terms,
        bill_to_id: val.bill_to_id,
        bill_to_name: val.bill_to_name,
        ship_to_id: val.ship_to_id,
        ship_to_name: val.ship_to_name,
        vendor: val.vendor_id,
        vendor_name: val.vendor_name,
        grn_status: val.grn_status,
        company_id: val.company_id,
        tax: val.tax,
        total_before_tax: val.total_before_tax,
        total_after_tax: val.total_after_tax,
        po_detail: val.po_detail
      });
    });
    this.poNumber_collection = [...po];
  }

  private loadVendors(): any {
      const company_active = this.localStorageService.retrieve('user_company_active');
      this.apiService
        .get('vendor?sort=vendorName,asc&company_id=' + company_active)
        .pipe(delay(500))
        .subscribe((data: Master) => {
          const items = [];
          data.content.forEach(el => {
            items.push(
              {
                id: el.id,
                title: el.vendor_name,
                type: el.vendor_type,
                address: el.address,
                phone: el.phone,
                fax: el.fax,
                email: el.email,
                web: el.web
              });
          });
          this.vendors = [...items];
        });
  }

  loadProductsEdit(grn_id) {
    this.apiService.get('goods_receipt_note/'+ grn_id).subscribe((data_grn_detail) => {
      console.log(data_grn_detail['grn_detail']);

      data_grn_detail['grn_detail'].forEach(item => {
        const rd2 = this.formBuilder.group({
          product_id: [item.product_id],
          product_name: [item.product_name],
          vin: [item.vin],
          engine_number: [item.engine_number],
          color: [item.color],
          manufacture_year: [item.manufacture_year],
          unit_price:[item.unit_price],
          id:[item.id]
        });
        this.Detailproduct.push(rd2);
      });
      this.tempData = data_grn_detail['grn_detail'];
    });
  }

    changePO(event) {
      this.po_selected = true;
      this.total_ordered = 0;
      this.received_qty = 0;
      console.log(event);
      this.po_id        = event.po_id;
      this.po_number    = event.po_number;
      this.po_status    = event.po_status;
      this.po_terms     = event.po_terms;
      this.po_date      = event.po_date;
      this.bill_to_id   = event.bill_to_id;
      this.bill_to_name = event.bill_to_name;
      this.ship_to_id   = event.ship_to_id;
      this.ship_to_name = event.ship_to_name;
      this.vendor_id    = event.vendor;
      this.vendor_name  = event.vendor_name;
      this.company_id   = event.company_id;
      this.tax          = event.tax;
      this.total_before_tax = event.total_before_tax;
      this.total_after_tax  = event.total_after_tax;
      this.po_detail        = event.po_detail;

      /** GET Vendor Data */
      this.apiService.get('vendor/' + this.vendor_id).subscribe((data: any) => {
        this.vendor_type = data.vendor_type;
        this.address = data.address;
        this.phone = data.phone;
        this.fax = data.fax;
        this.email = data.email;
        this.web = data.web;
      });
      /** GET Ship To Data */
      this.apiService.get('dealer/' + this.ship_to_id).subscribe((data: any) => {
        this.company_name_ShipTo = data.company_name;
        this.addressShipTo = data.address;
        this.phoneShipTo = data.phone;
        this.faxShipTo = data.fax;
        this.emailShipto = data.email;
        this.webShipTo = data.web;
      });
      /** GET Bill To Data */
      this.apiService.get('company/' + this.bill_to_id).subscribe((data: any) => {
        this.company_name_BillTo = data.company_name;
        this.addressBillTo = data.address;
        this.phoneBillTo = data.phone;
        this.faxBillTo = data.fax;
        this.emailBillTo = data.email;
        this.webBillTo = data.web;
      });


      const control = <FormArray>this.formProduct.controls['items'];
      console.log(control.controls);

      for (let s = 0; s < control.controls.length; s++) { // hapus ketika ganti PO
         // console.log(s);
          control.removeAt(s);
      }

      this.loadProductForAdd(this.po_id);
    }

  private loadProductForAdd(po_id) {
    //  console.log(po_id);
    this.apiService
      .get('purchase_order/' + po_id)
      .pipe(delay(500))
      .subscribe((data_po_for_grid) => {
        console.log(data_po_for_grid);
        const items = [];
        const count = [];
        const temp: any = [];
        data_po_for_grid['po_detail'].forEach(data_po_detail => {
          this.total_ordered = this.total_ordered + data_po_detail.qty;
          for (let i = 0; i < data_po_detail.qty; i++) {
            const receiptDetail =
              {
                product_id: data_po_detail.product_id,
                product_name: data_po_detail.product_name,
                vin: null,
                engine_number: null,
                color: null,
                manufacture_year: null,
                unit_price: data_po_detail.unit_price
              };
            count.push(i);
            temp.push(receiptDetail);
            // this.Detailproduct.push(receiptDetail);
          }

          const product_id = data_po_detail.product_id;
          items.push({
            id: data_po_detail.id,
            title: data_po_detail.product_name,
            product_id: product_id,
            // picture: data_product['picture'],
            price: data_po_detail.unit_price,
            qty_po: data_po_detail.qty,
            unit_price: data_po_detail.unit_price,
            sub_total: data_po_detail.sub_total,
            grn_detail: count
          });
          // this.Detailproduct.push(temp);
        });

        console.log(temp);

        temp.forEach(item => {
          const rd2 = this.formBuilder.group({
            product_id: [item.product_id],
            product_name: [item.product_name],
            vin: [],
            engine_number: [],
            color: [],
            manufacture_year: [],
            unit_price:[item.unit_price]
          });
          // const rd2 = this.createItem();
          this.Detailproduct.push(rd2);
        });
        this.products = [...items];
        console.log(this.products);
        this.tempData = temp;
        console.log(this.tempData);
      });
  }

  private createItem(): FormGroup {
    return this.formBuilder.group({
      product_id: '',
      product_name: '',
      vin: '',
      engine_number: '',
      color: '',
      manufacture_year: ''
    });
  }

  editItem(i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    console.log(control.value[i].vin);

    control.at(i).patchValue({ vin: control.value[i].vin });
  }
  get Detailproduct() {
    return this.formProduct.get('items') as FormArray;
  }
  get formItems(): FormGroup {
    return this.formProduct.get('items') as FormGroup;
  }


    validateAllFormFields(formGroup: FormGroup) {
      Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
          this.validateAllFormFields(control);
        }
      });
    }

    isFieldValid(field: string) {
    // return !this.formProduct.valid && this.formProduct.touched;
    return !this.formProduct.get(field).valid && this.formProduct.get(field).touched;
    }

    displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
    }

    private Validation(dataForm) {
      this.valid =1;
      let vin_not_valid = 0;
      let engine_number_not_valid = 0;
      let color_not_valid = 0;
      let manufacture_year_valid = 0;

      dataForm.forEach(value => {
        if (!value.vin) {
          vin_not_valid++;
          this.valid = this.NotSave(0);
        }
        if (!value.engine_number) {
          engine_number_not_valid++;
          this.valid = this.NotSave(0);
        }
        if (!value.color) {
          color_not_valid++;
          this.valid = this.NotSave(0);
        }
        if (!value.manufacture_year) {
          manufacture_year_valid++;
          this.valid = this.NotSave(0);
        }
      });

      if (vin_not_valid >= 1) {
        alert ('One or more Vin is Empty');
      }
      if (engine_number_not_valid >= 1) {
        alert ('One or more Engine Number is Empty');
      }
      if (color_not_valid >= 1) {
        alert ('One or more Color is Empty');
      }
      if (manufacture_year_valid >= 1) {
        alert ('One or more Manufacture Year is Empty');
      }
      return this.NotSave(this.valid);
    }

    NotSave(value) {
      return value === 0 ? 0 : 1;
    }


  async save() {
    this.received_qty = 0;
    let grn_status_save;
    if (this.formProduct.valid) {
      let save_grn = 'failed';
      let save_stock = 'failed';
      const myDate  = new Date(this.dateValue);
      const NewDate = myDate.toISOString();

      const poDate = new Date(this.formProduct.value.date).toISOString();
      const grn_detail = [];
      const product_collection = this.formProduct.value.items;

      const product_value = [];
      const product_stock_insert = [];
      let updateProductStock = {};


      if(!this.id) {
      /* POST */
      const check_product = this.Validation(product_collection);
        if (check_product === 1){
        await product_collection.forEach(async value => {
          if(value.vin && value.engine_number && value.color && value.manufacture_year) { // hitung brp bnyk item yg sudah diisi
            this.received_qty = this.received_qty + 1;
          }

          const detail = {
            product_id : value.product_id,
            product_name : value.product_name,
            manufacture_year : value.manufacture_year,
            vin : value.vin,
            engine_number : value.engine_number,
            color : value.color,
            unit_price : value.unit_price,
            sell_price : value.unit_price
          };
          await grn_detail.push(detail);
        });

        console.log('total ordered = '+ this.total_ordered);
        console.log('total received = '+ this.received_qty);

        if (this.received_qty === 0) {
          grn_status_save = 'UNRECEIVED';
        } else if (this.total_ordered === this.received_qty) {
          grn_status_save = 'RECEIVED';
        } else if (this.total_ordered > this.received_qty) {
          grn_status_save = 'PARTIAL';
        }
      // console.log(grn_status_save);
        const form_value = {
          company_id : this.company_id,
          po_id : this.po_id,
          grn_date: NewDate,
          po_number : this.formProduct.value.POnumber,
          po_date : poDate,
          po_terms : this.po_terms,
          vendor_id : this.vendor_id,
          vendor_name : this.vendor_name,
          ship_to_id : this.ship_to_id,
          ship_to_name : this.ship_to_name,
          bill_to_id : this.bill_to_id,
          bill_to_name : this.company_name_BillTo,
          total_before_tax : this.total_before_tax,
          tax : this.tax,
          total_after_tax : this.total_after_tax,
          order_qty : 1,
          received_qty : 1,
          payment_status: 'UNPAID',
          // grn_status: this.formProduct.value.GR_status,
          grn_status : grn_status_save,
          grn_detail: grn_detail
          // grn_number: this.formProduct.value.GRnumber
        };

        await this.apiService.post('goods_receipt_note/', form_value).subscribe(
          success => {
            console.log(success);
            save_grn = 'success';
          },
          error => {
            console.log(error);
          });

        // start post stock yg ada isinya saja
        product_collection.forEach(data => {
          if(data.vin && data.engine_number && data.color && data.manufacture_year) {
          updateProductStock = {
            product : {
              id : data.product_id
            },
            manufacture_year : data.manufacture_year,
            vin: data.vin,
            engine_number: data.engine_number,
            color: data.color,
            price: data.unit_price,
            sales_status: 'AVAILABLE',
            storage_location_id: this.ship_to_id,
            storage_location_name: this.ship_to_name,
            // grn_detail_id
          };

          this.apiService.post('product_stock/', updateProductStock).subscribe(
            success => {
              save_stock = 'success';
              console.log(success);
              this.router.navigate(['transaction/vendor-receive']);
            },
            error => {
              console.log(error);
            });
          }
        });
        // end product stock

        //update PO status if all received
        let po_update_status;

        if (grn_status_save === 'RECEIVED') {
          po_update_status = {
              grn_status: 'RECEIVED'
          };
        } else if (grn_status_save === 'PARTIAL') {
          po_update_status = {
            grn_status: 'PARTIAL'
          };
        }

        if (grn_status_save !== 'UNRECEIVED' && save_grn === 'success' && save_stock === 'success') {
          this.apiService.put('purchase_order/grn_status/' + this.po_id, po_update_status).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );
        }
        }
        else {
          return false;
        }
      }
      else {
      /* EDIT */
        console.log('edit');
        console.log(this.po_id);

        product_collection.forEach(element => {
          if (element.vin && element.engine_number && element.color && element.manufacture_year) {
            this.received_qty = this.received_qty + 1; // hitung brp bnyk item yg sudah diisi

            const product_edit = {
              goods_receipt_note: {
                id : this.id
              },
              product_id: element.product_id,
              product_name: element.product_name,
              manufacture_year: element.manufacture_year,
              vin: element.vin,
              engine_number: element.engine_number,
              color: element.color,
              unit_price:element.unit_price,
              sell_price: element.unit_price
            }
            // post stock baru yg ada isinya saja dan beda
            this.apiService.get(
              'product_stock/search?vin=' + element.vin+ '&engine_number='+element.engine_number)
              .subscribe((data) => {
                if(data['number_of_elements'] === 0) {
                  console.log('msk ini');
                  updateProductStock = {
                    product : {
                      id : element.product_id
                    },
                    manufacture_year : element.manufacture_year,
                    vin: element.vin,
                    engine_number: element.engine_number,
                    color: element.color,
                    price: element.unit_price,
                    sales_status: 'AVAILABLE',
                    storage_location_id: this.ship_to_id,
                    storage_location_name: this.ship_to_name
                  };

                  this.apiService.post('product_stock/', updateProductStock).subscribe(
                    success => {
                      console.log(success);
                    },
                    error => {
                      console.log(error);
                    });
                }
                // else tampilkan alert
              }
            );

            // update GRN detail
            this.apiService.put('goods_receipt_note/detail/'+ element.id, product_edit).subscribe(
              success => {
                console.log(success);
                this.router.navigate(['transaction/vendor-receive']);
              },
              error => {
                console.log(error);
              }
            );
          }
        });

        if (this.received_qty === 0) {
          grn_status_save = 'UNRECEIVED';
        } else if (this.total_ordered === this.received_qty) {
          grn_status_save = 'RECEIVED';
        } else if (this.total_ordered > this.received_qty) {
          grn_status_save = 'PARTIAL';
        }

        // if RECEIVED UPDATE GRN Header Status = RECEIVED AND Update PO grn status = received
        if (grn_status_save == 'RECEIVED') {
          const param = {
            grn_status: "RECEIVED"
          }
          this.apiService.put('purchase_order/grn_status/' + this.po_id, param).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );

          this.apiService.put('goods_receipt_note/grn_status/' + this.id, param).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );
        }
      }
    } else {
      this.validateAllFormFields(this.formProduct);
    }
  }

  async checkVin(vin_check, i) {
    const check_vin_api = await this.apiService.get('product_stock/search/vin?vin=' + vin_check).toPromise();

    if(check_vin_api['number_of_elements'] >= 1) {
      alert('Vin = ' + vin_check + ' already inserted in system');
      const control = <FormArray>this.formProduct.controls['items'];
      control.at(i).patchValue({ vin: ''});
    }


  }
  async checkEngineNumber(engine_number_check, i) {
    const check_engine_number_api = await this.apiService.get('product_stock/search/engine?engine_number=' + engine_number_check).toPromise();

    if(check_engine_number_api['number_of_elements'] >= 1) {
      alert('Engine Number = ' + engine_number_check + ' already inserted in system');
      const control = <FormArray>this.formProduct.controls['items'];
      control.at(i).patchValue({ engine_number: ''});
    }
  }

  back() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.vendors = false;
  }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = (value && [value]) || [];
    this._dateValue = value;
  }

  counter(i: number) {
    return new Array(i);
  }


}
