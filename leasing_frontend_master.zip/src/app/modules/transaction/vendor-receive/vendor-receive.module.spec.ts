import { VendorReceiveModule } from './vendor-receive.module';

describe('VendorReceiveModule', () => {
  let vendorReceiveModule: VendorReceiveModule;

  beforeEach(() => {
    vendorReceiveModule = new VendorReceiveModule();
  });

  it('should create an instance', () => {
    expect(vendorReceiveModule).toBeTruthy();
  });
});
