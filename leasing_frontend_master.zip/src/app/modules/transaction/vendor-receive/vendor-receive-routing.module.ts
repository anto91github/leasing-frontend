import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VendorReceiveComponent } from './vendor-receive.component';
import { VendorReceiveFormComponent } from './vendor-receive-form.component';

const routes: Routes = [
  {
    path: '',
    component: VendorReceiveComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: VendorReceiveFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: VendorReceiveFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VendorReceiveRoutingModule { }
