import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { fadeIn } from '../../../shared/animations';
import { DxDataGridComponent } from 'devextreme-angular';
import { Router } from '@angular/router';
import { ApiService, ConfigService } from '../../../core';
import CustomStore from 'devextreme/data/custom_store';
import { Location } from '@angular/common';
import { LocalStorageService } from 'ngx-webstorage';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import * as jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import 'jspdf-autotable';
import { Master } from '../../../core/models';
import { DatePipe, formatCurrency } from '@angular/common';

@Component({
  selector: 'app-vendor-receive',
  templateUrl: './vendor-receive.component.html',
  styleUrls: ['./vendor-receive.component.scss'],
  providers: [ApiService, TranslateService],
  animations: [fadeIn()]
})
export class VendorReceiveComponent implements OnInit {
  title: any;
  [x: string]: any;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;
  // dataSource: any = [];
  dataSource: any = {};
  dataGridPageSize = 10;
  route = 'transaction/vendor-receive';
  status_product_edit;
  vin_old;
  engine_number_old;

  constructor(
    @Inject(ApiService) apiServiceInject: ApiService,
    private router: Router,
    private apiService: ApiService,
    private location: Location,
    private localSt: LocalStorageService,
    private config: ConfigService,
    private datePipe: DatePipe,
    private translateService: TranslateService
  ) {
    this.title = this.translateService.instant('app.vendor-receive');
    this.dataSource.store = new CustomStore({
      load: function (options: any) {
        options.userData.company_id = true;
        // options.userData.is_po_approved = true;
        // options.userData.grn_status_not = true;
        // return apiServiceInject.getMaster('purchase_order/search', options);
        options.userData.custom_sort = true;
        options.userData.selector = 'id';
        options.userData.sortMethod = 'desc';
        return apiServiceInject.getMaster('goods_receipt_note', options);
      }
      // ,
      // remove: function (row) {
      //   return apiServiceInject
      //     .delete('goods_receipt/' + row.id)
      //     .toPromise()
      //     .then(
      //       () => document.getElementById('btn-refresh').click(),
      //       error => Promise.reject(error.error.message)
      //     );
      // }
    });
    this.dataGridPageSize = config.getConfig('paginationLength');
  }

  ngOnInit() {}

  async checkStatusProduct(event) {
    this.vin_old = event.key.vin;
    this.engine_number_old = event.key.engine_number;

    const api_status = await this.apiService.get(
      'product_stock/search?vin=' + this.vin_old + '&engine_number=' + this.engine_number_old).toPromise();
    this.status_product_edit = api_status['content'][0]['sales_status'];
  }

  Editing(event) {
    console.log(event);
  }

  async inLineEdit(event, header_data) {
    if (this.status_product_edit !== 'AVAILABLE') {
      alert ('This Product is NOT AVAILABLE anymore to be change');
      location.reload();
      return false;
    }

    const detail_product_edit = event.key;
    const grn_detail_id = event.key.id;
    const vin = event.key.vin;
    const engine_number = event.key.engine_number;
    const color = event.key.color;
    const manufacture_year = event.key.manufacture_year;

    const edit_stock = {
      color: color,
      vin: vin,
      engine_number: engine_number,
      manufacture_year: manufacture_year
    };
    const grn_header_id = header_data.id;

    const grn_detail_edit = {
      goods_receipt_note: {
        id : grn_header_id
      },
      product_id: detail_product_edit.product_id,
      product_name: detail_product_edit.product_name,
      manufacture_year: detail_product_edit.manufacture_year,
      vin: detail_product_edit.vin,
      engine_number: detail_product_edit.engine_number,
      color: detail_product_edit.color,
      unit_price: detail_product_edit.unit_price,
      sell_price: detail_product_edit.unit_price
    };

      // Edit Grn Detail
      this.apiService.put('goods_receipt_note/detail/' + grn_detail_id, grn_detail_edit).subscribe(
        success => {
          console.log(success);
        },
        error => {
          console.log(error);
        }
      );

      // Edit Product Stock
      this.apiService.put('product_stock/vin/' + grn_detail_id, edit_stock).subscribe(
        success => {
          console.log(success);
        },
        error => {
          console.log(error);
        }
      );

      // Edit Invoice Payment Detail
      this.apiService.get('invoice_payment/by?grn_id=' + grn_header_id).subscribe(
        async (data: any) => {
          console.log(data);
          if (data['number_of_elements'] !== 0) {
            const invoice_header_id = data['content'][0]['id'];

            // search invoice detail id by vin and engine number
            const id_api = await this.apiService.get(
              'invoice_payment/detail?vin=' + this.vin_old + '&engine_number=' + this.engine_number_old).toPromise();
            const invoice_detail_id = id_api['content'][0]['id'];

            // edit invoice detail
            const edit_invoice_detail = {
              manufacture_year: detail_product_edit.manufacture_year,
              vin: detail_product_edit.vin,
              engine_number: detail_product_edit.engine_number,
              color: detail_product_edit.color
            };

            this.apiService.put('invoice_payment/detail/' + invoice_detail_id, edit_invoice_detail).subscribe(
              success => {
                console.log(success);
              },
              error => {
                console.log(error);
              }
            );

          }
        }
      );

  }

  actionRefresh() {
    this.dataGrid.instance.refresh();
  }

  actionAdd() {
    this.router.navigate([this.route, 'create']);
  }

  actionEdit(id) {
    console.log(id);
    this.router.navigate([this.route, id, 'edit']);
  }

  actionPdf() {
    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.grn_number'), dataKey: 'grn_number' },
      { title: this.translateService.instant('app.grn_date'), dataKey: 'grn_date' },
      { title: this.translateService.instant('app.po-number'), dataKey: 'po_number' },
      { title: this.translateService.instant('app.po-date'), dataKey: 'po_date' },
      { title: this.translateService.instant('app.terms'), dataKey: 'po_terms' },
      { title: this.translateService.instant('app.vendor'), dataKey: 'vendor_name' },
      { title: this.translateService.instant('app.ship-to'), dataKey: 'ship_to_name' },
      { title: this.translateService.instant('app.bill-to'), dataKey: 'bill_to_name' },
      { title: this.translateService.instant('app.delivery-value'), dataKey: 'total_after_tax' },
      { title: this.translateService.instant('app.order_qty'), dataKey: 'order_qty' },
      { title: this.translateService.instant('app.received_qty'), dataKey: 'received_qty' },
      { title: this.translateService.instant('app.status'), dataKey: 'grn_status' }
    ];
    const rows = [];
    const company_active = this.localSt.retrieve('user_company_active');
    this.apiService.get('goods_receipt_note?company_id=' + company_active).subscribe(
      (success: any) => {
        const items = success.content;
        for (let i = 0; i < items.length; i++) {
          rows.push({
            no: `${i + 1}.`,
            grn_number: items[i].grn_number,
            grn_date: this.datePipe.transform(items[i].grn_date, 'yyyy-MM-dd'),
            po_number: items[i].po_number,
            po_date: this.datePipe.transform(items[i].po_date, 'yyyy-MM-dd'),
            po_terms: items[i].po_terms,
            vendor_name: items[i].vendor_name,
            ship_to_name: items[i].ship_to_name,
            bill_to_name: items[i].bill_to_name,
            total_after_tax: items[i].total_after_tax,
            order_qty: items[i].order_qty,
            received_qty: items[i].received_qty,
            grn_status: items[i].grn_status
          });
        }

        // Only pt supported (not mm or in)
        const doc = new jsPDF('l', 'pt');
        doc.autoTable(columns, rows, {
          addPageContent: function (data) {
            doc.text('Goods Receipt Note', 40, 30);
          },
          margin: { top: 60 },
          bodyStyles: { valign: 'top' },
          styles: { overflow: 'linebreak', fontSize: 7 },
          columnStyles: { text: { columnWidth: 'auto' } }
        });
        window.open(doc.output('bloburl'));
      },
      error => {
        console.log(error);
      }
    );
  }

  async actionPrintReceived(value) {
    const data_po = await this.apiService.get('goods_receipt_note/' + value).toPromise();
    const vendor_id = data_po['vendor_id'];
    const shippTo_id = data_po['ship_to_id'];
    const billTo_id = data_po['bill_to_id'];

    const data_vendor = await this.apiService.get('vendor/' + vendor_id).toPromise();
    const data_ship_dealer = await this.apiService.get('dealer/' + shippTo_id).toPromise();
    const data_bill_company = await this.apiService.get('company/' + billTo_id).toPromise();

    const doc = new jsPDF('p', 'pt');
    // const doc = new jsPDF('p', 'mm', [148, 210]); // A5 page size

    const columns = [
      { title: 'No', dataKey: 'no' },
      { title: this.translateService.instant('app.product'), dataKey: 'product' },
      { title: this.translateService.instant('app.manufacture_year'), dataKey: 'manufacture_year' },
      { title: this.translateService.instant('app.vin'), dataKey: 'vin' },
      { title: this.translateService.instant('app.engine_number'), dataKey: 'engine_number' },
      { title: this.translateService.instant('app.color'), dataKey: 'color' },
      { title: this.translateService.instant('app.sell_price'), dataKey: 'sell_price' }

    ];

    const rows = [];
    // for (let i = 0; i < data_po['grn_detail']['length']; i++) {
    //   rows.push({
    //     no: `${i + 1}.`,
    //     product: data_po['grn_detail'][i].product_name,
    //     manufacture_year: data_po['grn_detail'][i].manufacture_year,
    //     vin: data_po['grn_detail'][i].vin,
    //     engine_number: data_po['grn_detail'][i].engine_number,
    //     color: data_po['grn_detail'][i].color,
    //     sell_price: this.formatNumber(data_po['grn_detail'][i].sell_price)
    //   });
    // }

    data_po['grn_detail'].forEach(element => {
    let vin = '-';
    let manufacture_year = '-';
    let engine_number = '-';
    let color = '-';
    let sell_price = 0;
    console.log(element);

      if (element['vin']) {
        vin = element['vin'];
      }
      if (element['manufacture_year']) {
        manufacture_year = element['manufacture_year'];
      }
      if (element['engine_number']) {
        engine_number = element['engine_number'];
      }
      if (element['color']) {
        color = element['color'];
      }
      if (element['sell_price']) {
        sell_price = element['sell_price'];
      }
      rows.push({
        product: element.product_name,
        manufacture_year: manufacture_year,
        vin: vin,
        engine_number: engine_number,
        color: color,
        sell_price: sell_price
      });
    });


    const col_empty = ['', ''];
    const row_empty = [];

    const columns_head = ['', '', '', ''];
    const rows_head = [
    ];


    const col_before_tax = ['', '', ''];
    const row_before_tax = [
        [
          'Total Before Tax ',
          ':',
          this.formatNumber(data_po['total_before_tax'])
        ],
        [
          'Tax ',
          ':',
          this.formatNumber(data_po['tax'])
        ]
      ];

    const col_after_tax = ['', '', ''];
    const row_after_tax = [
        [
          'Total After Tax ',
          ':',
          this.formatNumber(data_po['total_after_tax'])
        ]
      ];

      // draw PDF
      // const po_date_format = this.datePipe.transform(data_po['po_date'], 'yyyy-MM-dd HH:mm:ss', '008Z');
      const grn_date_format = this.datePipe.transform(data_po['grn_date'], 'yyyy-MM-dd');
      rows_head.push({
        0: 'GR Number: ' +  data_po['grn_number']
      });
      rows_head.push({
        0: 'PO Number: ' +  data_po['po_number']
      });
      rows_head.push({
        0: 'PO Date  : ' + grn_date_format
      });
      rows_head.push({
        0: 'Status : ' + data_po['grn_status']
      });


      // title
      doc.autoTable(columns_head, rows_head, {
        addPageContent: function (data) {
          doc.text('RECEIVED', 50, 40);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 },
          1: { columnWidth: 200 },
          2: { columnWidth: 70 }
        }
      });

      // company header
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.text('PT. Mobe Auto Dwipantara', 360, 40);
          doc.setFontSize(9);
          doc.text('Jl. H. Rasuna Said No.Kav 1, RT.1/RW.6', 388, 55);
          doc.text('Phone: 021-12345678', 462, 67);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });


      // // date and status
      // const grn_date_format = this.datePipe.transform(data_po['grn_date'], 'yyyy-MM-dd');
      // doc.autoTable(col_empty, row_empty, {
      //   addPageContent: function (data) {
      //     doc.setFontSize(9);
      //     doc.text('GR Number : ' + data_po['grnNumber'], 52, 90);
      //     doc.text('Status : ' + data_po['po_status'], 52, 100);
      //   },
      //   theme: 'plain',
      //   margin: { top: 35, left: 50 },
      //   bodyStyles: { valign: 'top' },
      //   styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
      //   columnStyles: {
      //     0: { columnWidth: 200 }
      //   }
      // });

      // vendor
      const splitVendorAddress = doc.splitTextToSize(data_vendor['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Vendor :', 52, 125);
          doc.setFontType('normal');
          doc.text(data_vendor['vendor_name'], 52, 135);
          doc.text(splitVendorAddress, 52, 145);
          doc.text('Phone : ' + data_vendor['phone'], 52, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // ship to
      const splitShipAddress = doc.splitTextToSize(data_ship_dealer['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Ship To :', 230, 125);
          doc.setFontType('normal');
          doc.text(data_ship_dealer['dealer_name'], 230, 135);
          doc.text(splitShipAddress, 230, 145);
          doc.text('Phone: ' + data_ship_dealer['phone'], 230, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

      // bill to
      const splitBillAddress = doc.splitTextToSize(data_bill_company['address'], 300);
      doc.autoTable(col_empty, row_empty, {
        addPageContent: function (data) {
          doc.setFontSize(8);
          doc.setFontType('bold');
          doc.text('Bill To :', 400, 125);
          doc.setFontType('normal');
          doc.text(data_bill_company['company_name'], 400, 135);
          doc.text(splitBillAddress, 400, 145);
          doc.text('Phone: ' + data_bill_company['phone'], 400, 165);
        },
        theme: 'plain',
        margin: { top: 35, left: 50 },
        bodyStyles: { valign: 'top' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 200 }
        }
      });

       // table detail
       doc.autoTable(columns, rows, {
        theme: 'grid',
        margin: { top: 180 },
        bodyStyles: { valign: 'top' },
        headerStyles: { halign: 'center', fillColor: [153, 153, 153] },
        styles: { overflow: 'linebreak', fontSize: 7, halign: 'right' },
        columnStyles: {
          no: { columnWidth: 25 },
          product_qty: { columnWidth: 25 },
          product: { halign: 'left' },
          text: { columnWidth: 'auto' }
        }
      });
      this.apiService.get('goods_receipt_note/' + value).subscribe(
        (response: any) => {
        // to get y position of last autotable
      const finalY = doc.autoTable.previous.finalY + 15;
      const finalY2 = doc.autoTable.previous.finalY + 25;
      const finalY3 = doc.autoTable.previous.finalY + 45;

      // total before tax and tax
      doc.autoTable(col_before_tax, row_before_tax, {
        addPageContent: function (data) {
        },
        theme: 'plain',
        margin: { top: finalY, left: 393 },
        bodyStyles: { valign: 'top', halign: 'right' },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 80 },
          1: { columnWidth: 10 },
          2: { columnWidth: 70 }
        }
      });

      // total after tax
      doc.autoTable(col_after_tax, row_after_tax, {
        addPageContent: function (data) {
        },
        theme: 'plain',
        margin: { top: finalY3, left: 393 },
        bodyStyles: { valign: 'top', halign: 'right', fontStyle: 'bold', fontSize: 11 },
        styles: { overflow: 'linebreak', fontSize: 9, cellPadding: 1 },
        columnStyles: {
          0: { columnWidth: 80 },
          1: { columnWidth: 10 },
          2: { columnWidth: 70 }
        }
      });
        window.open(doc.output('bloburl'));
      });
    }

  actionExcel() {
    const company_active = this.localSt.retrieve('user_company_active');
    this.apiService.get('goods_receipt_note?company_id=' + company_active).subscribe(
      (success: Master) => {
        const table = [];
        success.content.forEach(el => {
          table.push({
            ID: el.id,
            ['GRN Number']: el.grn_number,
            ['GRN Date']: el.grn_date,
            ['PO Number']: el.po_number,
            ['PO Date']: el.po_date,
            ['PO Terms']: el.po_terms,
            ['Vendor Name']: el.vendor_name,
            ['Ship To']: el.ship_to_name,
            ['Bill To']: el.bill_to_name,
            ['PO Amount']: el.total_after_tax,
            ['Order Qty']: el.order_qty,
            ['Received Qty']: el.received_qty,
            ['GRN Status']: el.grn_status
          });
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(table);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, this.title);
        XLSX.writeFile(wb, `${this.title}.xlsx`);
      },
      error => {
        console.log(error);
      }
    );
  }

  actionDelete(row) {
    this.dataGrid.instance.deleteRow(row.rowIndex);
  }
/**
   * To Format Number with , (digit grouping)
   */
  formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(value);
  }
}
