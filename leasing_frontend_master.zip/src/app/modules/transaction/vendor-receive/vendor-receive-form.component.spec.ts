import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorReceiveFormComponent } from './vendor-receive-form.component';

describe('VendorReceiveFormComponent', () => {
  let component: VendorReceiveFormComponent;
  let fixture: ComponentFixture<VendorReceiveFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VendorReceiveFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorReceiveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
