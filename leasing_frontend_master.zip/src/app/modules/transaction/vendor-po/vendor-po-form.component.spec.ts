import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorPoFormComponent } from './vendor-po-form.component';

describe('VendorPoFormComponent', () => {
  let component: VendorPoFormComponent;
  let fixture: ComponentFixture<VendorPoFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VendorPoFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorPoFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
