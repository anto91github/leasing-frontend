import { Component, OnInit, ChangeDetectionStrategy, ViewChild, Injectable } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { map, mergeMap, concatMap, delay } from 'rxjs/operators';
import { LocalStorageService } from 'ngx-webstorage';
import { Location } from '@angular/common';
import { Observable, concat } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { fadeIn } from '../../../shared/animations';
import { ApiService, Master, Product } from '../../../core';
import { Router, ActivatedRoute } from '@angular/router';
import { DxDataGridComponent } from 'devextreme-angular';
import { FlashMessagesService } from 'angular2-flash-messages';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-vendor-po-form',
  changeDetection: ChangeDetectionStrategy.Default,
  templateUrl: './vendor-po-form.component.html',
  styleUrls: ['./vendor-po-form.component.scss'],
  animations: [fadeIn()]
})

@Injectable()

export class VendorPoFormComponent implements OnInit {
/* tslint:disable */
  [x: string]: any;
  form: FormGroup;
  formProduct: FormGroup;
  items: FormArray;
  products = [];
  vendors = [];
  statusPO = [];
  company = [];
  dealer = [];
  row: any = [];
  now: Date = new Date();
  _dateValue: any;
  /** Vendor data */
  detailVendor = false;
  vendor_name = [];
  vendor_type = [];
  address = [];
  phone = [];
  fax = [];
  email = [];
  web = [];
  po_detail = [];
  NameProduct = [];
  sumValue = 0;
  taxVal = 0;

  ship_to_id = 0;
  bill_to_id = 0;
  // idDealer = 0;
  @ViewChild(DxDataGridComponent)
  dataGrid: DxDataGridComponent;

  /** Ship To Data */
  detailShipTo = false;
  // company_name_ShipTo = [];
  dealer_name_ShipTo = [];
  addressShipTo = [];
  phoneShipTo = [];
  faxShipTo = [];
  emailShipto = [];
  webShipTo = [];

  /** Bill To Data */
  detailBillTo = false;
  company_name_BillTo = [];
  addressBillTo = [];
  phoneBillTo = [];
  faxBillTo = [];
  emailBillTo = [];
  webBillTo = [];
  itemspartners: any;

  constructor(
    private apiService: ApiService,
    private localStorageService: LocalStorageService,
    private formBuilder: FormBuilder,
    private location: Location,
    private router: Router,
    private route: ActivatedRoute,
    private flashMessage: FlashMessagesService,
    private translate: TranslateService
  ) {
    this.dateValue = this.now;
  }

  ngOnInit() {
    this.loadVendors();
    this.loadStatus();
    this.loadCompany();
    this.loadDealer();
    this.loadProducts();

    this.formProduct = this.formBuilder.group({
      date: new FormControl('', {
        // validators: Validators.required
      }),
      POnumber: new FormControl('', {}),
      vendor: new FormControl('', {
        validators: Validators.required
      }),
      status: new FormControl('', {
        validators: Validators.required
      }),
      terms: new FormControl('', {
        validators: Validators.required
      }),
      shipTo: new FormControl('', {
        validators: Validators.required
      }),
      billTo: new FormControl('', {
        validators: Validators.required
      }),
      items: this.formBuilder.array([])
    },
      { updateOn: 'blur' });

    this.route.params.subscribe(params => {
      this.id = isNaN(parseInt(params['id'], 10)) ? false : params['id'];
      if (!this.id) {
        return this.createItem();
      }
      const company_active = this.localStorageService.retrieve('user_company_active');
      this.apiService
        .get('vendor?sort=vendorName,asc&company_id=' + company_active)
        .subscribe(async (data: any) => {
          data.content.forEach(val => {
            this.apiService.get('purchase_order/' + this.id).subscribe((data: any) => {
              console.log(data);
              this.grn_status = data.grn_status;
              this.idVendor = data.vendor_id;
              this.idDealer = data.ship_to_id;
              // tslint:disable-next-line: radix
              if (data.vendor_id !== parseInt(val.id)) {
                return this.detailVendor = true;
              }

              if (!data.total_before_tax) {
                this.sum_total = 0;
              }
              if (!data.total_after_tax) {
                this.grand_total_value = 0;
              }

              this.sum_total = data.total_before_tax;
              this.taxVal    = 0;
              this.grand_total_value = data.total_after_tax;

              this.formProduct.patchValue(
                {
                  vendor: data.vendor_id,
                  shipTo: data.ship_to_id,
                  billTo: data.bill_to_id,
                  POnumber: data.po_number,
                  status: data.po_status,
                  terms: data.po_terms
                }
              );

              if (this.idVendor) {
                this.detailVendor = true;
                this.apiService.get('vendor/' + this.idVendor).subscribe((data: any) => {
                  this.vendor_name = data.vendor_name;
                  this.vendor_type = data.vendor_type;
                  this.address = data.address;
                  this.phone = data.phone;
                  this.fax = data.fax;
                  this.email = data.email;
                  this.web = data.web;
                });
              }
              
              data.po_detail.forEach(i => {          
                console.log(i);
                const receiptDetail = this.formBuilder.group(
                  {
                    id: [i.id],
                    product: [i.product_id],
                    price: [i.unit_price],
                    amount: [i.qty],
                    total: [i.sub_total],
                    name: [i.product_name],
                    title: [i.product_name]
                  });
                console.log(receiptDetail);

                this.Detailproduct.push(receiptDetail);
              });
              console.log(this.formProduct);
              /** Ship To */
              this.detailShipTo = true;
              this.apiService.get('dealer/' + this.idDealer).subscribe((data: any) => {
                this.dealer_name_ShipTo = data.dealer_name;
                this.addressShipTo = data.address;
                this.phoneShipTo = data.phone;
                this.faxShipTo = data.fax;
                this.emailShipto = data.email;
                this.webShipTo = data.web;
              });
            });
          });

          /** Bill To */
          this.detailBillTo = true;
          this.apiService.get('company/' + company_active).subscribe((data: any) => {
            this.company_name_BillTo = data.company_name;
            this.addressBillTo = data.address;
            this.phoneBillTo = data.phone;
            this.faxBillTo = data.fax;
            this.emailBillTo = data.email;
            this.webBillTo = data.web;
          });
        });
    });
  }

  get Detailproduct() {
    return this.formProduct.get('items') as FormArray;
  }
  get formItems(): FormGroup {
    return this.formProduct.get('items') as FormGroup;
  }

  async loadProducts() {
      const product_api = await this.apiService.get('product').toPromise();
        const items = [];
        product_api['content'].forEach(product => {          
          items.push({
            id: product.id,
            title: product.brand + ' - ' + product.type + ' - ' + product.model,
            category: product.category,
            cylinder: product.cylinder,
            fuel: product.fuel,
            model: product.model,
            picture: product.picture,
            price: product.basic_price
            // color: stock.color,
            // engine_number: stock.engine_number,
            // manufacture_year: stock.manufacture_year,
            // vin: stock.vin
          });
        });
        this.products = [...items];
      console.log(this.products);
  }

  private loadVendors(): any {
    const company_active = this.localStorageService.retrieve('user_company_active');
    this.apiService
      .get('vendor?sort=vendorName,asc&company_id=' + company_active)
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              title: el.vendor_name,
              type: el.vendor_type,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.vendors = [...items];
      });
  }

  private loadCompany(): any {
    this.apiService
      .get('company')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              company_name: el.company_name,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.company = [...items];
      });
  }

private loadDealer(): any {
    this.apiService
      .get('dealer')
      .pipe(delay(500))
      .subscribe((data: Master) => {
        const items = [];
        data.content.forEach(el => {
          items.push(
            {
              id: el.id,
              dealer_name: el.dealer_name,
              address: el.address,
              phone: el.phone,
              fax: el.fax,
              email: el.email,
              web: el.web
            });
        });
        this.dealer = [...items];
      });
  }

  private loadStatus() {
    const status = [
      { id: 'DRAFT', name: 'Draft' },
      { id: 'APPROVED', name: 'Approved' },
      { id: 'REJECTED', name: 'Rejected' }
    ];
    this.statusPO = [...status];
  }

  private createItem(): FormGroup {
    return this.formBuilder.group({ product: '', price: 0, amount: 0, total: 0, name: '' });
  }


  changeVendors(event) {
    this.detailVendor = false;
    if (event) {
      this.detailVendor = true;
      this.vendor_name = event.title;
      this.vendor_type = event.type;
      this.address = event.address;
      this.phone = event.phone;
      this.fax = event.fax;
      this.email = event.email;
      this.web = event.web;
    } else {
      this.detailVendor = false;
    }
  }

  changeShipTo(event) {
    // console.log(event);
    // console.log('VENDOR SHIP TO');
    if (event.id) {
      this.detailShipTo = true;
      this.dealer_name_ShipTo = event.dealer_name;
      this.addressShipTo = event.address;
      this.phoneShipTo = event.phone;
      this.faxShipTo = event.fax;
      this.emailShipto = event.email;
      this.webShipTo = event.web;
    }
  }

  changeBillTo(event) {
    // console.log(event);
    // console.log('VENDOR BILL TO');
    if (event.id) {
      this.detailBillTo = true;
      this.company_name_BillTo = event.company_name;
      this.addressBillTo = event.address;
      this.phoneBillTo = event.phone;
      this.faxBillTo = event.fax;
      this.emailBillTo = event.email;
      this.webBillTo = event.web;
    }
  }

  async changeProduct(event, i: number) {
    const control = <FormArray>this.formProduct.controls['items'];
    control.at(i).patchValue({ price: event.price, amount: 1, total: event.price, name: event.title });

    const total = this.formProduct.value.items;
    const outValue = [];
    for (let i = 0; i < total.length; i++) {
      outValue.push(total[i].total);
    }
    const reducer  = (accumulator, currentValue) => accumulator + currentValue;
    this.sum_total = outValue.reduce(reducer);
    this.taxVal    = 0;
    this.grand_total_value = this.sum_total;
    await this.loadProducts();
    await this.customRemoveProducts();
    console.log('Current item ', control.value[i]);
  }

  async addItem($event) {
    this.items = this.formProduct.get('items') as FormArray;
    this.items.push(this.createItem());
    await this.loadProducts();
    await this.customRemoveProducts();
  }

  async customRemoveProducts() {
    const control = <FormArray>this.formProduct.controls['items'];        
    const item_delete = control.value;    
    console.log(this.products);
    console.log(item_delete);

        item_delete.forEach(element => {          
          if (element.product !== '') {            
            const id_need_remove = element.product;
            const index = this.products.findIndex(x => x.id === id_need_remove);
            this.products.splice(index,1);// remove element if already selected
          }
        });        
        console.log(this.products);
  }

  editItem(event, i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    control.at(i).patchValue({ total: control.value[i].price * control.value[i].amount });

    const total = this.formProduct.value.items;
    const outValue = [];
    for (let i = 0; i < total.length; i++) {
      outValue.push(total[i].total);
    }
    const reducer = (accumulator, currentValue) => accumulator + currentValue;
    this.sum_total = outValue.reduce(reducer);
    this.taxVal    = 0;
    this.grand_total_value = this.sum_total;
    console.log('Current item ', control.value[i]);
  }

  deleteItem(i: number): void {
    const control = <FormArray>this.formProduct.controls['items'];
    const total   = this.formProduct.value.items;
    const product_detail_id = control.at(i).value.id;
    const reducer = (accumulator, currentValue) => accumulator + currentValue;
    console.log(control.at(i));

    if (!product_detail_id) {
      this.sum_total = 0;
      this.taxVal = 0;
      this.grand_total_value = 0;

      const outValue = [];
      for (let s = 0; s < total.length; s++) {
        outValue.push(total[s].total);
      }

      const sum = outValue.splice(1);
      let val = 0;
      for (let i = 0; i < sum.length; i++) {
        val += sum[i];
      }
      this.sum_total = val;
      // return;
    }
      // this.apiService.delete('purchase_order/detail/' + product_detail_id).subscribe(
      //   success => { },
      //   error => { }
      // );
    const outValue2 = [];
    for (let s = 0; s < total.length; s++) {
       outValue2.push(total[s].total);
    }
    const AllItemsValue =  outValue2.reduce(reducer);
    this.sum_total = AllItemsValue - outValue2.splice(i)[0];

    const sum = outValue2.splice(1);
    let val = 0;
    for (let i = 0; i < sum.length; i++) {
      val += sum[i];
    }
    // this.sum_total = val;

    control.removeAt(i);
  }

  taxValue(event) {
    const value = event.srcElement.value;
    this.taxVal = value;
    this.grand_total_calculate = this.sum_total * value / 100;
    this.grand_total_value = this.grand_total_calculate + this.sum_total;

    return this.grand_total_value;
  }

  async save() {
    const companyId = this.localStorageService.retrieve('user_company_active');
    this.validate = this.Validation(this.formProduct.value);
    if (this.formProduct.valid) {
      const product = this.formProduct.value.items;
      const product_value = [];
      const product_detail = [];
      product.forEach(data => {
        const updatedataProduct = {
          product_id: data.product,
          product_name: data.name,
          qty: data.amount,
          unit_price: data.price,
          sub_total: data.total,
        };
        const updatedataProductDetail = {
          id: data.id,
          product_id: data.product,
          product_name: data.name,
          qty: data.amount,
          unit_price: data.price,
          sub_total: data.total,
        };
        product_value.push(updatedataProduct);
        product_detail.push(updatedataProductDetail);
      });

      this.percent = this.taxVal;
      const sumTotal = product.reduce((sum, item) => sum + item.total, 0);
      this.tax = sumTotal * this.percent / 100;
      this.grand_total = this.tax + sumTotal;

      const data_Vendor = await this.apiService.get('vendor/' + this.formProduct.value.vendor).toPromise();
      this.vendorName   = data_Vendor['vendor_name'];

      const data_Company_billTo = await this.apiService.get('company/' + this.formProduct.value.billTo).toPromise();
      this.BillToName = data_Company_billTo['company_name'];

      const data_Dealer_shipTo = await this.apiService.get('dealer/' + this.formProduct.value.shipTo).toPromise();
      this.ShipToName = data_Dealer_shipTo['dealer_name'];

      /** Convert Format Date to ISO */
      const myDate  = new Date(this.dateValue);
      const NewDate = myDate.toISOString();
    
      if (this.formProduct.valid) {
        if (!this.id) {
          const form_value_type_POST = {
            company_id: companyId,
            // po_number: this.formProduct.value.POnumber,
            po_terms: this.formProduct.value.terms,
            po_date: NewDate,
            vendor_id: this.formProduct.value.vendor,
            vendor_name: this.vendorName,
            // dealer_id: this.formProduct.value.dealer,
            // dealer_name: this.dealerName,
            bill_to_id: this.formProduct.value.billTo,
            ship_to_name: this.ShipToName,
            ship_to_id: this.formProduct.value.shipTo,
            bill_to_name: this.BillToName,
            total_before_tax: this.sum_total,
            tax: this.taxVal,
            total_after_tax: this.grand_total,
            po_status: this.formProduct.value.status,
            po_detail: product_value,
            grn_status: 'NOT_RECEIVED'
          };

          this.apiService.post('purchase_order/', form_value_type_POST).subscribe(
            success => {
              console.log(success);
              this.router.navigate(['transaction/vendor-po']);
            },
            error => {
              console.log(error);
            }
          );
          // this.router.navigate(['transaction/vendor-po']);
        } else {
          if (this.grand_total === '' && this.grand_total === 0) {
            this.grand_total = 0;
          }
          const form_PUT_without_detailPO = {
            company_id: companyId,
            po_number: this.formProduct.value.POnumber,
            po_terms: this.formProduct.value.terms,
            po_date: NewDate,
            vendor_id: this.formProduct.value.vendor,
            vendor_name: this.vendorName,
            bill_to_id: this.formProduct.value.billTo,
            ship_to_name: this.ShipToName,
            ship_to_id: this.formProduct.value.shipTo,
            bill_to_name: this.BillToName,
            total_before_tax: this.sum_total,
            tax: this.taxVal,
            total_after_tax: this.grand_total,
            po_status: this.formProduct.value.status,
            grn_status: this.grn_status 

          };

          this.apiService.put('purchase_order/' + this.id, form_PUT_without_detailPO).subscribe(
            success => {
              console.log(success);
            },
            error => {
              console.log(error);
            }
          );
          product_detail.forEach(data => {
            if (!data.id) {
              const form_detailPO_POST = {
                purchase_order: { id: this.id },
                product_id: data.product_id,
                product_name: data.product_name,
                qty: data.qty,
                sub_total: data.sub_total,
                unit_price: data.unit_price
              };

              this.apiService.post('purchase_order/detail/', form_detailPO_POST).subscribe(
                success => {
                  console.log(success);
                  this.router.navigate(['transaction/vendor-po']);
                },
                error => {
                  console.log(error);
                }
              );
              return;
            } else {
              const form_detailPO_PUT = {
                purchase_order: { id: this.id},
                product_id: data.product_id,
                product_name: data.product_name,
                qty: data.qty,
                sub_total: data.sub_total,
                unit_price: data.unit_price
              };
              this.apiService.put('purchase_order/detail/' + data.id, form_detailPO_PUT).subscribe(
                success => {
                  console.log(success);
                  this.router.navigate(['transaction/vendor-po']);
                },
                error => {
                  console.log(error);
                }
              );
            }
          });
          // this.router.navigate(['transaction/vendor-po']);
        }
      }
    } else {
      this.validateAllFormFields(this.formProduct);
    }
  }

  back(): void {
    this.location.back();
  }
  fieldValid(control) {
    return control.markAsTouched({ onlySelf: true });
  }

  isFieldValid(field: string) {
    return !this.formProduct.get(field).valid && this.formProduct.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-danger': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  Validation(dataForm) {
    this.valid  = 1;
      // console.log(dataForm);
      if (!dataForm.status) {
        const control = this.formProduct.get('status');
        this.fieldValid(control);
        const title = this.translate.instant('app.status');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.terms) {
        const control = this.formProduct.get('terms');
        this.fieldValid(control);
        const title = this.translate.instant('terms');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
        });
        this.valid = this.NotSave(0);
      }
      if (!dataForm.vendor) {
        const control = this.formProduct.get('vendor');
        this.fieldValid(control);
        const title = this.translate.instant('app.vendor');
        this.flashMessage.show(title + ' is not empty !', {
          cssClass: 'alert-danger',
          showCloseBtn: true
      });
      this.valid = this.NotSave(0);
    }
    if (!dataForm.shipTo) {
      const control = this.formProduct.get('shipTo');
      this.fieldValid(control);
      const title = this.translate.instant('app.ship-to');
      this.flashMessage.show(title + ' is not empty !', {
        cssClass: 'alert-danger',
        showCloseBtn: true
    });
    this.valid = this.NotSave(0);
  }
  if (!dataForm.billTo) {
    const control = this.formProduct.get('billTo');
    this.fieldValid(control);
    const title = this.translate.instant('app.bill-to');
    this.flashMessage.show(title + ' is not empty !', {
      cssClass: 'alert-danger',
      showCloseBtn: true
  });
  this.valid = this.NotSave(0);
}
      return this.NotSave(this.valid);
    }
    NotSave(value) {
      return value === 0 ? 0 : 1;
    }

  get dateValue(): any {
    return this._dateValue;
  }

  set dateValue(value: any) {
    this._dateValue = (value && [value]) || [];
    this._dateValue = value;
  }
}


