import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VendorPoComponent } from './vendor-po.component';
import { VendorPoFormComponent } from './vendor-po-form.component';

const routes: Routes = [
  {
    path: '',
    component: VendorPoComponent,
    data: {
      breadcrumb: 'sys.list'
    }
  },
  {
    path: 'create',
    component: VendorPoFormComponent,
    data: {
      breadcrumb: 'sys.add'
    }
  },
  {
    path: ':id/edit',
    component: VendorPoFormComponent,
    data: {
      breadcrumb: 'sys.edit'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VendorPoRoutingModule { }
