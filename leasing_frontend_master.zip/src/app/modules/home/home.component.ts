import { Component, OnInit } from '@angular/core';
import { Data, HomeService } from '../home/home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styles: [],
  providers: [HomeService]
})
export class HomeComponent implements OnInit {
  dataSource: any;

  constructor(private homeService: HomeService) {
    this.dataSource = this.homeService.getData();
  }

  ngOnInit() {}
}
