import { Injectable } from '@angular/core';

export class Data {
  day: string;
  oranges: number;
}

const data: Data[] = [
  {
    day: 'January',
    oranges: 100000
  },
  {
    day: 'February',
    oranges: 120000
  },
  {
    day: 'March',
    oranges: 190000
  },
  {
    day: 'April',
    oranges: 210000
  },
  {
    day: 'May',
    oranges: 270000
  },
  {
    day: 'June',
    oranges: 310000
  },
  {
    day: 'July',
    oranges: 380000
  },
  {
    day: 'August',
    oranges: 490000
  }
];

@Injectable()
export class HomeService {
  constructor() {}

  getData(): Data[] {
    return data;
  }
}
