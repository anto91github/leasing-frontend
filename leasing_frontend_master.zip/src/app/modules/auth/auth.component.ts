import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { FlashMessagesService } from 'angular2-flash-messages';
import { UserService, User } from '../../core';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit, OnDestroy {
  formLogin: FormGroup;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private userService: UserService,
    private flashMessage: FlashMessagesService,
    private router: Router
  ) {}

  ngOnInit() {
    this.document.body.classList.add('login');
    this.formLogin = new FormGroup({
      username: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      password: new FormControl('', {
        validators: [Validators.required]
      })
    });
  }

  ngOnDestroy() {
    this.document.body.classList.remove('login');
  }

  /**
   * Submit login data
   */
  submit() {
    if (this.formLogin.valid) {
      const credentials = {
        username_or_email: this.formLogin.value.username,
        password: this.formLogin.value.password
      };
      this.userService.attemptAuth(credentials).subscribe(
        (data: User) => {
          if (data.id) {
            this.userService.saveUserData(data);
            this.router.navigateByUrl('/user/profiles');
          }
        },
        error => {
          this.flashMessage.show(error.error.message, {
            cssClass: 'alert-danger',
            showCloseBtn: true
          });
        }
      );
    }
  }
}
