import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CoreModule } from './core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { DxDataGridModule, DxChartModule } from 'devextreme-angular';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Ng2Webstorage } from 'ngx-webstorage';
import { FlashMessagesModule } from 'angular2-flash-messages';
import {
  PerfectScrollbarModule,
  PERFECT_SCROLLBAR_CONFIG,
  PerfectScrollbarConfigInterface
} from 'ngx-perfect-scrollbar';
import { DatePipe } from '@angular/common';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/containers/full-layout/header.component';
import { SidebarComponent } from './shared/containers/full-layout/sidebar.component';
import { FooterComponent } from './shared/containers/full-layout/footer.component';
import { HomeComponent } from './modules/home/home.component';
import { BreadcrumbComponent } from './shared/containers/full-layout/breadcrumb.component';
import { SimpleLayoutComponent } from './shared/containers/simple-layout/simple-layout.component';
import { FullLayoutComponent } from './shared/containers/full-layout/full-layout.component';
import { PolicyFormComponent } from './modules/setting/policy/policy-form.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    HomeComponent,
    BreadcrumbComponent,
    SimpleLayoutComponent,
    FullLayoutComponent,
    PolicyFormComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    SharedModule,
    DxDataGridModule,
    DxChartModule,
    HttpClientModule,
    PerfectScrollbarModule,
    Ng2Webstorage.forRoot({ prefix: '', separator: '', caseSensitive: true }),
    NgbModule.forRoot(),
    FlashMessagesModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: function(http: HttpClient) {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
