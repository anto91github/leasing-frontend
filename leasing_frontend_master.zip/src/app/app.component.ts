import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LocalStorageService } from 'ngx-webstorage';
import { UserService, ConfigService } from './core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  config: any;
  constructor(
    translate: TranslateService,
    private localSt: LocalStorageService,
    private configService: ConfigService,
    private userService: UserService
  ) {
    let lang = this.localSt.retrieve('sys.lang');
    if (lang == null) {
      this.localSt.store('sys.lang', 'en');
      lang = 'en';
    }
    translate.setDefaultLang(lang);
    translate.use(lang);
    this.config = this.configService.config;
    this.userService.populate();
  }
}
