import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  headers_token: any;
  url: any;
  
  constructor() {
    this.url = 'http://192.168.1.6:8080/v1/';
    this.headers_token = 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyIiwiaWF0IjoxNTcyNDA4NzE5LCJleHAiOjE1NzMwMTM1MTl9.OUFASH3ejlJwmnEwhpmltwwKAZ6N2SBQTY-9eutrxIpOZbVmvlJwdrYVCie1RzIB3QhO0s2v-H3Ynmw-vUFfrw';
   }

  async simpleGet(url) {
    let result;
    await window.fetch(this.url+url, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': this.headers_token
      }
    }).then(r => r.json()).then(j => { 
      result = j;
    });
    return result;
  }

}
