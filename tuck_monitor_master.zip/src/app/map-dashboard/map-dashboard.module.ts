import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MapDashboardComponent } from './map-dashboard.component';
import { MapDashboardRoutingModule } from './map-dashboard-routing.module';

@NgModule({
  declarations: [MapDashboardComponent],
  imports: [
    CommonModule,
    MapDashboardRoutingModule
  ]
})
export class MapDashboardModule { }
