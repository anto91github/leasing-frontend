import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-dashboard',
  templateUrl: './map-dashboard.component.html',
  styleUrls: ['./map-dashboard.component.scss']
})
export class MapDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
