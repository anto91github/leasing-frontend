import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MapDashboardComponent } from './map-dashboard.component';


const routes: Routes = [
  {
    path: '',
    component: MapDashboardComponent,
    data: {
      title: 'Map-Dashboard'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MapDashboardRoutingModule { }
