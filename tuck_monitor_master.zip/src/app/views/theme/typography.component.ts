import { Component } from '@angular/core';

@Component({
  templateUrl: 'typography.component.html'
})
export class TypographyComponent {

  constructor() { }

}
