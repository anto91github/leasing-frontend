import { Component, OnInit, Inject } from '@angular/core';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { ApiService } from '../../services/api.service';

@Component({
  templateUrl: 'dashboard.component.html',
  providers: [ApiService]
})
export class DashboardComponent implements OnInit {
  subtitle: string;
  // google maps zoom level
  zoom: number = 15;
  constructor(
    private apiService: ApiService,
  ) {}
  
  // initial center position for the map
  lat: number = 0.3666337;
  lng: number = 116.1402746;

  userScreenHeight = window.innerHeight - 200;

  clickedMarker(label: string, index: number) {
    console.log(`clicked the marker: ${label || index}`)
  }
  // mapClicked($event: MouseEvent) {
  //   this.markers.push({
  //     lat: $event.coords.lat,
  //     lng: $event.coords.lng,
  //     draggable: true
  //   });
  // }
  
  markerDragEnd(m: marker, $event: MouseEvent) {
    console.log('dragEnd', m, $event);
  }

  markerIconUrl() {
     //return require('../../../assets/img/map/ship-c.png');
    // const param ={
    //     url: './../../../assets/img/map/ship-c.png',
    //     scaledSize: {
    //         width: 40,
    //         height: 60
    //     }
    // }; 
    // return param;
  }

  updateMarker() {
    this.lat = 0.3629298;
    this.lng = 116.1432755;
  }

  resetMarker() {
  this.lat = 0.3666337;
  this.lng = 116.1402746;
  }
  
  markers: marker[] = [
	  {
		  lat: 51.673858,
		  lng: 7.815982,
		  label: 'A',
		  draggable: true
	  },
	  {
		  lat: 51.373858,
		  lng: 7.215982,
		  label: 'B',
		  draggable: false
	  },
	  {
		  lat: 51.723858,
		  lng: 7.895982,
		  label: 'C',
		  draggable: true
	  }
  ]
 
  ngAfterViewInit() {}

  async getTugboat(){
    console.log(2);
    const a = await this.apiService.simpleGet('tugboat');
    console.log(a);
  }

  ngOnInit(): void {
    console.log(1);
    this.getTugboat();
  }
  
}

interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}
